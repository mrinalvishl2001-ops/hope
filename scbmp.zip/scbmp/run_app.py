"""Start SCBMP:  python run_app.py   then open http://localhost:8000"""
from __future__ import annotations

import socket
import sys
import threading
import time
import webbrowser


def port_free(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1" if host in ("0.0.0.0", "") else host, port)) != 0


def main() -> int:
    if sys.version_info < (3, 10):
        print("SCBMP needs Python 3.10 or newer. You have", sys.version.split()[0])
        return 1
    try:
        import uvicorn
        from backend.core.config import get_config
    except ImportError as exc:
        print(f"Missing package ({exc.name}). Run:  pip install -r requirements.txt")
        return 1
    cfg = get_config()
    host, port = cfg.app.get("host", "127.0.0.1"), int(cfg.app.get("port", 8000))
    if not port_free(host, port):
        print(f"Port {port} is already in use. Close the other SCBMP window or change app.port in config.yaml.")
        return 1
    url = f"http://localhost:{port}"
    print(f"\n  SCBMP is starting at {url}  (press Ctrl+C to stop)\n")
    if cfg.app.get("open_browser", True):
        threading.Thread(target=lambda: (time.sleep(2), webbrowser.open(url)), daemon=True).start()
    uvicorn.run("backend.main:app", host=host, port=port, log_level="warning")
    return 0


if __name__ == "__main__":
    sys.exit(main())
