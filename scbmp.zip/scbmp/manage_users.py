"""Manage SCBMP users.

  python manage_users.py init                      create the three default users
  python manage_users.py list                      show users
  python manage_users.py add USER PASSWORD ROLE [--name "Full Name"] [--email a@b.com]
  python manage_users.py reset USER NEWPASSWORD    change a password
  python manage_users.py email USER a@b.com        change an email address
ROLE is SDQ, CFMO or AE.
"""
from __future__ import annotations

import argparse
import sys

from backend.core.auth import ROLES, UserStore
from backend.core.config import get_config

DEFAULTS = [
    ("Mrinal007", "Bhaavya", "SDQ", "Mrinal", "mrinal007@example.com"),
    ("Visva3202", "Godhelpme", "CFMO", "Visva", "visva3202@example.com"),
    ("Nitesh003", "Mentor123", "AE", "Nitesh", "nitesh003@example.com"),
]


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Manage SCBMP users")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("init")
    sub.add_parser("list")
    a = sub.add_parser("add")
    a.add_argument("username"); a.add_argument("password"); a.add_argument("role", choices=ROLES)
    a.add_argument("--name", default=""); a.add_argument("--email", default="")
    r = sub.add_parser("reset")
    r.add_argument("username"); r.add_argument("password")
    e = sub.add_parser("email")
    e.add_argument("username"); e.add_argument("email")
    args = p.parse_args(argv)

    store = UserStore(get_config().users_file)
    if args.cmd == "init":
        for u, pw, role, name, email in DEFAULTS:
            store.upsert(u, pw, role, name, email)
        print("Created default users:", ", ".join(d[0] for d in DEFAULTS))
    elif args.cmd == "list":
        for u in store.all():
            print(f"{u.username:12} {u.role:5} {u.display_name:15} {u.email}")
    elif args.cmd == "add":
        store.upsert(args.username, args.password, args.role, args.name or args.username, args.email)
        print("Saved", args.username)
    elif args.cmd in ("reset", "email"):
        u = store.get(args.username)
        if not u:
            print("No such user:", args.username); return 1
        if args.cmd == "reset":
            store.upsert(u.username, args.password, u.role, u.display_name, u.email)
        else:
            store.upsert(u.username, None, u.role, u.display_name, args.email)
        print("Updated", u.username)
    return 0


if __name__ == "__main__":
    sys.exit(main())
