"""SCBMP automated tests.  Run:  python -m unittest -v"""
from __future__ import annotations

import shutil
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path

import yaml

from backend.core import chasers
from backend.core.assignment import Classifier, inspect_upload, run_assignment
from backend.core.auth import LoginGuard, UserStore, hash_password, make_token, read_token, verify_password
from backend.core.breaks import all_summaries
from backend.core.config import BASE_DIR, Config
from backend.core.data_store import ConflictError, DataStore, StoreError
from backend.core.dates import days_between, parse_date
from backend.core.workflow import apply_action

SAMPLE = BASE_DIR / "data" / "sample" / "Combined_Sheet_original.xlsx"


def add_bdays(start: date, n: int) -> date:
    d, k = start, 0
    while k < n:
        d += timedelta(days=1)
        if d.weekday() < 5:
            k += 1
    return d


class Env:
    """A throw-away copy of the app's data, config and users."""

    def __init__(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="scbmp_test_"))
        shutil.copy(SAMPLE, self.tmp / "breaks.xlsx")
        raw = yaml.safe_load((BASE_DIR / "config.yaml").read_text(encoding="utf-8"))
        raw["data"].update({"excel_path": str(self.tmp / "breaks.xlsx"), "sample_path": str(SAMPLE),
                            "backups_dir": str(self.tmp / "backups"), "uploads_dir": str(self.tmp / "uploads")})
        raw["chasers"].update({"outbox_dir": str(self.tmp / "outbox"), "mode": "preview"})
        raw["users_file"] = str(self.tmp / "users.json")
        (self.tmp / "config.yaml").write_text(yaml.safe_dump(raw), encoding="utf-8")
        self.cfg = Config(self.tmp / "config.yaml", self.tmp / "runtime.json")
        self.users = UserStore(self.cfg.users_file)
        self.users.upsert("Mrinal007", "Bhaavya", "SDQ", "Mrinal", "mrinal@example.com")
        self.users.upsert("Visva3202", "Godhelpme", "CFMO", "Visva", "visva@example.com")
        self.users.upsert("Nitesh003", "Mentor123", "AE", "Nitesh", "nitesh@example.com")
        self.store = DataStore(self.cfg)

    def user(self, name):
        return self.users.get(name)

    def items(self, as_of=None):
        return all_summaries(self.store.snapshot(), self.cfg, as_of or date.today())

    def cleanup(self):
        shutil.rmtree(self.tmp, ignore_errors=True)


class Base(unittest.TestCase):
    def setUp(self):
        self.env = Env()
        run_assignment(self.env.store, self.env.cfg, self.env.users)

    def tearDown(self):
        self.env.cleanup()

    def mine(self, username):
        return [i for i in self.env.items() if i["is_open"] and i["assigned_to"] == username]

    def act(self, username, bid, action, comment="Checked and updated", **kw):
        snap = self.env.store.snapshot()
        from backend.core.workflow import version_of
        v = version_of(snap.by_id(bid).wf)
        return apply_action(self.env.store, self.env.cfg, self.env.users, self.env.user(username), bid, action,
                            comment, v, **kw)


class TestDates(unittest.TestCase):
    def test_parse_formats(self):
        for v in ("07-10-2026", "2026-10-07", 20261007, "07/10/2026"):
            self.assertEqual(parse_date(v), date(2026, 10, 7), v)
        self.assertIsNone(parse_date("not a date"))

    def test_business_days(self):
        self.assertEqual(days_between(date(2026, 10, 7), date(2026, 10, 14)), 5)    # Wed -> Wed
        self.assertEqual(days_between(date(2026, 10, 9), date(2026, 10, 12)), 1)    # Fri -> Mon
        self.assertEqual(days_between(date(2026, 10, 9), date(2026, 10, 12), business=False), 3)


class TestAuth(unittest.TestCase):
    def test_hash_and_verify(self):
        h = hash_password("Bhaavya")
        self.assertTrue(verify_password("Bhaavya", h))
        self.assertFalse(verify_password("bhaavya", h))      # passwords are case-sensitive
        self.assertNotIn("Bhaavya", h)

    def test_token_tamper_and_expiry(self):
        t = make_token("Mrinal007")
        self.assertEqual(read_token(t, 8, 30)[0], "Mrinal007")
        self.assertIsNone(read_token(t[:-4] + "AAAA", 8, 30))
        old = make_token("Mrinal007", issued=1, seen=1)
        self.assertIsNone(read_token(old, 8, 30))

    def test_lockout_after_five(self):
        g = LoginGuard()
        for _ in range(5):
            g.failed("Nitesh003")
        with self.assertRaises(Exception):
            g.check("nitesh003")


class TestAssignment(Base):
    def test_expected_result_on_sample(self):
        items = self.env.items()
        self.assertEqual(len(items), 29)
        self.assertEqual(sum(1 for i in items if i["status"] == "Closed"), 23)
        self.assertEqual(len(self.mine("Nitesh003")), 5)
        self.assertEqual(len(self.mine("Visva3202")), 1)
        self.assertEqual(sum(1 for i in items if i["is_exception"]), 23)

    def test_rerun_changes_nothing(self):
        before = [(i["id"], i["status"]) for i in self.env.items()]
        res = run_assignment(self.env.store, self.env.cfg, self.env.users)
        self.assertEqual(res.newly_assigned, 0)
        self.assertEqual(before, [(i["id"], i["status"]) for i in self.env.items()])

    def test_classifier_rules(self):
        c = Classifier(self.env.cfg)
        self.assertEqual(c.classify("CFMO", "Product mapping").role, "CFMO")      # column BC wins
        self.assertEqual(c.classify("", "Product mapping").role, "AE")             # then BB
        self.assertEqual(c.classify("", "", "please ask the Account Executive").role, "AE")
        self.assertEqual(c.classify("", "", "AEX venue").category, "Unclassified")  # whole word only
        self.assertTrue(c.classify("", "", "").flagged)

    def test_upload_detects_duplicates(self):
        info = inspect_upload(SAMPLE, self.env.store, self.env.cfg)
        self.assertEqual(info["new"], 0)
        self.assertEqual(info["duplicates"], 29)


class TestWorkflow(Base):
    def test_full_flow_ae_sdq_cfmo_close(self):
        bid = self.mine("Nitesh003")[0]["id"]
        self.act("Nitesh003", bid, "send_to_sdq", checks=["Agreement updated"])
        self.assertIn(bid, [i["id"] for i in self.mine("Mrinal007")])
        self.act("Mrinal007", bid, "send_to_cfmo")
        self.assertIn(bid, [i["id"] for i in self.mine("Visva3202")])
        self.act("Visva3202", bid, "comment")
        self.act("Visva3202", bid, "close")
        item = next(i for i in self.env.items() if i["id"] == bid)
        self.assertEqual(item["status"], "Closed")
        self.assertEqual(item["closed_by"], "Visva3202")
        audit = [a for a in self.env.store.snapshot().audit if a["Break ID"] == bid]
        self.assertEqual([a["User"] for a in audit][1:], ["Nitesh003", "Mrinal007", "Visva3202", "Visva3202"])
        self.assertIn("Agreement updated", audit[1]["Comment"])

    def test_permissions(self):
        ae_bid = self.mine("Nitesh003")[0]["id"]
        cfmo_bid = self.mine("Visva3202")[0]["id"]
        with self.assertRaises(StoreError):
            self.act("Nitesh003", ae_bid, "close")             # AE cannot close
        with self.assertRaises(StoreError):
            self.act("Visva3202", ae_bid, "comment")           # CFMO cannot touch an AE break
        with self.assertRaises(StoreError):
            self.act("Nitesh003", cfmo_bid, "send_to_sdq")

    def test_comment_required(self):
        bid = self.mine("Nitesh003")[0]["id"]
        with self.assertRaises(StoreError):
            self.act("Nitesh003", bid, "send_to_sdq", comment="ok")

    def test_stale_version_is_rejected(self):
        bid = self.mine("Nitesh003")[0]["id"]
        snap = self.env.store.snapshot()
        from backend.core.workflow import version_of
        old = version_of(snap.by_id(bid).wf)
        self.act("Nitesh003", bid, "comment")
        with self.assertRaises(ConflictError):
            apply_action(self.env.store, self.env.cfg, self.env.users, self.env.user("Nitesh003"), bid,
                         "comment", "Second comment", old)

    def test_reassign_and_reopen(self):
        bid = self.mine("Nitesh003")[0]["id"]
        self.act("Mrinal007", bid, "reassign", target_role="CFMO")
        self.assertIn(bid, [i["id"] for i in self.mine("Visva3202")])
        self.act("Visva3202", bid, "close")
        self.act("Mrinal007", bid, "reopen")
        self.assertIn(bid, [i["id"] for i in self.mine("Mrinal007")])

    def test_backup_written(self):
        bid = self.mine("Nitesh003")[0]["id"]
        self.act("Nitesh003", bid, "comment")
        self.assertTrue(list((self.env.tmp / "backups").glob("*.xlsx")))


class TestChasers(Base):
    def test_level_schedule(self):
        levels = [chasers.level_for_idle(d, self.env.cfg) for d in range(0, 11)]
        self.assertEqual(levels, [0, 0, 0, 0, 0, 1, 1, 2, 3, 4, 5])

    def test_plan_recipients_and_cc(self):
        today = date.today()
        self.assertEqual(chasers.plan(self.env.store, self.env.cfg, self.env.users, today), [])
        g5 = chasers.plan(self.env.store, self.env.cfg, self.env.users, add_bdays(today, 5))
        self.assertEqual({g["username"] for g in g5}, {"Nitesh003", "Visva3202"})
        self.assertTrue(all(g["level"] == 1 and g["cc"] == "" for g in g5))
        nitesh = next(g for g in g5 if g["username"] == "Nitesh003")
        self.assertEqual(len(nitesh["breaks"]), 5)                       # one email, five breaks
        g7 = chasers.plan(self.env.store, self.env.cfg, self.env.users, add_bdays(today, 7))
        self.assertTrue(all(g["level"] == 2 and g["cc"] == "mrinal@example.com" for g in g7))
        g8 = chasers.plan(self.env.store, self.env.cfg, self.env.users, add_bdays(today, 8))
        self.assertTrue(all(g["level"] == 3 and g["subject"].startswith("[Daily Reminder]") for g in g8))

    def test_redirect(self):
        self.env.cfg.save_runtime_settings({"redirect_all_to": "demo@example.com"})
        g = chasers.plan(self.env.store, self.env.cfg, self.env.users, add_bdays(date.today(), 7))
        self.assertTrue(all(x["to"] == "demo@example.com" and x["cc"] == "" for x in g))

    def test_action_stops_chasers(self):
        bid = self.mine("Nitesh003")[0]["id"]
        self.act("Nitesh003", bid, "comment")
        g = chasers.plan(self.env.store, self.env.cfg, self.env.users, add_bdays(date.today(), 5))
        ids = [b["id"] for x in g for b in x["breaks"]]
        self.assertIn(bid, ids)          # same day comment: clock restarts from today, still due at +5
        self.assertEqual(len(ids), 6)

    def test_run_preview_mode_records_and_does_not_repeat(self):
        self.env.cfg.save_runtime_settings({"mode": "preview"})
        res = chasers.run(self.env.store, self.env.cfg, self.env.users, date.today())
        self.assertEqual(res["count"], 0)
        # pretend today is 5 business days later by back-dating the last action
        def backdate(ed):
            for r in ed.data_rows():
                wf = ed.get_wf(r)
                if wf["Workflow Status"] != "Closed":
                    ed.set_wf(r, {"Last Action On": "2000-01-03 09:00"})
        self.env.store.mutate(backdate)
        res = chasers.run(self.env.store, self.env.cfg, self.env.users, date.today())
        self.assertEqual(res["count"], 2)
        self.assertTrue(list((self.env.tmp / "outbox").glob("*.html")))
        self.assertEqual(len(self.env.store.snapshot().emails), 2)
        again = chasers.run(self.env.store, self.env.cfg, self.env.users, date.today())
        self.assertEqual(again["count"], 0)          # never twice on the same day


class TestApi(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from backend.api.services import reset_services
        from backend.core.config import set_config
        cls.env = Env()
        set_config(cls.env.cfg)
        reset_services(cls.env.cfg)
        from fastapi.testclient import TestClient
        from backend.main import app
        cls.TestClient, cls.app = TestClient, app
        run_assignment(cls.env.store, cls.env.cfg, cls.env.users)

    @classmethod
    def tearDownClass(cls):
        cls.env.cleanup()

    def client(self, u, p):
        c = self.TestClient(self.app)
        r = c.post("/api/auth/login", json={"username": u, "password": p})
        self.assertEqual(r.status_code, 200, r.text)
        return c

    def test_login_rules(self):
        c = self.TestClient(self.app)
        self.assertEqual(c.post("/api/auth/login", json={"username": "Nitesh003", "password": "wrong"}).status_code, 401)
        self.assertEqual(c.get("/api/breaks").status_code, 401)
        self.client("nitesh003", "Mentor123")             # usernames are case-insensitive

    def test_role_guards(self):
        ae = self.client("Nitesh003", "Mentor123")
        self.assertEqual(ae.get("/api/dashboard").status_code, 403)
        self.assertEqual(ae.get("/api/breaks?scope=all").status_code, 403)
        cfmo_break = [i for i in self.env.items() if i["assigned_to"] == "Visva3202" and i["is_open"]][0]["id"]
        self.assertEqual(ae.get(f"/api/breaks/{cfmo_break}").status_code, 403)
        sdq = self.client("Mrinal007", "Bhaavya")
        d = sdq.get("/api/dashboard").json()
        self.assertEqual(d["kpis"]["total"], 29)
        self.assertEqual(sdq.get("/api/breaks/export").status_code, 200)

    def test_spa_served(self):
        c = self.TestClient(self.app)
        r = c.get("/inbox")
        self.assertEqual(r.status_code, 200)
        self.assertIn("<div id=\"root\">", r.text)


if __name__ == "__main__":
    unittest.main()
