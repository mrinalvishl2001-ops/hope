@echo off
rem Optional: only needed if you change the React code in frontend\src. Needs Node.js 18+.
cd /d "%~dp0frontend"
where npm >nul 2>&1
if errorlevel 1 (
  echo Node.js / npm was not found. The app still runs with the pre-built files in frontend\dist.
  pause & exit /b 1
)
call npm install
if errorlevel 1 ( echo npm install failed. & pause & exit /b 1 )
call npm run build
if errorlevel 1 ( echo Build failed. & pause & exit /b 1 )
echo Front end rebuilt into frontend\dist. Restart run_app.bat to see the changes.
pause
