"""Dashboard and inbox metrics (mentor doc Module 6)."""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import date, timedelta

from .config import Config
from .dates import days_between, parse_date, parse_ts
from .workflow import CLOSED, WITH_AE, WITH_CFMO, WITH_SDQ


def _round(x: float, n: int = 1) -> float:
    return round(x, n) if x == x else 0.0


def dashboard(items: list[dict], emails: list[dict], cfg: Config, as_of: date, users: list, period: str = "day") -> dict:
    business = bool(cfg.chasers.get("business_days", True))
    total = len(items)
    open_items = [i for i in items if i["is_open"]]
    closed_items = [i for i in items if i["status"] == CLOSED]
    sla_days = int(cfg.dashboard.get("sla_days", 5))

    kpis = {
        "total": total,
        "open": len(open_items),
        "closed": len(closed_items),
        "exceptions": sum(1 for i in items if i["is_exception"]),
        "overdue": sum(1 for i in open_items if i["overdue"]),
        "avg_aging_open": _round(sum(i["aging"] for i in open_items) / len(open_items)) if open_items else 0,
        "closure_rate": _round(100 * len(closed_items) / total) if total else 0,
        "open_lots": int(sum(abs(i["lots"]) for i in open_items)),
        "flagged": sum(1 for i in items if i["flagged"]),
    }
    flow = [
        {"key": "total", "label": "Daily report", "value": total},
        {"key": WITH_AE, "label": "With AE", "value": sum(1 for i in items if i["status"] == WITH_AE)},
        {"key": WITH_SDQ, "label": "With SDQ", "value": sum(1 for i in items if i["status"] == WITH_SDQ)},
        {"key": WITH_CFMO, "label": "With CFMO", "value": sum(1 for i in items if i["status"] == WITH_CFMO)},
        {"key": CLOSED, "label": "Closed", "value": len(closed_items)},
    ]
    buckets = [b["label"] for b in cfg.dashboard.get("aging_buckets", [])]
    aging_counts = Counter(i["aging_bucket"] for i in open_items)
    aging = [{"bucket": b, "count": aging_counts.get(b, 0)} for b in buckets]

    comments = defaultdict(lambda: {"open": 0, "closed": 0})
    for i in items:
        key = (i["sdq_comment"] or "(no comment)").strip()
        comments[key]["open" if i["is_open"] else "closed"] += 1
    sdq_comments = sorted(({"comment": k, **v, "total": v["open"] + v["closed"]} for k, v in comments.items()),
                          key=lambda x: -x["total"])[:10]

    workload = []
    for u in users:
        mine = [i for i in items if i["assigned_to"].lower() == u.username.lower()]
        closed_mine = [i for i in mine if i["status"] == CLOSED]
        tat = [days_between(parse_date(i["break_date"]), parse_date(i["closed_on"]) or as_of, business)
               for i in closed_mine if i["break_date"]]
        workload.append({"user": u.username, "name": u.display_name, "role": u.role,
                         "open": sum(1 for i in mine if i["is_open"]), "closed": len(closed_mine),
                         "avg_turnaround": _round(sum(tat) / len(tat)) if tat else 0})

    trend = _trend(items, as_of, period)

    accounts = defaultdict(lambda: {"open_lots": 0.0, "aged_lots": 0.0, "open_breaks": 0, "max_aging": 0})
    for i in open_items:
        a = accounts[(i["client"], i["account"])]
        a["open_lots"] += abs(i["lots"])
        a["open_breaks"] += 1
        a["max_aging"] = max(a["max_aging"], i["aging"])
        if i["aging"] >= int(cfg.dashboard.get("overdue_after_days", 5)):
            a["aged_lots"] += abs(i["lots"])
    high_risk = sorted(({"client": k[0], "account": k[1], **{x: int(y) for x, y in v.items()}}
                        for k, v in accounts.items()),
                       key=lambda x: (-x["aged_lots"], -x["open_lots"], -x["max_aging"]))[:10]

    levels = Counter()
    for e in emails:
        try:
            lvl = int(e.get("Chaser Level") or 0)
        except (TypeError, ValueError):
            lvl = 0
        label = "1st" if lvl == 1 else "2nd" if lvl == 2 else "Daily" if lvl >= 3 else None
        if label:
            levels[label] += 1
    within = [i for i in closed_items if i["break_date"] and i["closed_on"]]
    sla_ok = sum(1 for i in within if days_between(parse_date(i["break_date"]), parse_date(i["closed_on"]), business) <= sla_days)
    escalations = {
        "by_level": [{"level": k, "count": levels.get(k, 0)} for k in ("1st", "2nd", "Daily")],
        "sla_adherence": _round(100 * sla_ok / len(within)) if within else 0,
        "sla_days": sla_days, "emails_total": len(emails),
    }
    return {"as_of": as_of.isoformat(), "kpis": kpis, "flow": flow, "aging": aging,
            "status_split": [{"name": "Open", "value": len(open_items)}, {"name": "Closed", "value": len(closed_items)}],
            "sdq_comments": sdq_comments, "workload": workload, "trend": trend,
            "high_risk": high_risk, "escalations": escalations}


def _trend(items: list[dict], as_of: date, period: str) -> list[dict]:
    def key(d: date) -> date:
        if period == "week":
            return d - timedelta(days=d.weekday())
        if period == "month":
            return d.replace(day=1)
        return d
    created, closed = Counter(), Counter()
    for i in items:
        bd = parse_date(i["break_date"])
        if bd:
            created[key(bd)] += 1
        cd = parse_date(i["closed_on"])
        if cd:
            closed[key(cd)] += 1
    keys = sorted(set(created) | set(closed))
    if not keys:
        return []
    # fill gaps so the line is continuous (cap at 60 points)
    start, end = keys[0], max(keys[-1], key(as_of))
    points, d = [], start
    step = {"day": 1, "week": 7}.get(period)
    while d <= end and len(points) < 60:
        points.append({"period": d.isoformat(), "created": created.get(d, 0), "closed": closed.get(d, 0)})
        if step:
            d += timedelta(days=step)
        else:
            d = (d.replace(day=28) + timedelta(days=4)).replace(day=1)
    return points[-60:]


def inbox_summary(items: list[dict], audit: list[dict], username: str, as_of: date) -> dict:
    mine = [i for i in items if i["is_open"] and i["assigned_to"].lower() == username.lower()]
    week_start = as_of - timedelta(days=as_of.weekday())
    chased = 0
    for i in mine:
        t = parse_ts(i.get("last_chaser_on"))
        if t and t.date() >= week_start:
            chased += 1
    month_closed = 0
    for a in audit:
        t = parse_ts(a.get("Timestamp"))
        if (str(a.get("User") or "").lower() == username.lower() and a.get("To Status") == CLOSED
                and a.get("From Status") != CLOSED and t and t.year == as_of.year and t.month == as_of.month):
            month_closed += 1
    return {"open": len(mine), "overdue": sum(1 for i in mine if i["overdue"]),
            "chased_this_week": chased, "closed_this_month": month_closed}
