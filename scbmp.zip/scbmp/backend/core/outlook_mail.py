"""Send or draft email through the signed-in desktop Outlook (pywin32).

Falls back to writing an .html preview into the outbox folder when Outlook or
pywin32 is unavailable (e.g. on a Mac or Linux test machine), so nothing crashes.
"""
from __future__ import annotations

import logging
import re
from datetime import datetime
from pathlib import Path

log = logging.getLogger("scbmp.mail")


def outlook_available() -> bool:
    try:
        import win32com.client  # noqa: F401
        return True
    except Exception:
        return False


def write_preview(outbox: Path, to: str, cc: str, subject: str, html: str) -> Path:
    outbox.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r"[^A-Za-z0-9]+", "_", to.split("@")[0])[:30] or "recipient"
    path = outbox / f"{datetime.now().strftime('%Y%m%d_%H%M%S_%f')[:-3]}_{safe}.html"
    header = (f"<!-- To: {to} | CC: {cc} | Subject: {subject} -->\n"
              f"<div style=\"font:12px Segoe UI,Arial;color:#767676;padding:8px 16px;background:#F5F5F5\">"
              f"<b>To:</b> {to} &nbsp; <b>CC:</b> {cc or '-'} &nbsp; <b>Subject:</b> {subject}</div>\n")
    path.write_text(header + html, encoding="utf-8")
    return path


def deliver(mode: str, to: str, cc: str, subject: str, html: str, outbox: Path) -> str:
    """Return the mode actually used: preview, draft, live, or a preview with the reason."""
    if mode == "preview":
        write_preview(outbox, to, cc, subject, html)
        return "preview"
    try:
        import pythoncom
        import win32com.client
    except Exception:
        write_preview(outbox, to, cc, subject, html)
        return "preview (Outlook not available)"
    pythoncom.CoInitialize()          # required: FastAPI runs this in a worker thread
    try:
        outlook = win32com.client.Dispatch("Outlook.Application")
        mail = outlook.CreateItem(0)  # 0 = olMailItem
        mail.To = to
        if cc:
            mail.CC = cc
        mail.Subject = subject
        mail.HTMLBody = html
        if mode == "live":
            mail.Send()
            return "live"
        mail.Save()                   # lands in the Drafts folder
        return "draft"
    except Exception as exc:
        log.exception("Outlook failed; writing preview instead")
        write_preview(outbox, to, cc, subject, html)
        return f"preview (Outlook error: {str(exc)[:80]})"
    finally:
        pythoncom.CoUninitialize()
