"""Users, password hashing, session tokens and login lockout (standard library only)."""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import threading
import time
from dataclasses import dataclass
from pathlib import Path

from .config import BASE_DIR

PBKDF2_ITERATIONS = 200_000
MAX_FAILED = 5
LOCK_SECONDS = 5 * 60
ROLES = ("SDQ", "CFMO", "AE")
ROLE_LABELS = {"SDQ": "SDQ", "CFMO": "CFMO", "AE": "Account Executive"}
SECRET_FILE = BASE_DIR / ".secret_key"


class AuthError(Exception):
    """Raised for login problems; the message is safe to show to users."""


@dataclass
class User:
    username: str
    display_name: str
    role: str
    email: str

    def public(self) -> dict:
        return {"username": self.username, "display_name": self.display_name,
                "role": self.role, "role_label": ROLE_LABELS.get(self.role, self.role),
                "email": self.email}


# ---------------------------------------------------------------- hashing
def hash_password(password: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS)
    return "pbkdf2_sha256${}${}${}".format(
        PBKDF2_ITERATIONS, base64.b64encode(salt).decode(), base64.b64encode(digest).decode())


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, iters, salt_b64, hash_b64 = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"),
                                     base64.b64decode(salt_b64), int(iters))
        return hmac.compare_digest(digest, base64.b64decode(hash_b64))
    except (ValueError, TypeError):
        return False


# ---------------------------------------------------------------- user store
class UserStore:
    def __init__(self, path: Path):
        self.path = path
        self._lock = threading.Lock()

    def _load(self) -> dict:
        if not self.path.exists():
            raise AuthError(f"Users file not found: {self.path}. Run 'python manage_users.py init'.")
        with open(self.path, "r", encoding="utf-8") as fh:
            return json.load(fh)

    def _save(self, data: dict) -> None:
        tmp = self.path.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)
        tmp.replace(self.path)

    def all(self) -> list[User]:
        data = self._load()
        return [User(u["username"], u.get("display_name", u["username"]), u["role"], u.get("email", ""))
                for u in data.get("users", [])]

    def get(self, username: str) -> User | None:
        key = (username or "").strip().lower()
        for u in self.all():
            if u.username.lower() == key:
                return u
        return None

    def get_by_role(self, role: str, preferred: str | None = None) -> User | None:
        if preferred:
            u = self.get(preferred)
            if u and u.role == role:
                return u
        return next((u for u in self.all() if u.role == role), None)

    def check_password(self, username: str, password: str) -> User | None:
        key = (username or "").strip().lower()
        for rec in self._load().get("users", []):
            if rec["username"].lower() == key and verify_password(password or "", rec.get("password_hash", "")):
                return self.get(rec["username"])
        return None

    def upsert(self, username: str, password: str | None, role: str, display_name: str, email: str) -> None:
        if role not in ROLES:
            raise ValueError(f"Role must be one of {', '.join(ROLES)}")
        with self._lock:
            data = self._load() if self.path.exists() else {"users": []}
            users = data.setdefault("users", [])
            rec = next((u for u in users if u["username"].lower() == username.lower()), None)
            if rec is None:
                if not password:
                    raise ValueError("A new user needs a password.")
                rec = {"username": username}
                users.append(rec)
            rec.update({"role": role, "display_name": display_name or username, "email": email or ""})
            if password:
                rec["password_hash"] = hash_password(password)
            self._save(data)


# ---------------------------------------------------------------- lockout
class LoginGuard:
    """Locks a username for 5 minutes after 5 failed attempts (in memory)."""

    def __init__(self):
        self._fails: dict[str, list[float]] = {}
        self._locked_until: dict[str, float] = {}
        self._lock = threading.Lock()

    def check(self, username: str) -> None:
        key = (username or "").lower()
        until = self._locked_until.get(key, 0)
        if until > time.time():
            mins = max(1, round((until - time.time()) / 60))
            raise AuthError(f"Too many failed attempts. This user is locked for about {mins} more minute(s).")

    def failed(self, username: str) -> int:
        key = (username or "").lower()
        with self._lock:
            now = time.time()
            fails = [t for t in self._fails.get(key, []) if now - t < LOCK_SECONDS] + [now]
            self._fails[key] = fails
            if len(fails) >= MAX_FAILED:
                self._locked_until[key] = now + LOCK_SECONDS
                self._fails[key] = []
                return 0
            return MAX_FAILED - len(fails)

    def succeeded(self, username: str) -> None:
        key = (username or "").lower()
        self._fails.pop(key, None)
        self._locked_until.pop(key, None)


# ---------------------------------------------------------------- tokens
def _secret() -> bytes:
    if SECRET_FILE.exists():
        data = SECRET_FILE.read_bytes().strip()
        if data:
            return data
    key = secrets.token_hex(32).encode()
    SECRET_FILE.write_bytes(key)
    return key


def make_token(username: str, issued: float | None = None, seen: float | None = None) -> str:
    issued = issued or time.time()
    seen = seen or time.time()
    payload = f"{username}|{int(issued)}|{int(seen)}"
    sig = hmac.new(_secret(), payload.encode(), hashlib.sha256).hexdigest()
    return base64.urlsafe_b64encode(f"{payload}|{sig}".encode()).decode()


def read_token(token: str, session_hours: float, idle_minutes: float) -> tuple[str, int] | None:
    """Return (username, issued_at) when the token is valid and not expired, else None."""
    try:
        raw = base64.urlsafe_b64decode(token.encode()).decode()
        username, issued, seen, sig = raw.split("|")
        payload = f"{username}|{issued}|{seen}"
        good = hmac.new(_secret(), payload.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, good):
            return None
        now = time.time()
        if now - int(issued) > session_hours * 3600 or now - int(seen) > idle_minutes * 60:
            return None
        return username, int(issued)
    except Exception:  # malformed token
        return None
