"""Assignment engine: classify each break and give it an owner and workflow status."""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from openpyxl import load_workbook

from .auth import UserStore
from .config import Config
from .data_store import (COL, DataStore, StoreError, WorkbookEditor, build_col_index, json_safe,
                         original_column_count, row_key)
from .dates import now_ts, parse_date

STATUS_BY_ROLE = {"AE": "With AE", "SDQ": "With SDQ", "CFMO": "With CFMO"}
CLOSED = "Closed"


@dataclass
class Classification:
    category: str
    role: str
    matched: str          # e.g. "SDQ Team Responsible: 'Exception'"
    flagged: bool = False


def _pattern(keyword: str) -> re.Pattern:
    return re.compile(r"(?<![A-Za-z0-9])" + re.escape(keyword.strip()) + r"(?![A-Za-z0-9])", re.IGNORECASE)


class Classifier:
    def __init__(self, cfg: Config):
        rules = cfg.assignment.get("rules", [])
        if not rules:
            raise ValueError("config.yaml assignment.rules is empty")
        self.rules = [(r["category"], r["role"], [(k, _pattern(k)) for k in r.get("keywords", []) if str(k).strip()])
                      for r in rules]
        fb = cfg.assignment.get("fallback", {})
        self.fallback = (fb.get("category", "Unclassified"), fb.get("role", "SDQ"))

    def classify(self, team: str | None, comment: str | None, row_text: str = "") -> Classification:
        places = [("SDQ Team Responsible", team or ""), ("SDQ Comments", comment or ""), ("Row", row_text or "")]
        for place, text in places:
            if not text:
                continue
            for category, role, patterns in self.rules:
                for kw, pat in patterns:
                    if pat.search(str(text)):
                        return Classification(category, role, f"{place}: '{kw}'")
        return Classification(self.fallback[0], self.fallback[1], "No rule matched", flagged=True)


@dataclass
class AssignResult:
    total: int = 0
    newly_assigned: int = 0
    already_assigned: int = 0
    by_role: dict = field(default_factory=dict)
    by_status: dict = field(default_factory=dict)
    unclassified: list = field(default_factory=list)

    def as_dict(self) -> dict:
        return self.__dict__.copy()


def _is_closed(status) -> bool:
    return str(status or "").strip().lower() in ("closed", "close", "done", "resolved")


def owner_for(cfg: Config, users: UserStore, role: str) -> str:
    u = users.get_by_role(role, cfg.roles.get(role))
    if u is None:
        raise StoreError(f"No user has the role {role}. Check roles in config.yaml and users.json.")
    return u.username


def assign_in_editor(ed: WorkbookEditor, cfg: Config, users: UserStore) -> AssignResult:
    """Assign every break without a Break ID. Existing assignments are left untouched."""
    clf = Classifier(cfg)
    res = AssignResult()
    owners = {role: owner_for(cfg, users, role) for role in ("SDQ", "CFMO", "AE")}
    rows = list(ed.data_rows())
    ids = [str(ed.get_wf(r).get("Break ID") or "") for r in rows]
    nums = [int(i[4:]) for i in ids if i.upper().startswith("BRK-") and i[4:].isdigit()]
    next_num = max(nums, default=0) + 1
    ts = now_ts()
    for r in rows:
        res.total += 1
        wf = ed.get_wf(r)
        if wf.get("Break ID"):
            res.already_assigned += 1
            status = wf.get("Workflow Status") or "Unknown"
            res.by_status[status] = res.by_status.get(status, 0) + 1
            role = wf.get("Assigned Role") or "-"
            res.by_role[role] = res.by_role.get(role, 0) + 1
            continue
        f = ed.fields(r)
        c = clf.classify(f.get("team"), f.get("sdq_comment"), ed.row_text(r))
        bid = f"BRK-{next_num:05d}"
        next_num += 1
        updates = {"Break ID": bid, "Break Category": c.category, "Assigned Role": c.role,
                   "Assigned On": ts, "Chaser Count": 0}
        if _is_closed(f.get("sdq_status")):
            closed = parse_date(f.get("last_action"))
            updates.update({"Workflow Status": CLOSED, "Assigned To": owners[c.role],
                            "Closed On": closed.isoformat() if closed else ts[:10],
                            "Closed By": "Imported (SDQ STATUS = Closed)",
                            "Last Action On": closed.isoformat() + " 00:00" if closed else ts,
                            "Last Action By": "Import"})
        else:
            updates.update({"Workflow Status": STATUS_BY_ROLE[c.role], "Assigned To": owners[c.role],
                            "Last Action On": ts, "Last Action By": "Assignment engine"})
        ed.set_wf(r, updates)
        ed.audit(ts, bid, "Assignment engine", "Assigned", "", updates["Workflow Status"],
                 f"{c.category} -> {c.role} ({c.matched})")
        if c.flagged:
            res.unclassified.append(bid)
        res.newly_assigned += 1
        res.by_status[updates["Workflow Status"]] = res.by_status.get(updates["Workflow Status"], 0) + 1
        res.by_role[c.role] = res.by_role.get(c.role, 0) + 1
    return res


def run_assignment(store: DataStore, cfg: Config, users: UserStore) -> AssignResult:
    return store.mutate(lambda ed: assign_in_editor(ed, cfg, users))


# ---------------------------------------------------------------- uploads
def inspect_upload(path, store: DataStore, cfg: Config) -> dict:
    """Compare an uploaded daily report with the master file. Nothing is written."""
    try:
        wb = load_workbook(path, read_only=True, data_only=True)
    except Exception:
        raise StoreError("That file could not be read. Upload an .xlsx file in the daily control report layout.")
    try:
        sheet = cfg.data.get("sheet_name", "Sheet1")
        ws = wb[sheet] if sheet in wb.sheetnames else wb.worksheets[0]
        rows = ws.iter_rows(values_only=True)
        headers = list(next(rows, []) or [])
        snap = store.snapshot()
        master = [str(h or "").strip().lower() for h in snap.headers[: snap.original_count]]
        orig = original_column_count(headers)
        got = [str(h or "").strip().lower() for h in headers[:orig]]
        missing = [h for h in COL.values() if h.lower() not in got]
        if got != master:
            if missing:
                raise StoreError("The uploaded file's columns don't match the master file. Missing: "
                                 + ", ".join(missing))
            raise StoreError("The uploaded file has the right key columns but a different column order "
                             f"({orig} columns vs {len(master)}). Use the standard daily report layout.")
        idx = build_col_index(headers, orig)
        existing = {row_key(b.fields) for b in snap.breaks}
        clf = Classifier(cfg)
        new_rows, dupes, seen = [], 0, set()
        for values in rows:
            values = list(values or [])[:orig]
            if not any(v not in (None, "") for v in values):
                continue
            values += [None] * (orig - len(values))
            fields = {k: json_safe(values[i]) for k, i in idx.items()}
            key = row_key(fields)
            if key in existing or key in seen:
                dupes += 1
                continue
            seen.add(key)
            text = " | ".join(str(v) for v in values if v not in (None, ""))
            c = clf.classify(fields.get("team"), fields.get("sdq_comment"), text)
            new_rows.append({"raw": values, "values": [json_safe(v) for v in values], "fields": fields,
                             "category": c.category, "role": c.role,
                             "status": "Closed" if _is_closed(fields.get("sdq_status")) else STATUS_BY_ROLE[c.role]})
        return {"rows_in_file": len(new_rows) + dupes, "new": len(new_rows), "duplicates": dupes, "rows": new_rows}
    finally:
        wb.close()


def commit_upload(path, store: DataStore, cfg: Config, users: UserStore) -> dict:
    info = inspect_upload(path, store, cfg)

    def apply(ed: WorkbookEditor):
        for item in info["rows"]:
            ed.append_source_row(item["raw"])
        return assign_in_editor(ed, cfg, users)

    res = store.mutate(apply)
    return {"added": info["new"], "duplicates": info["duplicates"], "assignment": res.as_dict()}
