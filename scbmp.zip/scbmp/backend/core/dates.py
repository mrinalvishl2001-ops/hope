"""Date parsing and business-day arithmetic."""
from __future__ import annotations

from datetime import date, datetime, timedelta
from typing import Any

TS_FORMAT = "%Y-%m-%d %H:%M"
_TEXT_FORMATS = ("%d-%m-%Y", "%d/%m/%Y", "%Y-%m-%d", "%d.%m.%Y", "%Y/%m/%d",
                 "%d-%b-%Y", "%d %b %Y", "%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S",
                 "%d-%m-%Y %H:%M", "%d/%m/%Y %H:%M")


def parse_date(value: Any) -> date | None:
    """Best-effort conversion of an Excel cell value to a date. Never raises."""
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        n = int(value)
        if 19000101 <= n <= 29991231:                     # 20261007
            try:
                return datetime.strptime(str(n), "%Y%m%d").date()
            except ValueError:
                return None
        if 1 <= n <= 80000:                               # Excel serial date
            return date(1899, 12, 30) + timedelta(days=n)
        return None
    text = str(value).strip()
    if not text:
        return None
    if text.isdigit() and len(text) == 8:
        try:
            return datetime.strptime(text, "%Y%m%d").date()
        except ValueError:
            return None
    for fmt in _TEXT_FORMATS:
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


def parse_ts(value: Any) -> datetime | None:
    if isinstance(value, datetime):
        return value
    if value is None or value == "":
        return None
    text = str(value).strip()
    for fmt in (TS_FORMAT, "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            continue
    d = parse_date(value)
    return datetime.combine(d, datetime.min.time()) if d else None


def now_ts() -> str:
    return datetime.now().strftime(TS_FORMAT)


def days_between(start: date | None, end: date, business: bool = True) -> int:
    """Days elapsed after `start` up to and including `end` (0 if same day or start is later)."""
    if start is None or start >= end:
        return 0
    if not business:
        return (end - start).days
    total = (end - start).days
    full_weeks, rest = divmod(total, 7)
    count = full_weeks * 5
    d = start
    for _ in range(rest):
        d += timedelta(days=1)
        if d.weekday() < 5:
            count += 1
    return count


def fmt_date(d: date | None) -> str | None:
    return d.isoformat() if d else None
