"""Excel-backed data store.

The break workbook is the single source of truth. This module:
  * reads it (cached until the file changes on disk),
  * appends the workflow columns (BF onwards) and the Audit_Log / Email_Log sheets,
  * writes changes safely: process lock + lock file, backup first, save to a temp
    file, atomic replace, retry when Excel/OneDrive holds the file.
"""
from __future__ import annotations

import hashlib
import logging
import os
import shutil
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import Any, Callable

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter

from .config import BASE_DIR, Config

log = logging.getLogger("scbmp.data")

WF_COLUMNS = [
    "Break ID", "Break Category", "Assigned Role", "Assigned To", "Workflow Status",
    "Assigned On", "Last Action On", "Last Action By", "Latest Comment",
    "Chaser Count", "Last Chaser On", "Closed On", "Closed By",
]
AUDIT_SHEET = "Audit_Log"
AUDIT_HEADERS = ["Timestamp", "Break ID", "User", "Action", "From Status", "To Status", "Comment"]
EMAIL_SHEET = "Email_Log"
EMAIL_HEADERS = ["Timestamp", "Recipient", "CC", "Break IDs", "Chaser Level", "Mode", "Subject"]

# Headers of the original report the app relies on (matched case-insensitively).
COL = {
    "maker": "Maker", "break_date": "BDZ1DATE", "region": "Region", "account": "Account number",
    "client_legal": "BDZ1NA1", "qty": "BDZ1QTY", "product": "BDZ1PROD", "exchange": "Exchange",
    "product_group": "Product Group", "client_name": "Client Name", "sdq_comment": "SDQ Comments",
    "team": "SDQ Team Responsible", "last_action": "Last action", "sdq_status": "SDQ STATUS",
}
KEY_FIELDS = ("account", "product", "break_date", "qty")   # duplicate detection on upload


class StoreError(Exception):
    """A data problem whose message is safe to show to the user."""


class FileLockedError(StoreError):
    pass


class ConflictError(StoreError):
    pass


def norm(h: Any) -> str:
    return str(h).strip().lower() if h is not None else ""


def json_safe(v: Any) -> Any:
    if isinstance(v, datetime):
        return v.strftime("%Y-%m-%d %H:%M") if (v.hour or v.minute) else v.date().isoformat()
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, float) and v.is_integer():
        return int(v)
    if isinstance(v, str):
        return v.strip()
    return v


@dataclass
class Break:
    row: int
    source: list            # [[column letter, header, value], ...] original columns
    fields: dict            # COL key -> value
    wf: dict                # WF column -> value

    @property
    def id(self) -> str | None:
        return self.wf.get("Break ID") or None


@dataclass
class Snapshot:
    headers: list
    original_count: int
    breaks: list = field(default_factory=list)
    audit: list = field(default_factory=list)
    emails: list = field(default_factory=list)
    mtime: float = 0.0

    def by_id(self, break_id: str) -> Break | None:
        key = (break_id or "").strip().upper()
        return next((b for b in self.breaks if (b.id or "").upper() == key), None)


def original_column_count(headers: list) -> int:
    """Original report columns = everything before the first workflow column."""
    wf = {norm(h) for h in WF_COLUMNS}
    for i, h in enumerate(headers):
        if norm(h) in wf:
            return i
    while headers and headers[-1] in (None, ""):
        headers = headers[:-1]
    return len(headers)


def build_col_index(headers: list, original_count: int) -> dict:
    """COL key -> 0-based column index (first occurrence within the original columns)."""
    idx = {}
    lookup = {}
    for i, h in enumerate(headers[:original_count]):
        lookup.setdefault(norm(h), i)
    for key, name in COL.items():
        if norm(name) in lookup:
            idx[key] = lookup[norm(name)]
    return idx


def row_key(fields: dict) -> str:
    parts = []
    for k in KEY_FIELDS:
        v = json_safe(fields.get(k))
        parts.append("" if v is None else str(v).strip().upper())
    return "|".join(parts)


class DataStore:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self._cache: Snapshot | None = None
        self._cache_key: tuple | None = None
        self._lock = threading.RLock()
        locks = BASE_DIR / "locks"
        locks.mkdir(exist_ok=True)
        digest = hashlib.md5(str(self.path).lower().encode()).hexdigest()[:10]
        self._lockfile = locks / f"workbook_{digest}.lock"

    # ------------------------------------------------------------ basics
    @property
    def path(self) -> Path:
        return self.cfg.excel_path

    @property
    def sheet_name(self) -> str:
        return self.cfg.data.get("sheet_name", "Sheet1")

    def _check_exists(self) -> None:
        if not self.path.exists():
            raise StoreError(f"The break file was not found at {self.path}. "
                             "Check data.excel_path in config.yaml.")

    def _sheet(self, wb):
        if self.sheet_name in wb.sheetnames:
            return wb[self.sheet_name]
        raise StoreError(f"Sheet '{self.sheet_name}' was not found in {self.path.name}. "
                         f"Sheets found: {', '.join(wb.sheetnames)}.")

    # ------------------------------------------------------------ reading
    def snapshot(self, force: bool = False) -> Snapshot:
        self._check_exists()
        st = self.path.stat()
        key = (st.st_mtime, st.st_size)
        with self._lock:
            if not force and self._cache is not None and self._cache_key == key:
                return self._cache
            snap = self._read()
            snap.mtime = st.st_mtime
            self._cache, self._cache_key = snap, key
            return snap

    def invalidate(self) -> None:
        with self._lock:
            self._cache, self._cache_key = None, None

    def _read(self) -> Snapshot:
        try:
            wb = load_workbook(self.path, read_only=True, data_only=True)
        except PermissionError:
            raise FileLockedError("The Excel file can't be read right now. Close it in Excel and try again.")
        except Exception as exc:  # corrupt / not an xlsx
            raise StoreError(f"Could not open {self.path.name}: {exc}")
        try:
            ws = self._sheet(wb)
            rows = ws.iter_rows(values_only=True)
            headers = list(next(rows, []) or [])
            if not headers:
                raise StoreError(f"Sheet '{self.sheet_name}' is empty.")
            orig = original_column_count(headers)
            col_idx = build_col_index(headers, orig)
            wf_idx = {norm(h): i for i, h in enumerate(headers)}
            snap = Snapshot(headers=headers, original_count=orig)
            letters = [get_column_letter(i + 1) for i in range(orig)]
            for r, values in enumerate(rows, start=2):
                values = list(values or [])
                if not any(v not in (None, "") for v in values[:orig]):
                    continue                                   # skip blank rows
                values += [None] * (len(headers) - len(values))
                source = [[letters[i], headers[i], json_safe(values[i])] for i in range(orig)]
                fields = {k: json_safe(values[i]) for k, i in col_idx.items()}
                wf = {}
                for name in WF_COLUMNS:
                    i = wf_idx.get(norm(name))
                    wf[name] = json_safe(values[i]) if i is not None and i < len(values) else None
                snap.breaks.append(Break(row=r, source=source, fields=fields, wf=wf))
            snap.audit = self._read_log(wb, AUDIT_SHEET, AUDIT_HEADERS)
            snap.emails = self._read_log(wb, EMAIL_SHEET, EMAIL_HEADERS)
            return snap
        finally:
            wb.close()

    @staticmethod
    def _read_log(wb, name: str, headers: list) -> list:
        if name not in wb.sheetnames:
            return []
        out = []
        for i, values in enumerate(wb[name].iter_rows(values_only=True)):
            if i == 0 or not values or all(v in (None, "") for v in values):
                continue
            out.append({h: json_safe(values[j]) if j < len(values) else None for j, h in enumerate(headers)})
        return out

    # ------------------------------------------------------------ writing
    @contextmanager
    def _file_lock(self, timeout: float = 30.0):
        start = time.time()
        while True:
            try:
                fd = os.open(self._lockfile, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.write(fd, str(os.getpid()).encode())
                os.close(fd)
                break
            except FileExistsError:
                try:   # stale lock (crashed process) older than 2 minutes
                    if time.time() - self._lockfile.stat().st_mtime > 120:
                        self._lockfile.unlink(missing_ok=True)
                        continue
                except OSError:
                    pass
                if time.time() - start > timeout:
                    raise FileLockedError("Another SCBMP process is updating the file. Try again in a moment.")
                time.sleep(0.2)
        try:
            yield
        finally:
            try:
                self._lockfile.unlink(missing_ok=True)
            except OSError:
                pass

    def backup(self) -> Path | None:
        if not self.path.exists():
            return None
        bdir = self.cfg.dir("backups_dir", "backups")
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
        target = bdir / f"{self.path.stem}_{stamp}{self.path.suffix}"
        shutil.copy2(self.path, target)
        keep = int(self.cfg.data.get("backups_keep", 20))
        olds = sorted(bdir.glob(f"{self.path.stem}_*{self.path.suffix}"), key=lambda p: p.stat().st_mtime)
        for p in olds[:-keep] if keep > 0 else []:
            try:
                p.unlink()
            except OSError:
                pass
        return target

    def _save(self, wb) -> None:
        tmp = self.path.with_name(f"~scbmp_tmp_{os.getpid()}_{self.path.name}")
        try:
            wb.save(tmp)
        except PermissionError:
            raise FileLockedError("Could not write a temporary file next to the Excel. Check folder permissions.")
        delays = [0, 3, 7]                    # 3 tries over ~10 seconds
        try:
            for i, delay in enumerate(delays):
                if delay:
                    time.sleep(delay)
                try:
                    os.replace(tmp, self.path)
                    return
                except PermissionError:
                    log.warning("Excel file locked, attempt %s of %s", i + 1, len(delays))
            raise FileLockedError("The Excel file is open elsewhere. Close it and click Retry.")
        finally:
            if tmp.exists():
                try:
                    tmp.unlink()
                except OSError:
                    pass

    def mutate(self, fn: Callable[["WorkbookEditor"], Any], backup: bool = True) -> Any:
        """Open the workbook for writing, let `fn` edit it through a WorkbookEditor, save safely."""
        self._check_exists()
        with self._lock, self._file_lock():
            if backup:
                self.backup()
            try:
                wb = load_workbook(self.path)
            except PermissionError:
                raise FileLockedError("The Excel file is open elsewhere. Close it and click Retry.")
            except Exception as exc:
                raise StoreError(f"Could not open {self.path.name} for writing: {exc}")
            editor = WorkbookEditor(wb, self._sheet(wb))
            result = fn(editor)
            if editor.dirty:
                self._save(wb)
            wb.close()
            self.invalidate()
            return result

    # ------------------------------------------------------------ misc
    def restore_sample(self) -> None:
        sample = self.cfg.sample_path
        if not sample.exists():
            raise StoreError(f"Sample file not found: {sample}")
        with self._lock, self._file_lock():
            self.backup()
            tmp = self.path.with_name(f"~scbmp_tmp_{self.path.name}")
            shutil.copyfile(sample, tmp)
            try:
                os.replace(tmp, self.path)
            except PermissionError:
                tmp.unlink(missing_ok=True)
                raise FileLockedError("The Excel file is open elsewhere. Close it and click Retry.")
            self.invalidate()


class WorkbookEditor:
    """Write helpers handed to DataStore.mutate callbacks."""

    def __init__(self, wb: Workbook, ws):
        self.wb = wb
        self.ws = ws
        self.dirty = False
        headers = [c.value for c in ws[1]] if ws.max_row >= 1 else []
        self.headers = headers
        self.original_count = original_column_count(list(headers))
        self.col_idx = build_col_index(list(headers), self.original_count)
        self._wf_cols: dict[str, int] = {}
        self._ensure_wf_columns()

    # ---- workflow columns
    def _ensure_wf_columns(self) -> None:
        existing = {norm(c.value): c.column for c in self.ws[1] if c.value not in (None, "")}
        next_col = self.original_count + 1
        # keep appending after the last used header
        used = [c.column for c in self.ws[1] if c.value not in (None, "")]
        if used:
            next_col = max(max(used) + 1, next_col)
        style_src = self.ws.cell(row=1, column=max(1, self.original_count))
        for name in WF_COLUMNS:
            if norm(name) in existing:
                self._wf_cols[name] = existing[norm(name)]
                continue
            cell = self.ws.cell(row=1, column=next_col, value=name)
            if style_src.has_style:
                cell._style = style_src._style
            self.ws.column_dimensions[get_column_letter(next_col)].width = 18 if name != "Latest Comment" else 40
            self._wf_cols[name] = next_col
            next_col += 1
            self.dirty = True

    def data_rows(self):
        """Yield row numbers that hold a break (non-blank original columns)."""
        for r in range(2, self.ws.max_row + 1):
            for c in range(1, self.original_count + 1):
                if self.ws.cell(row=r, column=c).value not in (None, ""):
                    yield r
                    break

    def get_field(self, row: int, key: str) -> Any:
        i = self.col_idx.get(key)
        return json_safe(self.ws.cell(row=row, column=i + 1).value) if i is not None else None

    def fields(self, row: int) -> dict:
        return {k: self.get_field(row, k) for k in self.col_idx}

    def row_text(self, row: int) -> str:
        vals = [self.ws.cell(row=row, column=c).value for c in range(1, self.original_count + 1)]
        return " | ".join(str(v) for v in vals if v not in (None, ""))

    def get_wf(self, row: int) -> dict:
        return {name: json_safe(self.ws.cell(row=row, column=col).value) for name, col in self._wf_cols.items()}

    def set_wf(self, row: int, updates: dict) -> None:
        for name, value in updates.items():
            if name not in self._wf_cols:
                raise KeyError(name)
            self.ws.cell(row=row, column=self._wf_cols[name], value=value)
        self.dirty = True

    def find_row(self, break_id: str) -> int | None:
        col = self._wf_cols["Break ID"]
        key = (break_id or "").strip().upper()
        for r in range(2, self.ws.max_row + 1):
            v = self.ws.cell(row=r, column=col).value
            if v and str(v).strip().upper() == key:
                return r
        return None

    def append_source_row(self, values: list) -> int:
        r = self.ws.max_row + 1
        for c, v in enumerate(values[: self.original_count], start=1):
            self.ws.cell(row=r, column=c, value=v)
        self.dirty = True
        return r

    # ---- logs
    def _log_sheet(self, name: str, headers: list):
        if name in self.wb.sheetnames:
            return self.wb[name]
        ws = self.wb.create_sheet(name)
        ws.append(headers)
        for i, h in enumerate(headers, start=1):
            ws.cell(row=1, column=i).font = Font(bold=True)
            ws.column_dimensions[get_column_letter(i)].width = 45 if h in ("Comment", "Subject", "Break IDs") else 18
        self.dirty = True
        return ws

    def audit(self, ts: str, break_id: str, user: str, action: str, from_status: str, to_status: str, comment: str) -> None:
        self._log_sheet(AUDIT_SHEET, AUDIT_HEADERS).append([ts, break_id, user, action, from_status, to_status, comment])
        self.dirty = True

    def email_log(self, ts: str, recipient: str, cc: str, break_ids: str, level: int, mode: str, subject: str) -> None:
        self._log_sheet(EMAIL_SHEET, EMAIL_HEADERS).append([ts, recipient, cc, break_ids, level, mode, subject])
        self.dirty = True

    def clear_logs(self) -> None:
        for name in (AUDIT_SHEET, EMAIL_SHEET):
            if name in self.wb.sheetnames:
                del self.wb[name]
                self.dirty = True
