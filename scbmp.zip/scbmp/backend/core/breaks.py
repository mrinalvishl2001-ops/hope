"""Turn raw workbook rows into the break records the UI shows, plus filtering."""
from __future__ import annotations

from datetime import date

from .config import Config
from .data_store import Break, Snapshot
from .dates import days_between, parse_date, parse_ts
from .workflow import CLOSED, OPEN_STATUSES


def _num(v) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def bucket_for(days: int, cfg: Config) -> str:
    for b in cfg.dashboard.get("aging_buckets", []):
        if b["min"] <= days <= b["max"]:
            return b["label"]
    return "15+"


def summarize(b: Break, cfg: Config, as_of: date) -> dict:
    f, wf = b.fields, b.wf
    business = bool(cfg.chasers.get("business_days", True))
    status = wf.get("Workflow Status") or ("Unassigned" if not b.id else "Unknown")
    is_open = status in OPEN_STATUSES
    break_date = parse_date(f.get("break_date"))
    assigned = parse_ts(wf.get("Assigned On"))
    last_action = parse_ts(wf.get("Last Action On")) or assigned
    closed_on = parse_date(wf.get("Closed On"))
    start = break_date or (assigned.date() if assigned else None)
    end = closed_on if (status == CLOSED and closed_on) else as_of
    aging = days_between(start, end, business)
    idle = days_between(last_action.date() if last_action else start, as_of, business) if is_open else 0
    overdue_after = int(cfg.dashboard.get("overdue_after_days", 5))
    return {
        "id": b.id, "row": b.row,
        "client": f.get("client_name") or f.get("client_legal") or "",
        "client_legal": f.get("client_legal") or "",
        "account": f.get("account") or "", "product": f.get("product") or "",
        "product_group": f.get("product_group") or "", "exchange": f.get("exchange") or "",
        "region": f.get("region") or "", "lots": _num(f.get("qty")),
        "maker": f.get("maker") or "",
        "break_date": break_date.isoformat() if break_date else None,
        "sdq_comment": f.get("sdq_comment") or "", "team": f.get("team") or "",
        "original_status": f.get("sdq_status") or "",
        "category": wf.get("Break Category") or "", "role": wf.get("Assigned Role") or "",
        "assigned_to": wf.get("Assigned To") or "", "status": status, "is_open": is_open,
        "assigned_on": wf.get("Assigned On"), "last_action_on": wf.get("Last Action On"),
        "last_action_by": wf.get("Last Action By"), "latest_comment": wf.get("Latest Comment") or "",
        "chaser_count": int(_num(wf.get("Chaser Count"))), "last_chaser_on": wf.get("Last Chaser On"),
        "closed_on": closed_on.isoformat() if closed_on else None, "closed_by": wf.get("Closed By"),
        "aging": aging, "aging_bucket": bucket_for(aging, cfg), "idle": idle,
        "overdue": is_open and idle >= overdue_after,
        "flagged": (wf.get("Break Category") or "").lower() == "unclassified",
        "is_exception": "exception" in str(f.get("team") or "").lower(),
    }


def all_summaries(snap: Snapshot, cfg: Config, as_of: date) -> list[dict]:
    return [summarize(b, cfg, as_of) for b in snap.breaks if b.id]


def apply_filters(items: list[dict], params: dict) -> list[dict]:
    q = (params.get("q") or "").strip().lower()
    out = []
    date_from = parse_date(params.get("date_from"))
    date_to = parse_date(params.get("date_to"))
    for it in items:
        if params.get("status") and it["status"] != params["status"]:
            if not (params["status"] == "Open" and it["is_open"]):
                continue
        if params.get("region") and it["region"] != params["region"]:
            continue
        if params.get("category") and it["category"] != params["category"]:
            continue
        if params.get("owner") and it["assigned_to"].lower() != params["owner"].lower():
            continue
        if params.get("aging") and it["aging_bucket"] != params["aging"]:
            continue
        if params.get("overdue") in ("1", "true", True) and not it["overdue"]:
            continue
        if params.get("exceptions") in ("1", "true", True) and not it["is_exception"]:
            continue
        if date_from or date_to:
            bd = parse_date(it["break_date"])
            if bd is None or (date_from and bd < date_from) or (date_to and bd > date_to):
                continue
        if q:
            hay = " ".join(str(it.get(k) or "") for k in
                           ("id", "client", "client_legal", "account", "product", "sdq_comment", "category", "assigned_to"))
            if q not in hay.lower():
                continue
        out.append(it)
    return out
