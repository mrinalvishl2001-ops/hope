"""Configuration loading. All paths resolve relative to the project root."""
from __future__ import annotations

import copy
import json
import os
from pathlib import Path
from typing import Any

import yaml

BASE_DIR = Path(__file__).resolve().parents[2]
CONFIG_FILE = BASE_DIR / "config.yaml"
RUNTIME_FILE = BASE_DIR / "runtime_settings.json"

# Settings the SDQ owner may change from the UI (stored in runtime_settings.json)
RUNTIME_KEYS = {"mode", "redirect_all_to"}


def resolve_path(value: str | os.PathLike) -> Path:
    """Expand ~ and %VARS% and make relative paths relative to the project root."""
    p = Path(os.path.expandvars(os.path.expanduser(str(value))))
    return p if p.is_absolute() else (BASE_DIR / p)


class Config:
    """Thin wrapper around config.yaml plus UI-editable runtime settings."""

    def __init__(self, path: Path = CONFIG_FILE, runtime_path: Path = RUNTIME_FILE):
        self.path = path
        self.runtime_path = runtime_path
        self.reload()

    def reload(self) -> None:
        with open(self.path, "r", encoding="utf-8") as fh:
            self.raw: dict[str, Any] = yaml.safe_load(fh) or {}
        self._validate()

    def _validate(self) -> None:
        for key in ("app", "data", "roles", "assignment", "chasers", "dashboard"):
            if key not in self.raw:
                raise ValueError(f"config.yaml is missing the '{key}' section")
        for role in ("SDQ", "CFMO", "AE"):
            if role not in self.raw["roles"]:
                raise ValueError(f"config.yaml roles: '{role}' is not mapped to a user")
        mode = self.chasers.get("mode", "draft")
        if mode not in ("preview", "draft", "live"):
            raise ValueError("config.yaml chasers.mode must be preview, draft or live")

    # ---- sections -------------------------------------------------------
    @property
    def app(self) -> dict:
        return self.raw["app"]

    @property
    def data(self) -> dict:
        return self.raw["data"]

    @property
    def roles(self) -> dict:
        return self.raw["roles"]

    @property
    def assignment(self) -> dict:
        return self.raw["assignment"]

    @property
    def dashboard(self) -> dict:
        return self.raw["dashboard"]

    @property
    def demo(self) -> dict:
        return self.raw.get("demo", {"allow_reset": False})

    @property
    def chasers(self) -> dict:
        merged = copy.deepcopy(self.raw["chasers"])
        merged.update(self.runtime_settings())
        return merged

    # ---- paths ------------------------------------------------------------
    @property
    def excel_path(self) -> Path:
        return resolve_path(self.data["excel_path"])

    @property
    def sample_path(self) -> Path:
        return resolve_path(self.data["sample_path"])

    @property
    def users_file(self) -> Path:
        return resolve_path(self.raw.get("users_file", "users.json"))

    def dir(self, key: str, default: str) -> Path:
        src = self.chasers if key == "outbox_dir" else self.data
        p = resolve_path(src.get(key, default))
        p.mkdir(parents=True, exist_ok=True)
        return p

    # ---- runtime settings -------------------------------------------------
    def runtime_settings(self) -> dict:
        if not self.runtime_path.exists():
            return {}
        try:
            with open(self.runtime_path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            return {k: v for k, v in data.items() if k in RUNTIME_KEYS}
        except (OSError, ValueError):
            return {}

    def save_runtime_settings(self, updates: dict) -> dict:
        current = self.runtime_settings()
        for k, v in updates.items():
            if k not in RUNTIME_KEYS:
                continue
            if k == "mode" and v not in ("preview", "draft", "live"):
                raise ValueError("Email mode must be preview, draft or live.")
            if k == "redirect_all_to":
                v = (v or "").strip()
                if v and "@" not in v:
                    raise ValueError("Redirect address must be an email address.")
            current[k] = v
        with open(self.runtime_path, "w", encoding="utf-8") as fh:
            json.dump(current, fh, indent=2)
        return current


_config: Config | None = None


def get_config() -> Config:
    global _config
    if _config is None:
        _config = Config()
    return _config


def set_config(cfg: Config) -> None:
    """Used by tests to point the app at a temporary config."""
    global _config
    _config = cfg
