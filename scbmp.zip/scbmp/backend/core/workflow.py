"""Workflow state machine: who may do what, and applying an action to a break."""
from __future__ import annotations

import hashlib
from dataclasses import dataclass

from .auth import User, UserStore
from .config import Config
from .data_store import ConflictError, DataStore, StoreError, WorkbookEditor
from .dates import now_ts

WITH_AE, WITH_SDQ, WITH_CFMO, CLOSED = "With AE", "With SDQ", "With CFMO", "Closed"
OPEN_STATUSES = (WITH_AE, WITH_SDQ, WITH_CFMO)
STATUS_ROLE = {WITH_AE: "AE", WITH_SDQ: "SDQ", WITH_CFMO: "CFMO"}
ROLE_STATUS = {v: k for k, v in STATUS_ROLE.items()}
MIN_COMMENT = 5


@dataclass(frozen=True)
class Action:
    key: str
    label: str
    role: str
    from_statuses: tuple
    to_status: str | None      # None = unchanged; "*" = chosen by the user (reassign)
    done_label: str            # wording for the toast
    tone: str = "primary"      # primary | secondary | danger


ACTIONS = [
    Action("comment", "Add comment", "*", OPEN_STATUSES, None, "Comment added", "secondary"),
    Action("send_to_sdq", "Send to SDQ for review", "AE", (WITH_AE,), WITH_SDQ, "sent to SDQ"),
    Action("send_to_cfmo", "Send to CFMO for closure", "SDQ", (WITH_SDQ,), WITH_CFMO, "sent to CFMO"),
    Action("send_to_ae", "Send back to AE", "SDQ", (WITH_SDQ,), WITH_AE, "sent back to AE", "secondary"),
    Action("send_back_to_sdq", "Send back to SDQ", "CFMO", (WITH_CFMO,), WITH_SDQ, "sent back to SDQ", "secondary"),
    Action("close", "Close break", "SDQ|CFMO", (WITH_SDQ, WITH_CFMO), CLOSED, "closed"),
    Action("reassign", "Reassign", "SDQ", OPEN_STATUSES, "*", "reassigned", "secondary"),
    Action("reopen", "Reopen", "SDQ", (CLOSED,), WITH_SDQ, "reopened", "secondary"),
]
ACTION_BY_KEY = {a.key: a for a in ACTIONS}


def version_of(wf: dict) -> str:
    """Changes whenever the break's workflow state changes; used to detect stale screens."""
    raw = "|".join(str(wf.get(k) or "") for k in ("Workflow Status", "Assigned To", "Last Action On", "Latest Comment"))
    return hashlib.sha1(raw.encode()).hexdigest()[:12]


def allowed_actions(user: User, wf: dict) -> list[Action]:
    status = wf.get("Workflow Status") or ""
    out = []
    for a in ACTIONS:
        if status not in a.from_statuses:
            continue
        if a.key == "comment":
            # the current owner (or the SDQ owner, who sees everything) may comment
            if user.role == STATUS_ROLE.get(status) or user.role == "SDQ":
                out.append(a)
            continue
        roles = a.role.split("|")
        if user.role not in roles:
            continue
        # SDQ/CFMO close only from their own queue
        if a.key == "close" and STATUS_ROLE.get(status) != user.role:
            continue
        out.append(a)
    return out


def can_view(user: User, wf: dict, involved: bool = False) -> bool:
    if user.role == "SDQ":
        return True
    if (wf.get("Assigned To") or "").lower() == user.username.lower() and wf.get("Workflow Status") in OPEN_STATUSES:
        return True
    return involved


def apply_action(store: DataStore, cfg: Config, users: UserStore, user: User, break_id: str,
                 action_key: str, comment: str, version: str | None = None,
                 target_role: str | None = None, checks: list | None = None) -> dict:
    action = ACTION_BY_KEY.get(action_key)
    if action is None:
        raise StoreError("Unknown action.")
    comment = (comment or "").strip()
    if len(comment) < MIN_COMMENT:
        raise StoreError(f"Please write a comment of at least {MIN_COMMENT} characters.")
    if checks:
        ticked = [str(c).strip() for c in checks if str(c).strip()]
        if ticked:
            comment = f"{comment} [{'; '.join(ticked)}]"

    def edit(ed: WorkbookEditor) -> dict:
        row = ed.find_row(break_id)
        if row is None:
            raise StoreError(f"Break {break_id} was not found. It may have been removed from the file.")
        wf = ed.get_wf(row)
        if version and version != version_of(wf):
            raise ConflictError("This break was updated by someone else since you opened it. "
                                "The latest version has been loaded; please review and try again.")
        if action not in allowed_actions(user, wf):
            raise StoreError("You can't do that on this break in its current status.")
        old_status = wf.get("Workflow Status") or ""
        ts = now_ts()
        updates = {"Last Action On": ts, "Last Action By": user.username,
                   "Latest Comment": comment, "Chaser Count": 0, "Last Chaser On": None}
        new_status = old_status
        if action.to_status == "*":
            if target_role not in ROLE_STATUS:
                raise StoreError("Choose who to reassign the break to.")
            new_status = ROLE_STATUS[target_role]
            if new_status == old_status:
                raise StoreError("The break is already with that team.")
        elif action.to_status:
            new_status = action.to_status
        if new_status != old_status:
            updates["Workflow Status"] = new_status
            if new_status == CLOSED:
                updates.update({"Closed On": ts[:10], "Closed By": user.username})
            else:
                role = STATUS_ROLE[new_status]
                owner = users.get_by_role(role, cfg.roles.get(role))
                if owner is None:
                    raise StoreError(f"No user has the {role} role.")
                updates.update({"Assigned To": owner.username, "Assigned Role": role,
                                "Assigned On": ts, "Closed On": None, "Closed By": None})
        ed.set_wf(row, updates)
        ed.audit(ts, break_id, user.username, action.label, old_status, new_status, comment)
        wf.update(updates)
        return {"break_id": break_id, "status": new_status, "message": f"{break_id} {action.done_label}"
                if action.key != "comment" else f"Comment added to {break_id}", "version": version_of(wf)}

    return store.mutate(edit)
