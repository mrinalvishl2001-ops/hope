"""Automated chasers: 1st reminder after N idle days, 2nd after +M days, then every day."""
from __future__ import annotations

import html as h
from datetime import date

from .auth import User, UserStore
from .breaks import all_summaries
from .config import Config
from .data_store import DataStore, WorkbookEditor
from .dates import now_ts, parse_ts
from .outlook_mail import deliver

RED, BLACK, INK, MUTED, BORDER, BG = "#E9041E", "#000000", "#1A1A1A", "#767676", "#E0E0E0", "#F5F5F5"


def level_for_idle(idle: int, cfg: Config) -> int:
    c = cfg.chasers
    first = int(c.get("first_after_days", 5))
    second = int(c.get("second_after_days", 2))
    every = max(1, int(c.get("then_every_days", 1)))
    if idle < first:
        return 0
    if idle < first + second:
        return 1
    return 2 + (idle - first - second) // every


def level_label(level: int) -> str:
    return {1: "1st reminder", 2: "2nd reminder"}.get(level, f"Daily reminder ({level})")


def due_breaks(items: list[dict], cfg: Config, as_of: date) -> list[dict]:
    out = []
    for it in items:
        if not it["is_open"]:
            continue
        level = level_for_idle(it["idle"], cfg)
        last = parse_ts(it.get("last_chaser_on"))
        if level == 0 or level <= it["chaser_count"] or (last and last.date() >= as_of):
            continue
        out.append({**it, "due_level": level})
    return out


def build_groups(items: list[dict], cfg: Config, users: UserStore, as_of: date) -> list[dict]:
    due = due_breaks(items, cfg, as_of)
    c = cfg.chasers
    sdq = users.get_by_role("SDQ", cfg.roles.get("SDQ"))
    groups: dict[str, dict] = {}
    for it in due:
        u = users.get(it["assigned_to"])
        if u is None:
            continue
        g = groups.setdefault(u.username, {"user": u, "breaks": []})
        g["breaks"].append(it)
    out = []
    for g in groups.values():
        u: User = g["user"]
        level = max(b["due_level"] for b in g["breaks"])
        cc = []
        if sdq and u.role != "SDQ" and level >= int(c.get("cc_sdq_from_level", 2)) and sdq.email:
            cc.append(sdq.email)
        mgr = (c.get("manager_email") or "").strip()
        if mgr and level >= int(c.get("manager_from_level", 5)):
            cc.append(mgr)
        max_idle = max(b["idle"] for b in g["breaks"])
        subject = make_subject(level, len(g["breaks"]), max_idle)
        redirect = (c.get("redirect_all_to") or "").strip()
        to_addr = redirect or u.email
        cc_addr = "" if redirect else "; ".join(cc)
        out.append({
            "username": u.username, "name": u.display_name, "email": u.email, "role": u.role,
            "to": to_addr, "cc": cc_addr, "intended_cc": "; ".join(cc), "redirected": bool(redirect),
            "level": level, "label": level_label(level), "subject": subject, "max_idle": max_idle,
            "breaks": sorted(g["breaks"], key=lambda b: -b["idle"]),
        })
    return sorted(out, key=lambda g: (-g["level"], g["name"]))


def make_subject(level: int, n: int, max_idle: int) -> str:
    noun = "commission break" if n == 1 else "commission breaks"
    verb = "awaits" if n == 1 else "awaiting"
    if level >= 3:
        return f"[Daily Reminder] {n} {noun} {verb} your action \u2014 no action for {max_idle} days | SCBMP"
    return f"[Action Required] {n} {noun} {verb} your action \u2014 Reminder {level} | SCBMP"


def render_email(group: dict, cfg: Config) -> str:
    level = group["level"]
    first_n = int(cfg.chasers.get("first_after_days", 5))
    unit = "business days" if cfg.chasers.get("business_days", True) else "days"
    if level == 1:
        opening = (f"The breaks below are assigned to you and have had no update for {first_n} {unit}. "
                   "Kindly review and action them in SCBMP.")
    elif level == 2:
        opening = "This is a second reminder. The breaks below still have no update. SDQ has been copied for visibility."
    else:
        opening = ("These breaks remain unactioned. Please action them today; a reminder will be sent every "
                   "business day until they are updated.")
    first_name = h.escape(group["name"].split()[0] if group["name"] else group["username"])
    url = h.escape(cfg.app.get("public_url", "http://localhost:8000"))
    banner = ""
    if group.get("redirected"):
        banner = (f'<tr><td style="padding:10px 24px;background:#FDE6E8;font:12px Segoe UI,Arial;color:{INK}">'
                  f'Demo redirect: originally to {h.escape(group["email"])}'
                  f'{" | cc " + h.escape(group["intended_cc"]) if group["intended_cc"] else ""}</td></tr>')
    th = (f'style="text-align:left;padding:8px 10px;border-bottom:2px solid {BLACK};'
          f'font:600 12px Segoe UI,Arial;color:{INK}"')
    rows = []
    for b in group["breaks"]:
        days_style = f"color:{RED};font-weight:700" if b["idle"] >= 10 else f"color:{INK}"
        lots = int(b["lots"]) if float(b["lots"]).is_integer() else b["lots"]
        cells = [b["id"], b["client"], b["account"], b["product"], lots, b["sdq_comment"],
                 (b["assigned_on"] or "")[:10]]
        tds = "".join(f'<td style="padding:8px 10px;border-bottom:1px solid {BORDER};font:12px Segoe UI,Arial;'
                      f'color:{INK};vertical-align:top{";white-space:nowrap;font-weight:600" if i == 0 else ""}">'
                      f'{h.escape(str(v))}</td>' for i, v in enumerate(cells))
        tds += (f'<td style="padding:8px 10px;border-bottom:1px solid {BORDER};font:12px Segoe UI,Arial;'
                f'{days_style};text-align:right">{b["idle"]}</td>')
        rows.append(f"<tr>{tds}</tr>")
    headers = ["Break ID", "Client name", "Account number", "Product", "Lots", "SDQ comment",
               "Assigned on", "Days without action"]
    head = "".join(f"<th {th}>{x}</th>" for x in headers)
    return f"""<!DOCTYPE html><html><body style="margin:0;padding:0;background:{BG}">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:{BG};padding:24px 0">
<tr><td align="center">
<table role="presentation" width="760" cellpadding="0" cellspacing="0" style="background:#FFFFFF;border:1px solid {BORDER}">
<tr><td style="height:4px;background:{RED};font-size:0;line-height:0">&nbsp;</td></tr>
<tr><td style="background:{BLACK};padding:18px 24px;font:600 16px Segoe UI,Arial;color:#FFFFFF">
Smart Commission Break Management Portal</td></tr>
{banner}
<tr><td style="padding:24px 24px 8px;font:14px Segoe UI,Arial;color:{INK}">Dear {first_name},</td></tr>
<tr><td style="padding:0 24px 16px;font:14px/1.5 Segoe UI,Arial;color:{INK}">{h.escape(opening)}</td></tr>
<tr><td style="padding:0 24px 8px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0">
<tr>{head}</tr>{''.join(rows)}</table></td></tr>
<tr><td style="padding:20px 24px">
<a href="{url}" style="display:inline-block;background:{RED};color:#FFFFFF;text-decoration:none;
font:600 14px Segoe UI,Arial;padding:10px 22px">Open SCBMP</a></td></tr>
<tr><td style="padding:16px 24px 24px;border-top:1px solid {BORDER};font:12px Segoe UI,Arial;color:{MUTED}">
This is an automated reminder from SCBMP. Please do not reply. For queries, contact SDQ.</td></tr>
</table></td></tr></table></body></html>"""


def plan(store: DataStore, cfg: Config, users: UserStore, as_of: date, with_html: bool = False) -> list[dict]:
    items = all_summaries(store.snapshot(), cfg, as_of)
    groups = build_groups(items, cfg, users, as_of)
    if with_html:
        for g in groups:
            g["html"] = render_email(g, cfg)
    return groups


def run(store: DataStore, cfg: Config, users: UserStore, as_of: date | None = None) -> dict:
    """Send today's chasers for real (in the configured mode) and record them."""
    as_of = as_of or date.today()
    groups = plan(store, cfg, users, as_of)
    mode = cfg.chasers.get("mode", "draft")
    outbox = cfg.dir("outbox_dir", "outbox")
    ts = now_ts()
    sent = []
    for g in groups:
        used = deliver(mode, g["to"], g["cc"], g["subject"], render_email(g, cfg), outbox)
        sent.append({"to": g["to"], "cc": g["cc"], "level": g["level"], "subject": g["subject"],
                     "mode": used, "breaks": [b["id"] for b in g["breaks"]],
                     "levels": {b["id"]: b["due_level"] for b in g["breaks"]}})

    if sent:
        def record(ed: WorkbookEditor):
            for s in sent:
                for bid, lvl in s["levels"].items():
                    row = ed.find_row(bid)
                    if row:
                        ed.set_wf(row, {"Chaser Count": lvl, "Last Chaser On": ts})
                ed.email_log(ts, s["to"], s["cc"], ", ".join(s["breaks"]), s["level"], s["mode"], s["subject"])
        store.mutate(record)
    for s in sent:
        s.pop("levels", None)
    return {"as_of": as_of.isoformat(), "mode": mode, "emails": sent, "count": len(sent)}
