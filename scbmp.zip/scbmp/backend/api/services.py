"""Shared singletons used by the API routes."""
from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler

from ..core.auth import LoginGuard, UserStore
from ..core.config import BASE_DIR, Config, get_config
from ..core.data_store import DataStore


class Services:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.store = DataStore(cfg)
        self.users = UserStore(cfg.users_file)
        self.guard = LoginGuard()


_services: Services | None = None


def get_services() -> Services:
    global _services
    if _services is None:
        _services = Services(get_config())
    return _services


def reset_services(cfg: Config | None = None) -> Services:
    global _services
    _services = Services(cfg or get_config())
    return _services


def setup_logging() -> None:
    logs = BASE_DIR / "logs"
    logs.mkdir(exist_ok=True)
    root = logging.getLogger("scbmp")
    if root.handlers:
        return
    root.setLevel(logging.INFO)
    fh = RotatingFileHandler(logs / "scbmp.log", maxBytes=2_000_000, backupCount=3, encoding="utf-8")
    fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    root.addHandler(fh)
    sh = logging.StreamHandler()
    sh.setFormatter(logging.Formatter("%(levelname)s %(name)s: %(message)s"))
    root.addHandler(sh)
