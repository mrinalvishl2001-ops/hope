"""All REST endpoints under /api."""
from __future__ import annotations

import io
import secrets
from datetime import date, datetime

from fastapi import APIRouter, Depends, File, HTTPException, Request, Response, UploadFile
from fastapi.responses import HTMLResponse, StreamingResponse
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from pydantic import BaseModel

from ..core import assignment, chasers, metrics
from ..core.auth import AuthError, User
from ..core.breaks import all_summaries, apply_filters, summarize
from ..core.data_store import StoreError
from ..core.dates import parse_date
from ..core.outlook_mail import outlook_available
from ..core.workflow import (ACTIONS, CLOSED, OPEN_STATUSES, STATUS_ROLE, allowed_actions, apply_action,
                             can_view, version_of)
from .deps import COOKIE, current_user, require_sdq, set_session_cookie
from .services import get_services

router = APIRouter(prefix="/api")
MAX_UPLOAD = 25 * 1024 * 1024


def _today() -> date:
    return date.today()


def _items():
    svc = get_services()
    snap = svc.store.snapshot()
    return snap, all_summaries(snap, svc.cfg, _today())


# ------------------------------------------------------------------ auth
class LoginBody(BaseModel):
    username: str
    password: str


@router.post("/auth/login")
def login(body: LoginBody, response: Response):
    svc = get_services()
    username = (body.username or "").strip()
    if not username or not body.password:
        raise HTTPException(400, "Enter your username and password.")
    try:
        svc.guard.check(username)
    except AuthError as exc:
        raise HTTPException(429, str(exc))
    user = svc.users.check_password(username, body.password)
    if user is None:
        left = svc.guard.failed(username)
        msg = "Username or password is incorrect."
        if left == 0:
            msg = "Too many failed attempts. This user is locked for 5 minutes."
        elif left <= 2:
            msg += f" {left} attempt(s) left before a 5-minute lock."
        raise HTTPException(401, msg)
    svc.guard.succeeded(username)
    set_session_cookie(response, user.username)
    return {"user": user.public()}


@router.post("/auth/logout")
def logout(response: Response):
    response.delete_cookie(COOKIE, path="/")
    return {"ok": True}


@router.get("/auth/me")
def me(user: User = Depends(current_user)):
    return {"user": user.public()}


@router.get("/health")
def health():
    svc = get_services()
    return {"ok": True, "excel": str(svc.cfg.excel_path), "excel_found": svc.cfg.excel_path.exists()}


# ------------------------------------------------------------------ meta
@router.get("/meta")
def meta(user: User = Depends(current_user)):
    svc = get_services()
    snap, items = _items()
    p = svc.cfg.excel_path
    return {
        "today": _today().isoformat(),
        "regions": sorted({i["region"] for i in items if i["region"]}),
        "categories": sorted({i["category"] for i in items if i["category"]}),
        "statuses": list(OPEN_STATUSES) + [CLOSED],
        "buckets": [b["label"] for b in svc.cfg.dashboard.get("aging_buckets", [])],
        "users": [u.public() for u in svc.users.all()],
        "file": {"name": p.name, "path": str(p),
                 "modified": datetime.fromtimestamp(snap.mtime).strftime("%Y-%m-%d %H:%M")},
        "unassigned": sum(1 for b in snap.breaks if not b.id),
    }


# ------------------------------------------------------------------ breaks
@router.get("/breaks")
def list_breaks(request: Request, scope: str = "mine", user: User = Depends(current_user)):
    svc = get_services()
    snap, items = _items()
    params = dict(request.query_params)
    if scope == "all":
        if user.role != "SDQ":
            raise HTTPException(403, "Only SDQ can see all breaks.")
        rows = items
    elif scope == "history":
        touched = {str(a.get("Break ID")) for a in snap.audit
                   if str(a.get("User") or "").lower() == user.username.lower()}
        rows = [i for i in items if i["id"] in touched and not (i["is_open"] and i["assigned_to"].lower() == user.username.lower())]
    else:
        rows = [i for i in items if i["is_open"] and i["assigned_to"].lower() == user.username.lower()]
    rows = apply_filters(rows, params)
    rows.sort(key=lambda i: (not i["is_open"], -i["aging"], i["id"]))
    return {"items": rows, "count": len(rows)}


@router.get("/breaks/export")
def export_breaks(request: Request, user: User = Depends(require_sdq)):
    _, items = _items()
    rows = apply_filters(items, dict(request.query_params))
    cols = [("Break ID", "id"), ("Client", "client"), ("Account number", "account"), ("Product", "product"),
            ("Product group", "product_group"), ("Region", "region"), ("Lots", "lots"),
            ("Break date", "break_date"), ("SDQ comment", "sdq_comment"), ("Category", "category"),
            ("Status", "status"), ("Assigned to", "assigned_to"), ("Aging (days)", "aging"),
            ("Days without action", "idle"), ("Last action on", "last_action_on"),
            ("Latest comment", "latest_comment"), ("Chaser count", "chaser_count"), ("Closed on", "closed_on")]
    wb = Workbook()
    ws = wb.active
    ws.title = "Breaks"
    ws.append([c[0] for c in cols])
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="000000")
    for r in rows:
        ws.append([r.get(k) for _, k in cols])
    for i, (name, _) in enumerate(cols, start=1):
        ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = max(12, len(name) + 4)
    ws.freeze_panes = "A2"
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    name = f"SCBMP_breaks_{datetime.now():%Y%m%d_%H%M}.xlsx"
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": f'attachment; filename="{name}"'})


def _detail(break_id: str, user: User) -> dict:
    svc = get_services()
    snap = svc.store.snapshot()
    b = snap.by_id(break_id)
    if b is None:
        raise HTTPException(404, f"Break {break_id} was not found.")
    events = [a for a in snap.audit if str(a.get("Break ID") or "").upper() == b.id.upper()]
    involved = any(str(a.get("User") or "").lower() == user.username.lower() for a in events)
    if not can_view(user, b.wf, involved):
        raise HTTPException(403, "This break isn't assigned to you.")
    item = summarize(b, svc.cfg, _today())
    timeline = [{"ts": a.get("Timestamp"), "user": a.get("User"), "action": a.get("Action"),
                 "from": a.get("From Status"), "to": a.get("To Status"), "comment": a.get("Comment")}
                for a in events]
    if not timeline and item["status"] == CLOSED:
        timeline = [{"ts": item["closed_on"], "user": "Import", "action": "Imported as closed",
                     "from": "", "to": CLOSED, "comment": item["sdq_comment"]}]
    acts = allowed_actions(user, b.wf)
    current_role = STATUS_ROLE.get(item["status"])
    return {
        "break": item, "source": [{"col": c, "header": h, "value": v} for c, h, v in b.source],
        "timeline": timeline, "version": version_of(b.wf),
        "actions": [{"key": a.key, "label": a.label, "tone": a.tone,
                     "needs_target": a.to_status == "*",
                     "targets": [r for r in ("AE", "SDQ", "CFMO") if r != current_role] if a.to_status == "*" else [],
                     "checks": ["Agreement updated", "Missing product added"] if a.key == "send_to_sdq" else []}
                    for a in acts],
    }


@router.get("/breaks/{break_id}")
def get_break(break_id: str, user: User = Depends(current_user)):
    return _detail(break_id, user)


class ActionBody(BaseModel):
    action: str
    comment: str = ""
    version: str | None = None
    target_role: str | None = None
    checks: list[str] = []


@router.post("/breaks/{break_id}/actions")
def act(break_id: str, body: ActionBody, user: User = Depends(current_user)):
    svc = get_services()
    result = apply_action(svc.store, svc.cfg, svc.users, user, break_id, body.action, body.comment,
                          body.version, body.target_role, body.checks)
    return result


@router.get("/inbox/summary")
def inbox_summary(user: User = Depends(current_user)):
    snap, items = _items()
    return metrics.inbox_summary(items, snap.audit, user.username, _today())


# ------------------------------------------------------------------ dashboard
@router.get("/dashboard")
def dashboard(request: Request, period: str = "day", user: User = Depends(require_sdq)):
    svc = get_services()
    snap, items = _items()
    params = {k: v for k, v in request.query_params.items() if k in ("region", "owner", "category", "date_from", "date_to")}
    rows = apply_filters(items, params)
    return metrics.dashboard(rows, snap.emails, svc.cfg, _today(), svc.users.all(),
                             period if period in ("day", "week", "month") else "day")


# ------------------------------------------------------------------ admin
@router.post("/admin/assign")
def run_assign(user: User = Depends(require_sdq)):
    svc = get_services()
    return assignment.run_assignment(svc.store, svc.cfg, svc.users).as_dict()


@router.post("/admin/upload/preview")
async def upload_preview(file: UploadFile = File(...), user: User = Depends(require_sdq)):
    svc = get_services()
    if not (file.filename or "").lower().endswith((".xlsx", ".xlsm")):
        raise HTTPException(400, "Upload an Excel .xlsx file.")
    data = await file.read()
    if len(data) > MAX_UPLOAD:
        raise HTTPException(400, "The file is larger than 25 MB.")
    token = secrets.token_hex(8)
    path = svc.cfg.dir("uploads_dir", "uploads") / f"{token}.xlsx"
    path.write_bytes(data)
    try:
        info = assignment.inspect_upload(path, svc.store, svc.cfg)
    except StoreError:
        path.unlink(missing_ok=True)
        raise
    preview = [{"account": r["fields"].get("account"), "client": r["fields"].get("client_name"),
                "product": r["fields"].get("product"), "lots": r["fields"].get("qty"),
                "sdq_comment": r["fields"].get("sdq_comment"), "category": r["category"],
                "role": r["role"], "status": r["status"]} for r in info["rows"][:50]]
    return {"token": token, "filename": file.filename, "rows_in_file": info["rows_in_file"],
            "new": info["new"], "duplicates": info["duplicates"], "preview": preview}


class CommitBody(BaseModel):
    token: str


@router.post("/admin/upload/commit")
def upload_commit(body: CommitBody, user: User = Depends(require_sdq)):
    svc = get_services()
    if not body.token.isalnum():
        raise HTTPException(400, "Invalid upload reference.")
    path = svc.cfg.dir("uploads_dir", "uploads") / f"{body.token}.xlsx"
    if not path.exists():
        raise HTTPException(400, "That upload has expired. Please upload the file again.")
    try:
        return assignment.commit_upload(path, svc.store, svc.cfg, svc.users)
    finally:
        path.unlink(missing_ok=True)


@router.post("/admin/demo-reset")
def demo_reset(user: User = Depends(require_sdq)):
    svc = get_services()
    if not svc.cfg.demo.get("allow_reset", False):
        raise HTTPException(403, "Demo reset is switched off in config.yaml (demo.allow_reset).")
    svc.store.restore_sample()
    res = assignment.run_assignment(svc.store, svc.cfg, svc.users)
    return {"message": "Sample data restored and reassigned.", "assignment": res.as_dict()}


# ------------------------------------------------------------------ chasers
def _as_of(value: str | None) -> date:
    if not value:
        return _today()
    d = parse_date(value)
    if d is None:
        raise HTTPException(400, "Use the date format YYYY-MM-DD.")
    return d


@router.get("/chasers/plan")
def chaser_plan(as_of: str | None = None, user: User = Depends(require_sdq)):
    svc = get_services()
    d = _as_of(as_of)
    groups = chasers.plan(svc.store, svc.cfg, svc.users, d)
    for g in groups:
        g["breaks"] = [{k: b[k] for k in ("id", "client", "account", "product", "lots", "sdq_comment",
                                          "idle", "due_level", "assigned_on")} for b in g["breaks"]]
    return {"as_of": d.isoformat(), "simulated": d != _today(), "mode": svc.cfg.chasers.get("mode"),
            "outlook": outlook_available(), "groups": groups}


@router.get("/chasers/preview", response_class=HTMLResponse)
def chaser_preview(username: str, as_of: str | None = None, user: User = Depends(require_sdq)):
    svc = get_services()
    d = _as_of(as_of)
    for g in chasers.plan(svc.store, svc.cfg, svc.users, d):
        if g["username"].lower() == username.lower():
            return HTMLResponse(chasers.render_email(g, svc.cfg))
    raise HTTPException(404, "No chaser is due for that user on this date.")


@router.post("/chasers/run")
def chaser_run(user: User = Depends(require_sdq)):
    svc = get_services()
    return chasers.run(svc.store, svc.cfg, svc.users, _today())


@router.get("/chasers/log")
def chaser_log(user: User = Depends(require_sdq)):
    snap = get_services().store.snapshot()
    return {"items": list(reversed(snap.emails))[:500]}


# ------------------------------------------------------------------ audit & settings
@router.get("/audit")
def audit(user_filter: str = "", action: str = "", q: str = "", user: User = Depends(require_sdq)):
    snap = get_services().store.snapshot()
    out = []
    for a in reversed(snap.audit):
        if user_filter and str(a.get("User") or "").lower() != user_filter.lower():
            continue
        if action and str(a.get("Action") or "") != action:
            continue
        if q and q.lower() not in " ".join(str(v or "") for v in a.values()).lower():
            continue
        out.append(a)
    actions = sorted({str(a.get("Action")) for a in snap.audit if a.get("Action")})
    return {"items": out[:1000], "total": len(out), "actions": actions}


@router.get("/settings")
def get_settings(user: User = Depends(require_sdq)):
    svc = get_services()
    c = svc.cfg.chasers
    return {
        "mode": c.get("mode"), "redirect_all_to": c.get("redirect_all_to") or "",
        "outlook": outlook_available(),
        "chasers": {k: c.get(k) for k in ("business_days", "first_after_days", "second_after_days",
                                          "then_every_days", "cc_sdq_from_level", "manager_email",
                                          "manager_from_level")},
        "rules": svc.cfg.assignment.get("rules", []), "fallback": svc.cfg.assignment.get("fallback", {}),
        "roles": svc.cfg.roles, "excel_path": str(svc.cfg.excel_path),
        "allow_reset": bool(svc.cfg.demo.get("allow_reset", False)),
        "aging_buckets": svc.cfg.dashboard.get("aging_buckets", []),
    }


class SettingsBody(BaseModel):
    mode: str | None = None
    redirect_all_to: str | None = None


@router.put("/settings")
def put_settings(body: SettingsBody, user: User = Depends(require_sdq)):
    svc = get_services()
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    try:
        svc.cfg.save_runtime_settings(updates)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return get_settings(user)
