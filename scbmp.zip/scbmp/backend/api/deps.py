"""Request dependencies: current user and role checks."""
from __future__ import annotations

import time

from fastapi import Depends, HTTPException, Request, Response

from ..core.auth import User, make_token, read_token
from .services import get_services

COOKIE = "scbmp_session"


def set_session_cookie(response: Response, username: str, issued: float | None = None) -> None:
    cfg = get_services().cfg
    response.set_cookie(COOKIE, make_token(username, issued, time.time()), httponly=True, samesite="lax",
                        max_age=int(float(cfg.app.get("session_hours", 8)) * 3600), path="/")


def current_user(request: Request, response: Response) -> User:
    svc = get_services()
    token = request.cookies.get(COOKIE)
    info = read_token(token, float(svc.cfg.app.get("session_hours", 8)),
                      float(svc.cfg.app.get("idle_minutes", 30))) if token else None
    if not info:
        raise HTTPException(status_code=401, detail="Your session has ended. Please sign in again.")
    user = svc.users.get(info[0])
    if user is None:
        raise HTTPException(status_code=401, detail="This user no longer exists.")
    set_session_cookie(response, user.username, info[1])      # sliding idle timeout
    return user


def require_sdq(user: User = Depends(current_user)) -> User:
    if user.role != "SDQ":
        raise HTTPException(status_code=403, detail="Only the SDQ application owner can open this page.")
    return user
