"""SCBMP web server: REST API under /api plus the pre-built React app."""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .api.routes import router
from .api.services import get_services, setup_logging
from .core.auth import AuthError
from .core.config import BASE_DIR
from .core.data_store import ConflictError, FileLockedError, StoreError

setup_logging()
log = logging.getLogger("scbmp.api")
DIST = BASE_DIR / "frontend" / "dist"



def _startup() -> None:
    svc = get_services()
    log.info("SCBMP started. Excel: %s", svc.cfg.excel_path)
    try:
        snap = svc.store.snapshot()
        if any(not b.id for b in snap.breaks):
            from .core.assignment import run_assignment
            res = run_assignment(svc.store, svc.cfg, svc.users)
            log.info("Assigned %s new break(s) on startup", res.newly_assigned)
    except StoreError as exc:
        log.error("Could not load the break file: %s", exc)


@asynccontextmanager
async def lifespan(_: FastAPI):
    _startup()
    yield


app = FastAPI(title="SCBMP API", version="1.0", docs_url="/api/docs", openapi_url="/api/openapi.json",
              redoc_url=None, lifespan=lifespan)
app.include_router(router)


@app.exception_handler(FileLockedError)
async def _locked(_: Request, exc: FileLockedError):
    return JSONResponse(status_code=423, content={"detail": str(exc), "retry": True})


@app.exception_handler(ConflictError)
async def _conflict(_: Request, exc: ConflictError):
    return JSONResponse(status_code=409, content={"detail": str(exc)})


@app.exception_handler(StoreError)
async def _store(_: Request, exc: StoreError):
    return JSONResponse(status_code=400, content={"detail": str(exc)})


@app.exception_handler(AuthError)
async def _auth(_: Request, exc: AuthError):
    return JSONResponse(status_code=401, content={"detail": str(exc)})


@app.exception_handler(RequestValidationError)
async def _validation(_: Request, exc: RequestValidationError):
    return JSONResponse(status_code=422, content={"detail": "Some information is missing or in the wrong format."})


@app.exception_handler(Exception)
async def _unexpected(request: Request, exc: Exception):
    if isinstance(exc, HTTPException):
        return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})
    log.exception("Unexpected error on %s", request.url.path)
    return JSONResponse(status_code=500, content={"detail": "Something went wrong on the server. "
                                                            "Details were written to logs/scbmp.log."})


@app.get("/brand/logo.png", include_in_schema=False)
def logo():
    p = BASE_DIR / "assets" / "logo.png"
    if p.exists():
        return FileResponse(p)
    raise HTTPException(404, "No logo")


if (DIST / "assets").exists():
    app.mount("/assets", StaticFiles(directory=DIST / "assets"), name="assets")

_MISSING = """<html><body style="font-family:Segoe UI,Arial;padding:40px">
<h2>SCBMP front end not built</h2><p>The folder <code>frontend/dist</code> is missing.
Run <code>build_frontend.bat</code> (needs Node.js) or copy the <code>dist</code> folder from the zip.</p>
<p>The API is running: <a href="/api/docs">/api/docs</a></p></body></html>"""


@app.get("/{full_path:path}", include_in_schema=False)
def spa(full_path: str):
    if full_path.startswith("api/"):
        raise HTTPException(404, "Not found")
    candidate = (DIST / full_path).resolve()
    if full_path and candidate.is_file() and DIST.resolve() in candidate.parents:
        return FileResponse(candidate)
    index = DIST / "index.html"
    if index.exists():
        return FileResponse(index, headers={"Cache-Control": "no-cache"})
    return HTMLResponse(_MISSING)
