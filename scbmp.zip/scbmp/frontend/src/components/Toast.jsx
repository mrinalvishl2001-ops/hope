import { createContext, useCallback, useContext, useState } from 'react'
import { CheckCircle2, AlertTriangle, X } from 'lucide-react'

const ToastCtx = createContext(() => {})

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([])
  const push = useCallback((message, tone = 'success') => {
    const id = Math.random().toString(36).slice(2)
    setToasts((t) => [...t, { id, message, tone }])
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), tone === 'error' ? 7000 : 4000)
  }, [])
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="fixed top-16 right-4 z-[60] flex flex-col gap-2 w-[360px]" role="status" aria-live="polite">
        {toasts.map((t) => (
          <div key={t.id} className="animate-slidein bg-white border border-sg-border shadow-pop rounded flex items-start gap-3 p-3 pr-2">
            <div className={`w-1 self-stretch rounded ${t.tone === 'error' ? 'bg-sg-red' : 'bg-sg-closed'}`} />
            {t.tone === 'error'
              ? <AlertTriangle size={18} className="text-sg-red mt-0.5 shrink-0" />
              : <CheckCircle2 size={18} className="text-sg-closed mt-0.5 shrink-0" />}
            <p className="text-sm text-sg-ink flex-1">{t.message}</p>
            <button className="text-sg-muted hover:text-sg-ink p-1" onClick={() => setToasts((x) => x.filter((y) => y.id !== t.id))} aria-label="Dismiss">
              <X size={14} />
            </button>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  )
}

export const useToast = () => useContext(ToastCtx)
