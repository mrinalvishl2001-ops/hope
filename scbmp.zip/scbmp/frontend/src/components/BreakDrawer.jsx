import { useEffect, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import clsx from 'clsx'
import { ChevronDown, ChevronRight, X, Clock, MessageSquare } from 'lucide-react'
import { api, fmt } from '../api'
import { useAuth } from '../auth'
import { useToast } from './Toast'
import { AgingPill, Avatar, ErrorNote, FlagIcon, StatusPill } from './ui'

const TARGET_LABEL = { AE: 'Account Executive', SDQ: 'SDQ', CFMO: 'CFMO' }

export default function BreakDrawer({ id, onClose }) {
  const qc = useQueryClient()
  const toast = useToast()
  const { user } = useAuth()
  const [showAll, setShowAll] = useState(false)
  const [action, setAction] = useState(null)
  const [comment, setComment] = useState('')
  const [target, setTarget] = useState('')
  const [checks, setChecks] = useState([])
  const [error, setError] = useState(null)

  const q = useQuery({ queryKey: ['break', id], queryFn: () => api.get(`/api/breaks/${encodeURIComponent(id)}`), enabled: !!id })

  useEffect(() => {
    setAction(null); setComment(''); setTarget(''); setChecks([]); setError(null); setShowAll(false)
  }, [id])

  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose])

  const mut = useMutation({
    mutationFn: () => api.post(`/api/breaks/${encodeURIComponent(id)}/actions`, {
      action: action.key, comment, version: q.data?.version, target_role: target || null, checks,
    }),
    onSuccess: (res) => {
      toast(res.message)
      setAction(null); setComment(''); setTarget(''); setChecks([]); setError(null)
      ;['breaks', 'inbox', 'dashboard', 'meta', 'history', 'chasers'].forEach((k) => qc.invalidateQueries({ queryKey: [k] }))
      qc.invalidateQueries({ queryKey: ['break', id] })
    },
    onError: (e) => {
      setError(e)
      if (e.status === 409) qc.invalidateQueries({ queryKey: ['break', id] })
    },
  })

  if (!id) return null
  const d = q.data
  const b = d?.break
  const commentOk = comment.trim().length >= 5
  const needsTarget = action?.needs_target
  const canSubmit = action && commentOk && (!needsTarget || target) && !mut.isPending

  return (
    <div className="fixed inset-0 z-40" aria-modal="true" role="dialog" aria-label={`Break ${id}`}>
      <div className="absolute inset-0 bg-black/25" onClick={onClose} />
      <aside className="absolute right-0 top-0 bottom-0 w-full max-w-[600px] bg-white shadow-drawer flex flex-col animate-slidein">
        <div className="h-1 bg-sg-red shrink-0" />
        <header className="px-6 pt-4 pb-4 border-b border-sg-border shrink-0">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-xs text-sg-muted">Break</p>
              <h2 className="text-[22px] font-semibold text-sg-ink num leading-tight">{id}</h2>
            </div>
            <button className="btn-ghost h-8 px-2" onClick={onClose} aria-label="Close"><X size={18} /></button>
          </div>
          {b && (
            <div className="flex flex-wrap items-center gap-2 mt-3">
              <StatusPill status={b.status} />
              <AgingPill days={b.aging} bucket={b.aging_bucket} overdue={b.overdue} />
              {b.flagged && <span className="text-xs text-sg-red flex items-center gap-1"><FlagIcon /> Needs manual review</span>}
              <span className="ml-auto flex items-center gap-2 text-sm text-sg-ink">
                {b.is_open ? <><Avatar name={b.assigned_to} size={24} /> {b.assigned_to}</> : <span className="text-sg-muted">Closed {fmt.date(b.closed_on)}</span>}
              </span>
            </div>
          )}
        </header>

        <div className="flex-1 overflow-y-auto">
          {q.isLoading && <div className="p-6 space-y-3">{[...Array(8)].map((_, i) => <div key={i} className="skeleton h-6" />)}</div>}
          {q.error && <div className="p-6"><ErrorNote error={q.error} onRetry={() => q.refetch()} /></div>}
          {b && (
            <div className="p-6 space-y-6">
              <section>
                <div className="border-l-[3px] border-sg-ink pl-3">
                  <p className="text-xs text-sg-muted">SDQ comment</p>
                  <p className="text-sm text-sg-ink mt-0.5">{b.sdq_comment || '—'}</p>
                </div>
                <dl className="grid grid-cols-2 gap-x-6 gap-y-3 mt-5">
                  {[
                    ['Client', b.client], ['Account number', b.account], ['Product', b.product],
                    ['Product group', b.product_group], ['Exchange', b.exchange], ['Lots', fmt.num(b.lots)],
                    ['Region', b.region], ['Break date', fmt.date(b.break_date)], ['Category', b.category],
                    ['SDQ team responsible', b.team], ['Days without action', b.is_open ? b.idle : '—'], ['Chasers sent', b.chaser_count],
                  ].map(([k, v]) => (
                    <div key={k}>
                      <dt className="text-xs text-sg-muted">{k}</dt>
                      <dd className="text-sm text-sg-ink mt-0.5 break-words">{v === '' || v === null || v === undefined ? '—' : v}</dd>
                    </div>
                  ))}
                </dl>
              </section>

              <section>
                <button className="flex items-center gap-1.5 text-sm font-semibold text-sg-ink hover:text-sg-red" onClick={() => setShowAll((s) => !s)} aria-expanded={showAll}>
                  {showAll ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                  All source fields ({d.source.length})
                </button>
                {showAll && (
                  <div className="mt-3 border border-sg-border rounded max-h-72 overflow-y-auto">
                    <table className="w-full text-xs">
                      <tbody>
                        {d.source.map((f, i) => (
                          <tr key={i} className="border-b border-sg-border last:border-0">
                            <td className="px-2 py-1.5 text-sg-muted num w-10">{f.col}</td>
                            <td className="px-2 py-1.5 text-sg-muted w-44">{f.header}</td>
                            <td className="px-2 py-1.5 text-sg-ink break-all">{f.value === null || f.value === '' ? '—' : String(f.value)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </section>

              <section>
                <h3 className="text-sm font-semibold text-sg-ink mb-3">History</h3>
                <ol className="relative ml-2">
                  {[...d.timeline].reverse().map((t, i) => (
                    <li key={i} className="relative pl-6 pb-5 last:pb-0">
                      <span className="absolute left-0 top-1.5 w-2.5 h-2.5 -translate-x-1/2 rounded-full border-2 border-white"
                        style={{ backgroundColor: i === 0 ? '#E9041E' : '#1A1A1A', boxShadow: '0 0 0 1px #E0E0E0' }} />
                      {i < d.timeline.length - 1 && <span className="absolute left-0 top-4 bottom-0 w-px bg-sg-border" />}
                      <div className="flex flex-wrap items-baseline gap-x-2">
                        <span className="text-sm font-semibold text-sg-ink">{t.action}</span>
                        <span className="text-xs text-sg-muted">by {t.user}</span>
                        <span className="text-xs text-sg-muted ml-auto flex items-center gap-1"><Clock size={11} />{fmt.datetime(t.ts)}</span>
                      </div>
                      {t.from !== t.to && t.to && <p className="text-xs text-sg-muted mt-0.5">{t.from || 'New'} → {t.to}</p>}
                      {t.comment && <p className="text-sm text-sg-text mt-1 bg-sg-bg rounded px-3 py-2">{t.comment}</p>}
                    </li>
                  ))}
                </ol>
              </section>
            </div>
          )}
        </div>

        {b && (
          <footer className="border-t border-sg-border p-4 bg-white shrink-0">
            {d.actions.length === 0 ? (
              <p className="text-sm text-sg-muted flex items-center gap-2"><MessageSquare size={15} />
                {b.is_open ? `This break is with ${b.assigned_to}. You can view it but not act on it.` : 'This break is closed and read-only.'}
              </p>
            ) : !action ? (
              <div className="flex flex-wrap gap-2">
                {d.actions.map((a) => (
                  <button key={a.key} onClick={() => { setAction(a); setError(null) }}
                    className={a.tone === 'primary' ? 'btn-primary' : 'btn-secondary'}>{a.label}</button>
                ))}
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold text-sg-ink">{action.label}</p>
                  <button className="text-xs text-sg-muted hover:text-sg-ink" onClick={() => { setAction(null); setError(null) }}>Choose another action</button>
                </div>
                {needsTarget && (
                  <div className="flex gap-2">
                    {action.targets.map((t) => (
                      <button key={t} onClick={() => setTarget(t)}
                        className={clsx('btn-secondary h-8 text-xs', target === t && '!border-sg-ink !bg-sg-ink !text-white')}>
                        {TARGET_LABEL[t]}
                      </button>
                    ))}
                  </div>
                )}
                {action.checks.length > 0 && (
                  <div className="flex flex-wrap gap-4">
                    {action.checks.map((c) => (
                      <label key={c} className="flex items-center gap-2 text-sm text-sg-ink cursor-pointer">
                        <input type="checkbox" className="accent-[#E9041E] w-4 h-4" checked={checks.includes(c)}
                          onChange={(e) => setChecks((s) => e.target.checked ? [...s, c] : s.filter((x) => x !== c))} />
                        {c}
                      </label>
                    ))}
                  </div>
                )}
                <div>
                  <textarea className="input h-24 py-2 resize-none" placeholder="Add a comment (required)"
                    value={comment} onChange={(e) => setComment(e.target.value)} autoFocus maxLength={1000} />
                  <p className={clsx('text-xs mt-1', commentOk || !comment ? 'text-sg-muted' : 'text-sg-red')}>
                    {commentOk ? `${comment.trim().length} characters` : 'At least 5 characters'}
                  </p>
                </div>
                {error && <ErrorNote error={error} onRetry={error.status === 423 ? () => mut.mutate() : undefined} />}
                <div className="flex justify-end gap-2">
                  <button className="btn-secondary" onClick={() => { setAction(null); setError(null) }}>Cancel</button>
                  <button className="btn-primary" disabled={!canSubmit} onClick={() => mut.mutate()}>
                    {mut.isPending ? 'Saving…' : action.label}
                  </button>
                </div>
              </div>
            )}
            {user && b.is_open && d.actions.length > 0 && !action && (
              <p className="text-xs text-sg-muted mt-2">Every action needs a comment and is saved to the Excel audit log.</p>
            )}
          </footer>
        )}
      </aside>
    </div>
  )
}
