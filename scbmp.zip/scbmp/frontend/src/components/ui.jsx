import clsx from 'clsx'
import { AlertTriangle, Inbox, Flag } from 'lucide-react'
import { agingColor, statusColor } from '../theme'

export function StatusPill({ status }) {
  const c = statusColor[status] || '#767676'
  return (
    <span className="inline-flex items-center gap-1.5 h-6 px-2 rounded text-xs font-semibold whitespace-nowrap"
      style={{ color: c, backgroundColor: `${c}14`, border: `1px solid ${c}40` }}>
      <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: c }} />
      {status}
    </span>
  )
}

export function AgingPill({ days, bucket, overdue }) {
  const c = agingColor[bucket] || '#767676'
  return (
    <span className="inline-flex items-center gap-1 h-6 px-2 rounded text-xs font-semibold num whitespace-nowrap"
      style={{ color: '#fff', backgroundColor: c }} title={overdue ? 'Overdue: no action for 5+ business days' : undefined}>
      {overdue && <AlertTriangle size={11} />}
      {days}d
    </span>
  )
}

export function FlagIcon() {
  return <Flag size={13} className="text-sg-red inline" aria-label="Needs manual review" />
}

export function Avatar({ name, size = 28 }) {
  const initials = (name || '?').replace(/[^A-Za-z]/g, '').slice(0, 2).toUpperCase() || '?'
  return (
    <span className="inline-flex items-center justify-center rounded-full bg-sg-ink text-white font-semibold shrink-0"
      style={{ width: size, height: size, fontSize: size * 0.38 }}>{initials}</span>
  )
}

export function Card({ title, subtitle, actions, children, className, bodyClass }) {
  return (
    <section className={clsx('card', className)}>
      {(title || actions) && (
        <header className="flex items-start justify-between gap-4 px-5 pt-4 pb-3">
          <div>
            {title && <h2 className="text-[15px] font-semibold text-sg-ink">{title}</h2>}
            {subtitle && <p className="text-xs text-sg-muted mt-0.5">{subtitle}</p>}
          </div>
          {actions}
        </header>
      )}
      <div className={clsx(bodyClass ?? 'px-5 pb-5')}>{children}</div>
    </section>
  )
}

export function KpiCard({ label, value, hint, tone, onClick, loading }) {
  const Tag = onClick ? 'button' : 'div'
  return (
    <Tag onClick={onClick}
      className={clsx('card text-left p-4 flex flex-col gap-1 min-h-[96px] relative overflow-hidden',
        onClick && 'hover:border-sg-ink transition-colors')}>
      {tone === 'alert' && <span className="absolute left-0 top-0 bottom-0 w-[3px] bg-sg-red" />}
      <span className="text-[13px] text-sg-muted">{label}</span>
      {loading ? <span className="skeleton h-8 w-20 mt-1" />
        : <span className={clsx('text-[28px] leading-tight font-semibold num', tone === 'alert' ? 'text-sg-red' : 'text-sg-ink')}>{value}</span>}
      {hint && <span className="text-xs text-sg-muted mt-auto">{hint}</span>}
    </Tag>
  )
}

export function EmptyState({ title, text, icon: Icon = Inbox, action }) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-14 px-6">
      <div className="w-12 h-12 rounded-full bg-sg-bg flex items-center justify-center mb-3">
        <Icon size={22} className="text-sg-muted" />
      </div>
      <p className="text-[15px] font-semibold text-sg-ink">{title}</p>
      {text && <p className="text-sm text-sg-muted mt-1 max-w-sm">{text}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  )
}

export function ErrorNote({ error, onRetry }) {
  if (!error) return null
  return (
    <div className="flex items-start gap-3 border border-sg-red/40 bg-sg-tint rounded p-3 text-sm text-sg-ink" role="alert">
      <AlertTriangle size={18} className="text-sg-red shrink-0 mt-0.5" />
      <p className="flex-1">{error.message || String(error)}</p>
      {onRetry && <button className="btn-secondary h-8" onClick={onRetry}>Retry</button>}
    </div>
  )
}

export function Select({ value, onChange, options, placeholder, className, ...rest }) {
  return (
    <select value={value ?? ''} onChange={(e) => onChange(e.target.value)} className={clsx('input pr-8 cursor-pointer', className)} {...rest}>
      {placeholder !== undefined && <option value="">{placeholder}</option>}
      {options.map((o) => typeof o === 'string'
        ? <option key={o} value={o}>{o}</option>
        : <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  )
}

export function PageHeader({ title, subtitle, actions }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4 mb-5">
      <div>
        <h1 className="text-[22px] font-semibold text-sg-ink leading-tight">{title}</h1>
        {subtitle && <p className="text-sm text-sg-muted mt-1">{subtitle}</p>}
      </div>
      {actions && <div className="flex items-center gap-2 flex-wrap">{actions}</div>}
    </div>
  )
}

export function Modal({ open, title, children, onClose, footer, wide }) {
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onMouseDown={onClose}>
      <div role="dialog" aria-modal="true" aria-label={title}
        className={clsx('bg-white rounded shadow-pop w-full animate-slidein', wide ? 'max-w-4xl' : 'max-w-md')}
        onMouseDown={(e) => e.stopPropagation()}>
        <div className="h-1 bg-sg-red rounded-t" />
        <div className="px-5 pt-4 pb-2"><h3 className="text-base font-semibold text-sg-ink">{title}</h3></div>
        <div className="px-5 pb-4 text-sm text-sg-text">{children}</div>
        {footer && <div className="px-5 py-3 border-t border-sg-border flex justify-end gap-2">{footer}</div>}
      </div>
    </div>
  )
}

export function Segmented({ value, onChange, options }) {
  return (
    <div className="inline-flex border border-sg-border rounded overflow-hidden bg-white">
      {options.map((o) => (
        <button key={o.value} onClick={() => onChange(o.value)}
          className={clsx('h-8 px-3 text-xs font-semibold border-r last:border-r-0 border-sg-border',
            value === o.value ? 'bg-sg-ink text-white' : 'text-sg-ink hover:bg-sg-bg')}>
          {o.label}
        </button>
      ))}
    </div>
  )
}
