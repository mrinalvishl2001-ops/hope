import { useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import { api } from '../api'

export function useBreaks(scope) {
  return useQuery({ queryKey: ['breaks', scope], queryFn: () => api.get(`/api/breaks?scope=${scope}`) })
}

export function useFiltered(items, f) {
  return useMemo(() => {
    const q = (f.q || '').trim().toLowerCase()
    return (items || []).filter((it) => {
      if (f.status && it.status !== f.status && !(f.status === 'Open' && it.is_open)) return false
      if (f.region && it.region !== f.region) return false
      if (f.category && it.category !== f.category) return false
      if (f.owner && (it.assigned_to || '').toLowerCase() !== f.owner.toLowerCase()) return false
      if (f.aging && it.aging_bucket !== f.aging) return false
      if (f.overdue && !it.overdue) return false
      if (f.exceptions && !it.is_exception) return false
      if (q) {
        const hay = [it.id, it.client, it.client_legal, it.account, it.product, it.sdq_comment, it.category, it.assigned_to].join(' ').toLowerCase()
        if (!hay.includes(q)) return false
      }
      return true
    })
  }, [items, f])
}
