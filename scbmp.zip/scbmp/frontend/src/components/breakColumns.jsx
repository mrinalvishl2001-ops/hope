import { fmt } from '../api'
import { AgingPill, FlagIcon, StatusPill } from './ui'

export function breakColumns({ showOwner = false } = {}) {
  const cols = [
    { key: 'id', header: 'Break ID', width: 110, cell: (r) => <span className="font-semibold text-sg-ink num whitespace-nowrap">{r.id} {r.flagged && <FlagIcon />}</span> },
    { key: 'client', header: 'Client', cell: (r) => <span className="text-sg-ink">{r.client || '—'}</span> },
    { key: 'account', header: 'Account', cell: (r) => <span className="num">{r.account || '—'}</span> },
    { key: 'product', header: 'Product' },
    { key: 'lots', header: 'Lots', align: 'right', cell: (r) => fmt.num(r.lots) },
    { key: 'category', header: 'Category', cell: (r) => <span className="text-xs block max-w-[150px]">{r.category}</span> },
    { key: 'status', header: 'Status', cell: (r) => <StatusPill status={r.status} /> },
  ]
  if (showOwner) cols.push({ key: 'assigned_to', header: 'Owner', cell: (r) => (r.is_open ? r.assigned_to : '—') })
  cols.push(
    { key: 'aging', header: 'Aging', align: 'right', cell: (r) => <AgingPill days={r.aging} bucket={r.aging_bucket} overdue={r.overdue} /> },
    { key: 'last_action_on', header: 'Last action', cell: (r) => <span className="text-xs whitespace-nowrap">{fmt.datetime(r.last_action_on)}</span> },
  )
  if (!showOwner) cols.push({ key: 'chaser_count', header: 'Chasers', align: 'right' })
  return cols
}
