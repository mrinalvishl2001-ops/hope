import { useMemo, useState } from 'react'
import clsx from 'clsx'
import { flexRender, getCoreRowModel, getPaginationRowModel, getSortedRowModel, useReactTable } from '@tanstack/react-table'
import { ArrowDown, ArrowUp, ChevronLeft, ChevronRight } from 'lucide-react'

/**
 * columns: [{ key, header, cell?: (row) => node, accessor?: (row) => value, align?: 'right', width?, sortable? }]
 */
export default function DataTable({ columns, data, onRowClick, empty, pageSize = 25, initialSort, activeId, rowKey = 'id', loading }) {
  const [sorting, setSorting] = useState(initialSort ? [initialSort] : [])
  const defs = useMemo(() => columns.map((c) => ({
    id: c.key,
    accessorFn: c.accessor || ((r) => r[c.key]),
    header: c.header,
    enableSorting: c.sortable !== false,
    cell: (info) => (c.cell ? c.cell(info.row.original) : (info.getValue() ?? '—')),
    meta: { align: c.align, width: c.width },
    sortUndefined: 'last',
  })), [columns])

  const table = useReactTable({
    data: data || [], columns: defs, state: { sorting }, onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(), getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(), initialState: { pagination: { pageSize } },
    autoResetPageIndex: true,
  })

  if (loading) {
    return (
      <div className="p-5 space-y-3">
        {[...Array(6)].map((_, i) => <div key={i} className="skeleton h-9 w-full" />)}
      </div>
    )
  }
  if (!data?.length) return empty || null

  const { pageIndex } = table.getState().pagination
  const total = data.length
  const from = pageIndex * pageSize + 1
  const to = Math.min(total, from + pageSize - 1)

  return (
    <div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm border-collapse">
          <thead className="sticky top-0 z-[1]">
            {table.getHeaderGroups().map((hg) => (
              <tr key={hg.id} className="bg-white">
                {hg.headers.map((h) => {
                  const sorted = h.column.getIsSorted()
                  const align = h.column.columnDef.meta?.align
                  return (
                    <th key={h.id} style={{ width: h.column.columnDef.meta?.width }}
                      className={clsx('px-3 py-2.5 border-b-2 border-sg-ink text-xs font-semibold text-sg-ink whitespace-nowrap select-none',
                        align === 'right' ? 'text-right' : 'text-left')}>
                      {h.column.getCanSort() ? (
                        <button className={clsx('inline-flex items-center gap-1 hover:text-sg-red', align === 'right' && 'flex-row-reverse')}
                          onClick={h.column.getToggleSortingHandler()}>
                          {flexRender(h.column.columnDef.header, h.getContext())}
                          {sorted === 'asc' ? <ArrowUp size={12} /> : sorted === 'desc' ? <ArrowDown size={12} /> : <span className="w-3" />}
                        </button>
                      ) : flexRender(h.column.columnDef.header, h.getContext())}
                    </th>
                  )
                })}
              </tr>
            ))}
          </thead>
          <tbody>
            {table.getRowModel().rows.map((row) => {
              const active = activeId && row.original[rowKey] === activeId
              return (
                <tr key={row.id} onClick={onRowClick ? () => onRowClick(row.original) : undefined}
                  onKeyDown={onRowClick ? (e) => { if (e.key === 'Enter') onRowClick(row.original) } : undefined}
                  tabIndex={onRowClick ? 0 : undefined}
                  className={clsx('border-b border-sg-border', onRowClick && 'cursor-pointer hover:bg-sg-tint focus:bg-sg-tint',
                    active && 'bg-sg-tint')}>
                  {row.getVisibleCells().map((cell) => (
                    <td key={cell.id} className={clsx('px-3 py-2.5 align-middle text-sg-text',
                      cell.column.columnDef.meta?.align === 'right' && 'text-right num')}>
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </td>
                  ))}
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
      {total > pageSize && (
        <div className="flex items-center justify-between px-3 py-2.5 text-xs text-sg-muted">
          <span className="num">{from}–{to} of {total}</span>
          <div className="flex gap-1">
            <button className="btn-ghost h-7 px-2" disabled={!table.getCanPreviousPage()} onClick={() => table.previousPage()} aria-label="Previous page"><ChevronLeft size={14} /></button>
            <button className="btn-ghost h-7 px-2" disabled={!table.getCanNextPage()} onClick={() => table.nextPage()} aria-label="Next page"><ChevronRight size={14} /></button>
          </div>
        </div>
      )}
    </div>
  )
}
