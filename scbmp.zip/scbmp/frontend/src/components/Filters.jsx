import { Search, X } from 'lucide-react'
import { useQuery } from '@tanstack/react-query'
import { api } from '../api'
import { Select } from './ui'

export function useMeta() {
  return useQuery({ queryKey: ['meta'], queryFn: () => api.get('/api/meta'), staleTime: 30_000 })
}

/** fields: array of 'q' | 'region' | 'category' | 'status' | 'aging' | 'owner' | 'overdue' */
export default function Filters({ value, onChange, fields }) {
  const meta = useMeta().data
  const set = (k, v) => onChange({ ...value, [k]: v })
  const active = Object.entries(value).some(([k, v]) => v && k !== 'q') || value.q
  return (
    <div className="flex flex-wrap items-center gap-2">
      {fields.includes('q') && (
        <div className="relative w-64">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-sg-muted" />
          <input className="input pl-9" placeholder="Search ID, client, account, product" value={value.q || ''} onChange={(e) => set('q', e.target.value)} />
        </div>
      )}
      {fields.includes('region') && <Select className="w-36" value={value.region} onChange={(v) => set('region', v)} placeholder="All regions" options={meta?.regions || []} />}
      {fields.includes('category') && <Select className="w-60" value={value.category} onChange={(v) => set('category', v)} placeholder="All categories" options={meta?.categories || []} />}
      {fields.includes('status') && <Select className="w-36" value={value.status} onChange={(v) => set('status', v)} placeholder="Any status" options={['Open', ...(meta?.statuses || [])]} />}
      {fields.includes('owner') && <Select className="w-40" value={value.owner} onChange={(v) => set('owner', v)} placeholder="All owners" options={(meta?.users || []).map((u) => ({ value: u.username, label: `${u.username} (${u.role})` }))} />}
      {fields.includes('aging') && <Select className="w-36" value={value.aging} onChange={(v) => set('aging', v)} placeholder="Any aging" options={(meta?.buckets || []).map((b) => ({ value: b, label: `${b} days` }))} />}
      {fields.includes('overdue') && (
        <label className="flex items-center gap-2 text-sm text-sg-ink h-9 px-3 border border-sg-border rounded bg-white cursor-pointer">
          <input type="checkbox" className="accent-[#E9041E]" checked={!!value.overdue} onChange={(e) => set('overdue', e.target.checked ? '1' : '')} /> Overdue only
        </label>
      )}
      {active && (
        <button className="btn-ghost h-9 px-3 text-sg-muted" onClick={() => onChange({})}><X size={14} /> Clear</button>
      )}
    </div>
  )
}
