import { createContext, useCallback, useContext, useState } from 'react'
import { NavLink, Outlet, useSearchParams } from 'react-router-dom'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import clsx from 'clsx'
import { BellRing, History, Inbox, LayoutDashboard, LogOut, RefreshCw, Settings, Table2, Upload } from 'lucide-react'
import { api } from '../api'
import { useAuth } from '../auth'
import BreakDrawer from './BreakDrawer'

const NAV = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['SDQ'] },
  { to: '/inbox', label: 'My inbox', icon: Inbox, roles: ['SDQ', 'CFMO', 'AE'], badge: true },
  { to: '/breaks', label: 'All breaks', icon: Table2, roles: ['SDQ'] },
  { to: '/history', label: 'My history', icon: History, roles: ['CFMO', 'AE'] },
  { to: '/upload', label: 'Upload & assign', icon: Upload, roles: ['SDQ'] },
  { to: '/chasers', label: 'Chaser centre', icon: BellRing, roles: ['SDQ'] },
  { to: '/admin', label: 'Audit & settings', icon: Settings, roles: ['SDQ'] },
]

const DrawerCtx = createContext(() => {})
export const useOpenBreak = () => useContext(DrawerCtx)

export default function Layout() {
  const { user, logout } = useAuth()
  const qc = useQueryClient()
  const [params, setParams] = useSearchParams()
  const [spinning, setSpinning] = useState(false)
  const breakId = params.get('break')
  const summary = useQuery({ queryKey: ['inbox', 'summary'], queryFn: () => api.get('/api/inbox/summary'), refetchInterval: 60_000 })
  const [logoOk, setLogoOk] = useState(true)

  const openBreak = useCallback((id) => {
    setParams((p) => { const n = new URLSearchParams(p); n.set('break', id); return n })
  }, [setParams])
  const closeBreak = useCallback(() => {
    setParams((p) => { const n = new URLSearchParams(p); n.delete('break'); return n })
  }, [setParams])

  const refresh = async () => {
    setSpinning(true)
    await qc.invalidateQueries()
    setTimeout(() => setSpinning(false), 500)
  }

  return (
    <DrawerCtx.Provider value={openBreak}>
      <div className="h-full flex flex-col">
        <header className="h-14 bg-sg-black text-white flex items-center px-5 gap-4 shrink-0 border-b-[3px] border-sg-red">
          <div className="flex items-center gap-3">
            {logoOk && <img src="/brand/logo.png" alt="" className="h-7" onError={() => setLogoOk(false)} />}
            <span className="text-[17px] font-bold tracking-tight">SCBMP</span>
            <span className="h-5 w-px bg-white/30" />
            <span className="text-sm text-white/70 hidden md:inline">Commission break management</span>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <button onClick={refresh} className="h-9 px-3 rounded text-sm text-white/80 hover:text-white hover:bg-white/10 flex items-center gap-2" title="Reload data from the Excel file">
              <RefreshCw size={15} className={clsx(spinning && 'animate-spin')} /> <span className="hidden lg:inline">Refresh data</span>
            </button>
            <span className="h-6 w-px bg-white/20 mx-1" />
            <div className="text-right leading-tight">
              <p className="text-sm font-semibold">{user?.display_name}</p>
              <p className="text-[11px] text-white/60">{user?.username}</p>
            </div>
            <span className="text-[11px] font-semibold px-2 py-1 rounded bg-sg-red text-white">{user?.role_label}</span>
            <button onClick={logout} className="h-9 px-3 rounded text-sm text-white/80 hover:text-white hover:bg-white/10 flex items-center gap-2">
              <LogOut size={15} /> Sign out
            </button>
          </div>
        </header>
        <div className="flex flex-1 min-h-0">
          <nav className="w-[220px] bg-sg-ink text-white shrink-0 py-4 flex flex-col" aria-label="Main">
            {NAV.filter((n) => n.roles.includes(user?.role)).map((n) => (
              <NavLink key={n.to} to={n.to}
                className={({ isActive }) => clsx('relative flex items-center gap-3 h-10 px-5 text-sm',
                  isActive ? 'bg-white/10 text-white font-semibold' : 'text-white/70 hover:text-white hover:bg-white/5')}>
                {({ isActive }) => (
                  <>
                    {isActive && <span className="absolute left-0 top-0 bottom-0 w-[3px] bg-sg-red" />}
                    <n.icon size={17} />
                    <span className="flex-1">{n.label}</span>
                    {n.badge && summary.data?.open > 0 && (
                      <span className={clsx('text-[11px] font-semibold num min-w-[22px] h-5 px-1.5 rounded flex items-center justify-center',
                        summary.data.overdue > 0 ? 'bg-sg-red text-white' : 'bg-white/15 text-white')}>{summary.data.open}</span>
                    )}
                  </>
                )}
              </NavLink>
            ))}
            <div className="mt-auto px-5 pt-4 text-[11px] text-white/40 leading-relaxed">
              Smart Commission Break<br />Management Portal
            </div>
          </nav>
          <main className="flex-1 min-w-0 overflow-y-auto">
            <div className="p-6 max-w-[1500px] mx-auto">
              <Outlet />
            </div>
          </main>
        </div>
      </div>
      {breakId && <BreakDrawer id={breakId} onClose={closeBreak} />}
    </DrawerCtx.Provider>
  )
}
