export class ApiError extends Error {
  constructor(message, status, extra = {}) {
    super(message)
    this.status = status
    this.retry = !!extra.retry
  }
}

async function request(method, url, body, { noRedirect = false } = {}) {
  const init = { method, credentials: 'same-origin', headers: {} }
  if (body instanceof FormData) init.body = body
  else if (body !== undefined) {
    init.headers['Content-Type'] = 'application/json'
    init.body = JSON.stringify(body)
  }
  let res
  try {
    res = await fetch(url, init)
  } catch {
    throw new ApiError('Cannot reach the SCBMP server. Check that the run_app window is still open.', 0)
  }
  if (res.status === 401 && !noRedirect) window.dispatchEvent(new Event('scbmp:unauthorized'))
  if (!res.ok) {
    let msg = `Request failed (${res.status}).`
    let extra = {}
    try {
      const j = await res.json()
      if (typeof j.detail === 'string') msg = j.detail
      extra = j
    } catch { /* not JSON */ }
    throw new ApiError(msg, res.status, extra)
  }
  const ct = res.headers.get('content-type') || ''
  return ct.includes('application/json') ? res.json() : res.text()
}

export const api = {
  get: (url) => request('GET', url),
  post: (url, body) => request('POST', url, body),
  put: (url, body) => request('PUT', url, body),
  login: (body) => request('POST', '/api/auth/login', body, { noRedirect: true }),
}

export function qs(params = {}) {
  const p = new URLSearchParams()
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '' && v !== false) p.set(k, v)
  })
  const s = p.toString()
  return s ? `?${s}` : ''
}

export const fmt = {
  num: (n) => (n === null || n === undefined || n === '' ? '—' : Number(n).toLocaleString('en-GB')),
  date: (s) => {
    if (!s) return '—'
    const d = new Date(String(s).replace(' ', 'T'))
    if (Number.isNaN(d.getTime())) return String(s)
    return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
  },
  datetime: (s) => {
    if (!s) return '—'
    const d = new Date(String(s).replace(' ', 'T'))
    if (Number.isNaN(d.getTime())) return String(s)
    const hasTime = String(s).length > 10
    return d.toLocaleString('en-GB', hasTime
      ? { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }
      : { day: '2-digit', month: 'short', year: 'numeric' })
  },
}
