import { createContext, useContext, useEffect } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { api } from './api'

const AuthCtx = createContext(null)

export function AuthProvider({ children }) {
  const qc = useQueryClient()
  const me = useQuery({
    queryKey: ['me'],
    queryFn: async () => {
      try {
        return (await api.get('/api/auth/me')).user
      } catch (e) {
        if (e.status === 401) return null
        throw e
      }
    },
    staleTime: 60_000,
    retry: false,
  })

  useEffect(() => {
    const onUnauth = () => {
      qc.setQueryData(['me'], null)
      qc.removeQueries({ predicate: (q) => q.queryKey[0] !== 'me' })
    }
    window.addEventListener('scbmp:unauthorized', onUnauth)
    return () => window.removeEventListener('scbmp:unauthorized', onUnauth)
  }, [qc])

  const login = async (username, password) => {
    const { user } = await api.login({ username, password })
    qc.removeQueries({ predicate: (q) => q.queryKey[0] !== 'me' })   // drop the previous user's data
    qc.setQueryData(['me'], user)
    return user
  }
  const logout = async () => {
    try { await api.post('/api/auth/logout') } catch { /* ignore */ }
    qc.setQueryData(['me'], null)
    qc.removeQueries({ predicate: (q) => q.queryKey[0] !== 'me' })
  }

  return (
    <AuthCtx.Provider value={{ user: me.data, loading: me.isLoading, error: me.error, login, logout }}>
      {children}
    </AuthCtx.Provider>
  )
}

export const useAuth = () => useContext(AuthCtx)

export const homeFor = (user) => (user?.role === 'SDQ' ? '/dashboard' : '/inbox')
