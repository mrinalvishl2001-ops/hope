// Single source of colour truth (mirrored in tailwind.config.js).
// SG red #E9041E is Societe Generale's official corporate colour (Pantone 185).
export const colors = {
  red: '#E9041E',
  black: '#000000',
  ink: '#1A1A1A',
  text: '#333333',
  muted: '#767676',
  border: '#E0E0E0',
  bg: '#F5F5F5',
  surface: '#FFFFFF',
  tint: '#FDE6E8',
  ae: '#1F5C99',
  sdq: '#5E4B8B',
  cfmo: '#B86E00',
  closed: '#1E7F4F',
  grey: '#BDBDBD',
}

export const statusColor = {
  'With AE': colors.ae,
  'With SDQ': colors.sdq,
  'With CFMO': colors.cfmo,
  Closed: colors.closed,
}

export const agingColor = {
  '0-2': '#1E7F4F',
  '3-4': '#7FA83A',
  '5-9': '#E0A100',
  '10-14': '#D9531E',
  '15+': '#E9041E',
}
