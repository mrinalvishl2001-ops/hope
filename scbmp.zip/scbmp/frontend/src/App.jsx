import { Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { homeFor, useAuth } from './auth'
import Layout from './components/Layout'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import InboxPage from './pages/Inbox'
import AllBreaks from './pages/AllBreaks'
import HistoryPage from './pages/History'
import UploadPage from './pages/Upload'
import Chasers from './pages/Chasers'
import Admin from './pages/Admin'

function Guard({ roles, children }) {
  const { user, loading } = useAuth()
  const loc = useLocation()
  if (loading) return <FullPageLoader />
  if (!user) return <Navigate to="/login" replace state={{ from: loc.pathname + loc.search }} />
  if (roles && !roles.includes(user.role)) return <Navigate to={homeFor(user)} replace />
  return children
}

function FullPageLoader() {
  return (
    <div className="h-full flex items-center justify-center">
      <div className="w-10 h-10 border-[3px] border-sg-border border-t-sg-red rounded-full animate-spin" aria-label="Loading" />
    </div>
  )
}

export default function App() {
  const { user, loading } = useAuth()
  return (
    <Routes>
      <Route path="/login" element={loading ? <FullPageLoader /> : user ? <Navigate to={homeFor(user)} replace /> : <Login />} />
      <Route element={<Guard><Layout /></Guard>}>
        <Route index element={<Navigate to={homeFor(user)} replace />} />
        <Route path="dashboard" element={<Guard roles={['SDQ']}><Dashboard /></Guard>} />
        <Route path="inbox" element={<InboxPage />} />
        <Route path="breaks" element={<Guard roles={['SDQ']}><AllBreaks /></Guard>} />
        <Route path="history" element={<Guard roles={['CFMO', 'AE']}><HistoryPage /></Guard>} />
        <Route path="upload" element={<Guard roles={['SDQ']}><UploadPage /></Guard>} />
        <Route path="chasers" element={<Guard roles={['SDQ']}><Chasers /></Guard>} />
        <Route path="admin" element={<Guard roles={['SDQ']}><Admin /></Guard>} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
