import { useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { Eye, EyeOff, Lock } from 'lucide-react'
import { homeFor, useAuth } from '../auth'

const STAGES = ['Daily report', 'With AE', 'With SDQ', 'With CFMO', 'Closed']

export default function Login() {
  const { login } = useAuth()
  const nav = useNavigate()
  const loc = useLocation()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [show, setShow] = useState(false)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    if (!username.trim() || !password) { setError('Enter your username and password.'); return }
    setBusy(true)
    try {
      const user = await login(username.trim(), password)
      const from = loc.state?.from
      nav(from && from !== '/login' ? from : homeFor(user), { replace: true })
    } catch (err) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="min-h-full grid lg:grid-cols-[1.1fr_1fr]">
      <section className="bg-sg-black text-white px-10 lg:px-16 py-12 flex flex-col relative overflow-hidden">
        <div className="flex items-center gap-3">
          <span className="text-xl font-bold tracking-tight">SCBMP</span>
          <span className="h-5 w-px bg-white/30" />
          <span className="text-sm text-white/60">SDQ</span>
        </div>

        <div className="my-auto py-12 max-w-xl">
          <h1 className="text-[40px] leading-[1.1] font-semibold">Smart Commission Break Management Portal</h1>
          <p className="text-lg text-white/70 mt-4">Intelligent break assignment and resolution</p>

          <ol className="mt-12 flex items-center" aria-label="How a break moves">
            {STAGES.map((s, i) => (
              <li key={s} className="flex items-center flex-1 last:flex-none">
                <div className="flex flex-col items-start">
                  <span className={`w-3 h-3 rounded-full ${i === STAGES.length - 1 ? 'bg-sg-red' : 'bg-white'}`} />
                  <span className="text-xs text-white/60 mt-2 whitespace-nowrap">{s}</span>
                </div>
                {i < STAGES.length - 1 && <span className="flex-1 h-px bg-white/30 mx-2 -mt-5" />}
              </li>
            ))}
          </ol>

          <ul className="mt-12 space-y-4 text-[15px] text-white/85">
            <li className="flex gap-3"><span className="w-1 bg-sg-red shrink-0" />Each break is routed to SDQ, CFMO or the Account Executive as soon as the daily report is loaded.</li>
            <li className="flex gap-3"><span className="w-1 bg-sg-red shrink-0" />Everyone works from their own inbox, and every action is written to the Excel audit log.</li>
            <li className="flex gap-3"><span className="w-1 bg-sg-red shrink-0" />Outlook chasers go out automatically when a break sits without action.</li>
          </ul>
        </div>
        <p className="text-xs text-white/40">Zero Commission and Commission Difference control</p>
      </section>

      <section className="bg-sg-bg flex items-center justify-center px-6 py-12">
        <form onSubmit={submit} className="bg-white border border-sg-border rounded w-full max-w-[400px] p-8" noValidate>
          <div className="w-10 h-10 rounded bg-sg-ink flex items-center justify-center mb-5"><Lock size={18} className="text-white" /></div>
          <h2 className="text-[22px] font-semibold text-sg-ink">Sign in</h2>
          <p className="text-sm text-sg-muted mt-1 mb-6">Use your SCBMP username and password.</p>

          <label className="block text-sm font-semibold text-sg-ink mb-1.5" htmlFor="u">Username</label>
          <input id="u" className="input h-10" autoComplete="username" autoFocus value={username} onChange={(e) => setUsername(e.target.value)} />

          <label className="block text-sm font-semibold text-sg-ink mb-1.5 mt-4" htmlFor="p">Password</label>
          <div className="relative">
            <input id="p" className="input h-10 pr-10" type={show ? 'text' : 'password'} autoComplete="current-password"
              value={password} onChange={(e) => setPassword(e.target.value)} />
            <button type="button" className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-sg-muted hover:text-sg-ink"
              onClick={() => setShow((s) => !s)} aria-label={show ? 'Hide password' : 'Show password'}>
              {show ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>

          {error && <p className="mt-4 text-sm text-sg-red border-l-[3px] border-sg-red pl-3" role="alert">{error}</p>}

          <button className="btn-primary w-full h-10 mt-6" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
          <p className="text-xs text-sg-muted mt-6">Five failed attempts lock the username for five minutes.</p>
        </form>
      </section>
    </div>
  )
}
