import { useEffect, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { AlertTriangle, ScrollText } from 'lucide-react'
import { api, fmt, qs } from '../api'
import DataTable from '../components/DataTable'
import { useMeta } from '../components/Filters'
import { useOpenBreak } from '../components/Layout'
import { useToast } from '../components/Toast'
import { Card, EmptyState, ErrorNote, Modal, PageHeader, Segmented, Select } from '../components/ui'

function AuditTab() {
  const meta = useMeta().data
  const openBreak = useOpenBreak()
  const [f, setF] = useState({ user_filter: '', action: '', q: '' })
  const [q, setQ] = useState('')
  useEffect(() => { const t = setTimeout(() => setF((x) => ({ ...x, q })), 300); return () => clearTimeout(t) }, [q])
  const audit = useQuery({ queryKey: ['audit', f], queryFn: () => api.get(`/api/audit${qs(f)}`) })
  return (
    <Card bodyClass="" title="Audit log" subtitle={audit.data ? `${audit.data.total} action(s), newest first` : ''}
      actions={
        <div className="flex gap-2">
          <input className="input w-56" placeholder="Search comments, IDs" value={q} onChange={(e) => setQ(e.target.value)} />
          <Select className="w-40" value={f.user_filter} onChange={(v) => setF((x) => ({ ...x, user_filter: v }))} placeholder="All users"
            options={[...(meta?.users || []).map((u) => u.username), 'Assignment engine']} />
          <Select className="w-52" value={f.action} onChange={(v) => setF((x) => ({ ...x, action: v }))} placeholder="All actions" options={audit.data?.actions || []} />
        </div>
      }>
      <ErrorNote error={audit.error} />
      <DataTable rowKey="Timestamp" loading={audit.isLoading} data={audit.data?.items} pageSize={25}
        onRowClick={(r) => r['Break ID'] && openBreak(r['Break ID'])}
        columns={[
          { key: 'Timestamp', header: 'When', cell: (r) => <span className="whitespace-nowrap">{fmt.datetime(r.Timestamp)}</span> },
          { key: 'Break ID', header: 'Break', cell: (r) => <span className="font-semibold num whitespace-nowrap">{r['Break ID']}</span> },
          { key: 'User', header: 'User', cell: (r) => <span className="whitespace-nowrap">{r.User}</span> }, { key: 'Action', header: 'Action' },
          { key: 'To Status', header: 'Status change', cell: (r) => <span className="whitespace-nowrap">{r['From Status'] === r['To Status'] ? '—' : `${r['From Status'] || 'New'} → ${r['To Status']}`}</span> },
          { key: 'Comment', header: 'Comment', cell: (r) => <span className="text-xs">{r.Comment}</span> },
        ]}
        empty={<EmptyState icon={ScrollText} title="No actions match" />} />
    </Card>
  )
}

function SettingsTab() {
  const qc = useQueryClient()
  const toast = useToast()
  const s = useQuery({ queryKey: ['settings'], queryFn: () => api.get('/api/settings') })
  const [mode, setMode] = useState('draft')
  const [redirect, setRedirect] = useState('')
  const [confirm, setConfirm] = useState(false)
  useEffect(() => { if (s.data) { setMode(s.data.mode); setRedirect(s.data.redirect_all_to) } }, [s.data])
  const save = useMutation({
    mutationFn: () => api.put('/api/settings', { mode, redirect_all_to: redirect }),
    onSuccess: (d) => { qc.setQueryData(['settings'], d); qc.invalidateQueries({ queryKey: ['chasers'] }); toast('Settings saved') },
  })
  const reset = useMutation({
    mutationFn: () => api.post('/api/admin/demo-reset'),
    onSuccess: (r) => { setConfirm(false); qc.invalidateQueries(); toast(r.message) },
    onError: () => setConfirm(false),
  })
  const d = s.data
  if (s.isLoading) return <div className="skeleton h-64" />
  if (s.error) return <ErrorNote error={s.error} onRetry={() => s.refetch()} />
  const c = d.chasers

  return (
    <div className="grid xl:grid-cols-2 gap-5 items-start">
      <Card title="Chaser emails" subtitle={d.outlook ? 'Desktop Outlook detected on this computer.' : 'Outlook was not detected; drafts and sends fall back to preview files in the outbox folder.'}>
        <p className="label mb-2">How chasers are delivered</p>
        <Segmented value={mode} onChange={setMode} options={[{ value: 'preview', label: 'Preview files only' }, { value: 'draft', label: 'Outlook drafts' }, { value: 'live', label: 'Send for real' }]} />
        {mode === 'live' && <p className="text-xs text-sg-red mt-2">Emails will be sent to real recipients without review.</p>}
        <label className="label block mt-5 mb-1" htmlFor="redir">Redirect every email to (for demos, optional)</label>
        <input id="redir" className="input" placeholder="your.name@company.com" value={redirect} onChange={(e) => setRedirect(e.target.value)} />
        <div className="mt-3"><ErrorNote error={save.error} /></div>
        <button className="btn-primary mt-4" onClick={() => save.mutate()} disabled={save.isPending}>{save.isPending ? 'Saving…' : 'Save settings'}</button>
        <dl className="grid grid-cols-2 gap-3 mt-6 pt-5 border-t border-sg-border text-sm">
          <div><dt className="label">1st reminder after</dt><dd className="text-sg-ink">{c.first_after_days} {c.business_days ? 'business' : ''} days</dd></div>
          <div><dt className="label">2nd reminder</dt><dd className="text-sg-ink">{c.second_after_days} days after the 1st</dd></div>
          <div><dt className="label">Then</dt><dd className="text-sg-ink">every {c.then_every_days} day(s)</dd></div>
          <div><dt className="label">SDQ copied from</dt><dd className="text-sg-ink">reminder {c.cc_sdq_from_level}</dd></div>
          <div className="col-span-2"><dt className="label">Manager escalation</dt><dd className="text-sg-ink">{c.manager_email ? `${c.manager_email} from reminder ${c.manager_from_level}` : 'Not set (config.yaml)'}</dd></div>
        </dl>
      </Card>

      <Card title="Assignment rules" subtitle="Read-only. Edit config.yaml to change keywords; checked in column BC, then BB, then the whole row.">
        <table className="w-full text-sm">
          <thead><tr className="text-left text-xs font-semibold border-b-2 border-sg-ink"><th className="py-2">#</th><th>If the text contains</th><th>Category</th><th>Goes to</th></tr></thead>
          <tbody>
            {d.rules.map((r, i) => (
              <tr key={i} className="border-b border-sg-border align-top">
                <td className="py-2 num">{i + 1}</td>
                <td className="py-2 pr-3">{r.keywords.map((k) => <span key={k} className="inline-block text-xs bg-sg-bg border border-sg-border rounded px-1.5 py-0.5 mr-1 mb-1">{k}</span>)}</td>
                <td className="py-2 pr-3">{r.category}</td>
                <td className="py-2 whitespace-nowrap">{r.role} ({d.roles[r.role]})</td>
              </tr>
            ))}
            <tr><td className="py-2 num">{d.rules.length + 1}</td><td className="text-sg-muted">Nothing matched</td><td>{d.fallback.category}</td><td>{d.fallback.role} ({d.roles[d.fallback.role]}), flagged</td></tr>
          </tbody>
        </table>
        <p className="label mt-5">Master file</p>
        <p className="text-sm text-sg-ink break-all">{d.excel_path}</p>
      </Card>

      <Card title="Demo reset" className="xl:col-span-2 border-sg-red/50">
        <div className="flex flex-wrap items-center gap-4">
          <AlertTriangle className="text-sg-red" size={20} />
          <p className="text-sm flex-1 min-w-[300px]">Restores the original sample sheet, clears the audit and email logs, and re-runs the assignment engine. A backup of the current file is kept in the backups folder.</p>
          <button className="btn-danger" disabled={!d.allow_reset} onClick={() => setConfirm(true)}>Reset demo data</button>
        </div>
        {!d.allow_reset && <p className="text-xs text-sg-muted mt-2">Switched off in config.yaml (demo.allow_reset: false).</p>}
        <div className="mt-3"><ErrorNote error={reset.error} /></div>
      </Card>

      <Modal open={confirm} title="Reset demo data?" onClose={() => setConfirm(false)}
        footer={<><button className="btn-secondary" onClick={() => setConfirm(false)}>Cancel</button>
          <button className="btn-primary" disabled={reset.isPending} onClick={() => reset.mutate()}>{reset.isPending ? 'Resetting…' : 'Reset demo data'}</button></>}>
        All workflow progress in <b>{d.excel_path.split(/[\\/]/).pop()}</b> will be replaced with the original sample. A backup is saved first.
      </Modal>
    </div>
  )
}

export default function Admin() {
  const [tab, setTab] = useState('audit')
  return (
    <>
      <PageHeader title="Audit & settings" actions={<Segmented value={tab} onChange={setTab} options={[{ value: 'audit', label: 'Audit log' }, { value: 'settings', label: 'Settings' }]} />} />
      {tab === 'audit' ? <AuditTab /> : <SettingsTab />}
    </>
  )
}
