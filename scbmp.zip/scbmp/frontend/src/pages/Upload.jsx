import { useRef, useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { FileSpreadsheet, Play, UploadCloud } from 'lucide-react'
import { api, fmt } from '../api'
import { useMeta } from '../components/Filters'
import { useToast } from '../components/Toast'
import { Card, ErrorNote, PageHeader, StatusPill } from '../components/ui'

function Summary({ res }) {
  if (!res) return null
  const a = res.assignment || res
  return (
    <div className="mt-4 border border-sg-border rounded p-4 bg-sg-bg text-sm">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {res.added !== undefined && <div><p className="label">Added</p><p className="text-xl font-semibold num">{res.added}</p></div>}
        {res.duplicates !== undefined && <div><p className="label">Duplicates skipped</p><p className="text-xl font-semibold num">{res.duplicates}</p></div>}
        <div><p className="label">Breaks in file</p><p className="text-xl font-semibold num">{a.total}</p></div>
        <div><p className="label">Newly assigned</p><p className="text-xl font-semibold num">{a.newly_assigned}</p></div>
      </div>
      <p className="mt-3 text-sg-ink"><span className="text-sg-muted">By role:</span> {Object.entries(a.by_role || {}).map(([k, v]) => `${k} ${v}`).join(' · ') || '—'}</p>
      <p className="mt-1 text-sg-ink"><span className="text-sg-muted">By status:</span> {Object.entries(a.by_status || {}).map(([k, v]) => `${k} ${v}`).join(' · ') || '—'}</p>
      {a.unclassified?.length > 0 && <p className="mt-1 text-sg-red">Needs manual review: {a.unclassified.join(', ')}</p>}
    </div>
  )
}

export default function UploadPage() {
  const qc = useQueryClient()
  const toast = useToast()
  const meta = useMeta().data
  const input = useRef(null)
  const [preview, setPreview] = useState(null)
  const [result, setResult] = useState(null)
  const [assignRes, setAssignRes] = useState(null)
  const refreshAll = () => ['breaks', 'inbox', 'dashboard', 'meta'].forEach((k) => qc.invalidateQueries({ queryKey: [k] }))

  const up = useMutation({
    mutationFn: (file) => { const fd = new FormData(); fd.append('file', file); return api.post('/api/admin/upload/preview', fd) },
    onSuccess: (r) => { setPreview(r); setResult(null) },
  })
  const commit = useMutation({
    mutationFn: () => api.post('/api/admin/upload/commit', { token: preview.token }),
    onSuccess: (r) => { setResult(r); setPreview(null); refreshAll(); toast(`${r.added} new break(s) added and assigned`) },
  })
  const assign = useMutation({
    mutationFn: () => api.post('/api/admin/assign'),
    onSuccess: (r) => { setAssignRes(r); refreshAll(); toast(r.newly_assigned ? `${r.newly_assigned} break(s) assigned` : 'Every break already has an owner') },
  })

  return (
    <>
      <PageHeader title="Upload & assign" subtitle={meta ? `Master file: ${meta.file.name}, last changed ${fmt.datetime(meta.file.modified)}` : ''} />
      <div className="grid xl:grid-cols-[1.4fr_1fr] gap-5 items-start">
        <Card title="Add a daily control report" subtitle="New breaks are appended to the master file and assigned. Rows already in the file are skipped.">
          <input ref={input} type="file" accept=".xlsx,.xlsm" className="hidden"
            onChange={(e) => { const f = e.target.files?.[0]; if (f) up.mutate(f); e.target.value = '' }} />
          <button onClick={() => input.current?.click()} disabled={up.isPending}
            className="w-full border-2 border-dashed border-sg-border hover:border-sg-ink rounded p-8 flex flex-col items-center gap-2 text-sg-muted transition-colors">
            <UploadCloud size={28} className="text-sg-ink" />
            <span className="text-sm font-semibold text-sg-ink">{up.isPending ? 'Reading file…' : 'Choose the daily report (.xlsx)'}</span>
            <span className="text-xs">Same 57-column layout as the master file</span>
          </button>
          <div className="mt-4"><ErrorNote error={up.error || commit.error} /></div>

          {preview && (
            <div className="mt-2">
              <div className="flex items-center gap-2 text-sm text-sg-ink"><FileSpreadsheet size={16} /> {preview.filename}</div>
              <p className="text-sm text-sg-muted mt-1"><span className="num">{preview.rows_in_file}</span> rows in file · <span className="num font-semibold text-sg-ink">{preview.new}</span> new · <span className="num">{preview.duplicates}</span> already in the master file</p>
              {preview.preview.length > 0 && (
                <div className="mt-3 border border-sg-border rounded max-h-72 overflow-auto">
                  <table className="w-full text-xs">
                    <thead className="sticky top-0 bg-white"><tr className="text-left border-b-2 border-sg-ink">
                      <th className="px-2 py-2">Account</th><th className="px-2">Client</th><th className="px-2">Product</th><th className="px-2 text-right">Lots</th><th className="px-2">SDQ comment</th><th className="px-2">Goes to</th></tr></thead>
                    <tbody>{preview.preview.map((r, i) => (
                      <tr key={i} className="border-b border-sg-border">
                        <td className="px-2 py-1.5 num">{r.account}</td><td className="px-2">{r.client}</td><td className="px-2">{r.product}</td>
                        <td className="px-2 text-right num">{fmt.num(r.lots)}</td><td className="px-2">{r.sdq_comment}</td><td className="px-2"><StatusPill status={r.status} /></td>
                      </tr>))}</tbody>
                  </table>
                </div>
              )}
              <div className="flex gap-2 mt-4">
                <button className="btn-primary" disabled={!preview.new || commit.isPending} onClick={() => commit.mutate()}>
                  {commit.isPending ? 'Adding…' : `Add ${preview.new} new break(s) and assign`}
                </button>
                <button className="btn-secondary" onClick={() => setPreview(null)}>Cancel</button>
              </div>
            </div>
          )}
          <Summary res={result} />
        </Card>

        <Card title="Run the assignment engine" subtitle="Assigns any break in the master file that has no owner yet. Existing assignments never change.">
          <button className="btn-dark" onClick={() => assign.mutate()} disabled={assign.isPending}>
            <Play size={15} /> {assign.isPending ? 'Running…' : 'Run assignment'}
          </button>
          {meta?.unassigned > 0 && <p className="text-sm text-sg-red mt-3">{meta.unassigned} break(s) in the file have no owner yet.</p>}
          <div className="mt-3"><ErrorNote error={assign.error} onRetry={assign.error?.status === 423 ? () => assign.mutate() : undefined} /></div>
          <Summary res={assignRes} />
        </Card>
      </div>
    </>
  )
}
