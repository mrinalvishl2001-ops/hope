import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { BellRing, Eye, FlaskConical, Mail, Send } from 'lucide-react'
import { api, fmt } from '../api'
import { useToast } from '../components/Toast'
import DataTable from '../components/DataTable'
import { Card, EmptyState, ErrorNote, Modal, PageHeader } from '../components/ui'

const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
function addBusinessDays(n) {
  const d = new Date()
  let k = 0
  while (k < n) { d.setDate(d.getDate() + 1); if (d.getDay() !== 0 && d.getDay() !== 6) k += 1 }
  return iso(d)
}
const MODE = { preview: 'Preview files only', draft: 'Outlook drafts', live: 'Send for real' }
const levelColor = (l) => (l >= 3 ? '#E9041E' : l === 2 ? '#D9531E' : '#E0A100')

export default function Chasers() {
  const qc = useQueryClient()
  const toast = useToast()
  const today = iso(new Date())
  const [asOf, setAsOf] = useState(today)
  const [preview, setPreview] = useState(null)
  const [confirm, setConfirm] = useState(false)
  const [open, setOpen] = useState({})
  const plan = useQuery({ queryKey: ['chasers', 'plan', asOf], queryFn: () => api.get(`/api/chasers/plan?as_of=${asOf}`) })
  const logq = useQuery({ queryKey: ['chasers', 'log'], queryFn: () => api.get('/api/chasers/log') })
  const run = useMutation({
    mutationFn: () => api.post('/api/chasers/run'),
    onSuccess: (r) => {
      setConfirm(false)
      toast(r.count ? `${r.count} chaser email(s) processed (${MODE[r.mode] || r.mode})` : 'No chasers are due today')
      ;['chasers', 'breaks', 'dashboard', 'inbox'].forEach((k) => qc.invalidateQueries({ queryKey: [k] }))
    },
    onError: () => setConfirm(false),
  })
  const p = plan.data
  const simulated = asOf !== today
  const quick = [['Today', today], ['+5 business days', addBusinessDays(5)], ['+7', addBusinessDays(7)], ['+8', addBusinessDays(8)]]

  return (
    <>
      <PageHeader title="Chaser centre"
        subtitle="1st reminder after 5 business days without action, 2nd after 2 more (SDQ copied), then one every business day. One email per person per day." />

      <Card className="mb-5" bodyClass="p-5">
        <div className="flex flex-wrap items-end gap-4">
          <div>
            <label className="label block mb-1" htmlFor="asof">Show chasers due on</label>
            <input id="asof" type="date" className="input w-44" value={asOf} min={today} onChange={(e) => setAsOf(e.target.value || today)} />
          </div>
          <div className="flex gap-1">
            {quick.map(([l, v]) => (
              <button key={l} className={`btn-secondary h-9 text-xs ${asOf === v ? '!bg-sg-ink !text-white !border-sg-ink' : ''}`} onClick={() => setAsOf(v)}>{l}</button>
            ))}
          </div>
          <div className="ml-auto flex items-center gap-3">
            {p && <span className="text-xs text-sg-muted">Mode: <b className="text-sg-ink">{MODE[p.mode]}</b>{!p.outlook && p.mode !== 'preview' && ' (Outlook not detected, previews will be written)'}</span>}
            <button className="btn-primary" disabled={simulated || !p?.groups.length || run.isPending} onClick={() => setConfirm(true)}
              title={simulated ? 'Switch to today to send' : undefined}>
              <Send size={15} /> Run chasers now
            </button>
          </div>
        </div>
        {simulated && (
          <p className="mt-4 text-sm text-sg-ink bg-sg-tint border-l-[3px] border-sg-red px-3 py-2 flex items-center gap-2">
            <FlaskConical size={15} className="text-sg-red" /> Simulation for {fmt.date(asOf)}. Nothing is sent or saved; it shows what would go out if nobody acts before then.
          </p>
        )}
        <div className="mt-3"><ErrorNote error={plan.error || run.error} /></div>
      </Card>

      <Card title={p ? `${p.groups.length} email(s) due ${simulated ? 'on ' + fmt.date(asOf) : 'today'}` : 'Chasers due'} className="mb-5" bodyClass="">
        {plan.isLoading && <div className="p-5"><div className="skeleton h-16" /></div>}
        {p && p.groups.length === 0 && <EmptyState icon={BellRing} title="No chasers due" text={simulated ? 'No break would be idle long enough on this date.' : 'Try +5 or +7 business days to preview upcoming reminders.'} />}
        {p?.groups.map((g) => (
          <div key={g.username} className="border-t border-sg-border px-5 py-4">
            <div className="flex flex-wrap items-center gap-4">
              <span className="text-xs font-semibold text-white px-2 py-1 rounded" style={{ backgroundColor: levelColor(g.level) }}>{g.label}</span>
              <div className="min-w-[200px]">
                <p className="text-sm font-semibold text-sg-ink">{g.name} <span className="text-sg-muted font-normal">({g.role})</span></p>
                <p className="text-xs text-sg-muted">To {g.to}{g.cc ? ` · CC ${g.cc}` : ''}{g.redirected ? ' · demo redirect on' : ''}</p>
              </div>
              <p className="text-sm text-sg-ink flex-1 min-w-0 basis-60 truncate" title={g.subject}><Mail size={13} className="inline mr-1 text-sg-muted" />{g.subject}</p>
              <button className="btn-ghost h-8 text-xs" onClick={() => setOpen((o) => ({ ...o, [g.username]: !o[g.username] }))}>{open[g.username] ? 'Hide' : 'Show'} {g.breaks.length} break(s)</button>
              <button className="btn-secondary h-8 text-xs" onClick={() => setPreview(g)}><Eye size={14} /> Preview email</button>
            </div>
            {open[g.username] && (
              <table className="w-full text-xs mt-3">
                <thead><tr className="text-left text-sg-muted"><th className="py-1 font-normal">Break</th><th className="font-normal">Client</th><th className="font-normal">Product</th><th className="font-normal">SDQ comment</th><th className="font-normal text-right">Days without action</th></tr></thead>
                <tbody>{g.breaks.map((b) => (
                  <tr key={b.id} className="border-t border-sg-border"><td className="py-1.5 font-semibold num">{b.id}</td><td>{b.client}</td><td>{b.product}</td><td>{b.sdq_comment}</td>
                    <td className={`text-right num ${b.idle >= 10 ? 'text-sg-red font-semibold' : ''}`}>{b.idle}</td></tr>))}</tbody>
              </table>
            )}
          </div>
        ))}
      </Card>

      <Card title="Email log" subtitle="Every chaser that was drafted, sent or previewed" bodyClass="">
        <DataTable rowKey="Timestamp" loading={logq.isLoading} data={logq.data?.items} pageSize={15}
          columns={[
            { key: 'Timestamp', header: 'When', cell: (r) => <span className="whitespace-nowrap">{fmt.datetime(r.Timestamp)}</span> },
            { key: 'Recipient', header: 'To' }, { key: 'CC', header: 'CC' },
            { key: 'Chaser Level', header: 'Level', align: 'right' },
            { key: 'Mode', header: 'Mode' }, { key: 'Break IDs', header: 'Breaks' },
          ]}
          empty={<EmptyState icon={Mail} title="No chasers sent yet" />} />
      </Card>

      <Modal open={!!preview} title={preview?.subject || ''} wide onClose={() => setPreview(null)}
        footer={<button className="btn-secondary" onClick={() => setPreview(null)}>Close</button>}>
        {preview && <iframe title="Email preview" className="w-full h-[60vh] border border-sg-border rounded"
          src={`/api/chasers/preview?username=${encodeURIComponent(preview.username)}&as_of=${asOf}`} />}
      </Modal>

      <Modal open={confirm} title="Run chasers now?" onClose={() => setConfirm(false)}
        footer={<><button className="btn-secondary" onClick={() => setConfirm(false)}>Cancel</button>
          <button className="btn-primary" disabled={run.isPending} onClick={() => run.mutate()}>{run.isPending ? 'Working…' : 'Run chasers'}</button></>}>
        This will process <b>{p?.groups.length}</b> email(s) in <b>{MODE[p?.mode]}</b> mode
        {p?.mode === 'live' ? ', and they will be sent immediately.' : '.'} Each break's chaser count is updated in the Excel.
      </Modal>
    </>
  )
}
