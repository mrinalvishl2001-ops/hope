import { useState } from 'react'
import { History } from 'lucide-react'
import DataTable from '../components/DataTable'
import Filters from '../components/Filters'
import { breakColumns } from '../components/breakColumns'
import { useOpenBreak } from '../components/Layout'
import { useBreaks, useFiltered } from '../components/useBreaks'
import { Card, EmptyState, ErrorNote, PageHeader } from '../components/ui'

export default function HistoryPage() {
  const [f, setF] = useState({})
  const openBreak = useOpenBreak()
  const list = useBreaks('history')
  const rows = useFiltered(list.data?.items, f)
  return (
    <>
      <PageHeader title="My history" subtitle="Breaks you have acted on that are now with someone else or closed. Read-only." />
      <Card bodyClass="" actions={<Filters value={f} onChange={setF} fields={['q', 'status']} />} title="Breaks I acted on">
        {list.error && <div className="px-5 pb-5"><ErrorNote error={list.error} onRetry={() => list.refetch()} /></div>}
        <DataTable columns={breakColumns({ showOwner: true })} data={rows} loading={list.isLoading} onRowClick={(r) => openBreak(r.id)}
          empty={<EmptyState icon={History} title="Nothing here yet" text="Breaks appear here after you comment on them, send them on, or close them." />} />
      </Card>
    </>
  )
}
