import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { CheckCircle2 } from 'lucide-react'
import { api } from '../api'
import { useAuth } from '../auth'
import DataTable from '../components/DataTable'
import Filters from '../components/Filters'
import { breakColumns } from '../components/breakColumns'
import { useOpenBreak } from '../components/Layout'
import { useBreaks, useFiltered } from '../components/useBreaks'
import { Card, EmptyState, ErrorNote, KpiCard, PageHeader } from '../components/ui'

export default function InboxPage() {
  const { user } = useAuth()
  const openBreak = useOpenBreak()
  const [f, setF] = useState({})
  const list = useBreaks('mine')
  const summary = useQuery({ queryKey: ['inbox', 'summary'], queryFn: () => api.get('/api/inbox/summary') })
  const rows = useFiltered(list.data?.items, f)
  const s = summary.data

  const intro = {
    SDQ: 'Breaks sent to SDQ for review, plus anything the engine could not classify.',
    CFMO: 'Commission adjustments waiting for you. Comment, close, or send back to SDQ.',
    AE: 'Missing products in agreements. Update the agreement, then send the break to SDQ.',
  }[user?.role]

  return (
    <>
      <PageHeader title="My inbox" subtitle={intro} />
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-5">
        <KpiCard label="My open breaks" value={s?.open ?? '—'} loading={summary.isLoading} />
        <KpiCard label="Overdue" value={s?.overdue ?? '—'} hint="No action for 5+ business days" tone={s?.overdue ? 'alert' : undefined} loading={summary.isLoading}
          onClick={s?.overdue ? () => setF({ overdue: '1' }) : undefined} />
        <KpiCard label="Chased this week" value={s?.chased_this_week ?? '—'} loading={summary.isLoading} />
        <KpiCard label="Closed by me this month" value={s?.closed_this_month ?? '—'} loading={summary.isLoading} />
      </div>
      <Card title="Waiting for my action" subtitle={list.data ? `${rows.length} of ${list.data.count} shown, oldest first` : ' '}
        actions={<Filters value={f} onChange={setF} fields={['q', 'region', 'aging', 'overdue']} />} bodyClass="">
        {list.error && <div className="px-5 pb-5"><ErrorNote error={list.error} onRetry={() => list.refetch()} /></div>}
        <DataTable columns={breakColumns()} data={rows} loading={list.isLoading} onRowClick={(r) => openBreak(r.id)}
          empty={list.data?.count === 0
            ? <EmptyState icon={CheckCircle2} title="No breaks waiting for you" text="Nice work. New breaks appear here as soon as they are assigned to you." />
            : <EmptyState title="No breaks match these filters" action={<button className="btn-secondary" onClick={() => setF({})}>Clear filters</button>} />} />
      </Card>
    </>
  )
}
