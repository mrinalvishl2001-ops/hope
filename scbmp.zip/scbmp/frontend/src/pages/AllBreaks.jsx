import { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Download } from 'lucide-react'
import { qs } from '../api'
import DataTable from '../components/DataTable'
import Filters from '../components/Filters'
import { breakColumns } from '../components/breakColumns'
import { useOpenBreak } from '../components/Layout'
import { useBreaks, useFiltered } from '../components/useBreaks'
import { Card, EmptyState, ErrorNote, PageHeader } from '../components/ui'

const KEYS = ['q', 'region', 'category', 'status', 'owner', 'aging', 'overdue', 'exceptions']

export default function AllBreaks() {
  const [params] = useSearchParams()
  const initial = useMemo(() => Object.fromEntries(KEYS.map((k) => [k, params.get(k) || '']).filter(([, v]) => v)), []) // eslint-disable-line
  const [f, setF] = useState(initial)
  const openBreak = useOpenBreak()
  const list = useBreaks('all')
  const rows = useFiltered(list.data?.items, f)
  const exportUrl = `/api/breaks/export${qs(f)}`

  return (
    <>
      <PageHeader title="All breaks" subtitle="Every break in the file, open and closed."
        actions={<a className="btn-secondary" href={exportUrl}><Download size={15} /> Export to Excel</a>} />
      <Card bodyClass="">
        <div className="px-5 py-4 border-b border-sg-border">
          <Filters value={f} onChange={setF} fields={['q', 'status', 'owner', 'category', 'region', 'aging', 'overdue']} />
          {f.exceptions && <p className="text-xs text-sg-muted mt-2">Showing exceptions only (SDQ team responsible = Exception).</p>}
        </div>
        {list.error && <div className="p-5"><ErrorNote error={list.error} onRetry={() => list.refetch()} /></div>}
        <div className="px-5 pt-3 text-xs text-sg-muted">{list.data ? `${rows.length} of ${list.data.count} breaks` : ''}</div>
        <DataTable columns={breakColumns({ showOwner: true })} data={rows} loading={list.isLoading} pageSize={30}
          onRowClick={(r) => openBreak(r.id)}
          empty={<EmptyState title="No breaks match these filters" action={<button className="btn-secondary" onClick={() => setF({})}>Clear filters</button>} />} />
      </Card>
    </>
  )
}
