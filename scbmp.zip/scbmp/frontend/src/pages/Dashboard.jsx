import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { Bar, BarChart, CartesianGrid, Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { ChevronRight } from 'lucide-react'
import { api, fmt, qs } from '../api'
import { useMeta } from '../components/Filters'
import { Card, EmptyState, ErrorNote, KpiCard, PageHeader, Segmented, Select } from '../components/ui'
import { agingColor, colors, statusColor } from '../theme'

const tip = { contentStyle: { border: `1px solid ${colors.border}`, borderRadius: 4, fontSize: 12, padding: '6px 10px' }, cursor: { fill: '#00000008' } }
const axis = { tick: { fontSize: 12, fill: colors.muted }, axisLine: { stroke: colors.border }, tickLine: false }
const short = (s, n = 34) => (s.length > n ? `${s.slice(0, n - 1)}…` : s)

function Flow({ flow, onPick }) {
  const total = flow[0]?.value || 0
  const parts = flow.slice(1)
  return (
    <section className="card p-5 mb-5">
      <div className="flex items-baseline justify-between mb-4">
        <h2 className="text-[15px] font-semibold text-sg-ink">Where the breaks are now</h2>
        <span className="text-xs text-sg-muted">Click a stage to open its breaks</span>
      </div>
      <div className="flex items-stretch">
        {flow.map((s, i) => {
          const c = i === 0 ? colors.ink : statusColor[s.key]
          return (
            <div key={s.key} className="flex items-stretch flex-1 min-w-0">
              <button onClick={() => onPick(s)} className="flex-1 text-left px-4 py-3 rounded hover:bg-sg-bg transition-colors group">
                <span className="text-[13px] text-sg-muted flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: c }} />{s.label}
                </span>
                <span className="block text-[34px] leading-tight font-semibold num mt-1" style={{ color: i === 0 ? colors.ink : c }}>{fmt.num(s.value)}</span>
                <span className="text-xs text-sg-muted num">{i === 0 ? 'breaks in file' : total ? `${Math.round((100 * s.value) / total)}% of total` : '—'}</span>
              </button>
              {i < flow.length - 1 && <div className="flex items-center text-sg-border"><ChevronRight size={22} /></div>}
            </div>
          )
        })}
      </div>
      <div className="flex h-2 mt-4 rounded overflow-hidden bg-sg-bg" aria-hidden="true">
        {parts.map((s) => s.value > 0 && (
          <div key={s.key} style={{ width: `${(100 * s.value) / (total || 1)}%`, backgroundColor: statusColor[s.key] }} />
        ))}
      </div>
    </section>
  )
}

export default function Dashboard() {
  const nav = useNavigate()
  const meta = useMeta().data
  const [f, setF] = useState({})
  const [period, setPeriod] = useState('day')
  const q = useQuery({ queryKey: ['dashboard', f, period], queryFn: () => api.get(`/api/dashboard${qs({ ...f, period })}`) })
  const d = q.data
  const k = d?.kpis
  const go = (params) => nav(`/breaks${qs({ ...params, region: f.region, owner: f.owner, category: f.category })}`)
  const set = (key, v) => setF((x) => ({ ...x, [key]: v }))

  return (
    <>
      <PageHeader title="Dashboard" subtitle={d ? `As of ${fmt.date(d.as_of)}. Aging counts business days.` : 'Loading…'}
        actions={
          <>
            <Select className="w-36" value={f.region} onChange={(v) => set('region', v)} placeholder="All regions" options={meta?.regions || []} />
            <Select className="w-44" value={f.owner} onChange={(v) => set('owner', v)} placeholder="All owners" options={(meta?.users || []).map((u) => ({ value: u.username, label: `${u.username} (${u.role})` }))} />
            <Select className="w-56" value={f.category} onChange={(v) => set('category', v)} placeholder="All categories" options={meta?.categories || []} />
            <input type="date" className="input w-36" value={f.date_from || ''} onChange={(e) => set('date_from', e.target.value)} aria-label="Break date from" />
            <input type="date" className="input w-36" value={f.date_to || ''} onChange={(e) => set('date_to', e.target.value)} aria-label="Break date to" />
            {Object.values(f).some(Boolean) && <button className="btn-ghost text-sg-muted" onClick={() => setF({})}>Clear</button>}
          </>
        } />

      {q.error && <div className="mb-5"><ErrorNote error={q.error} onRetry={() => q.refetch()} /></div>}
      {q.isLoading && <div className="skeleton h-40 mb-5" />}
      {d && <Flow flow={d.flow} onPick={(s) => go(s.key === 'total' ? {} : { status: s.key })} />}

      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-5">
        <KpiCard label="Total breaks" value={fmt.num(k?.total)} loading={q.isLoading} onClick={() => go({})} />
        <KpiCard label="Open" value={fmt.num(k?.open)} loading={q.isLoading} onClick={() => go({ status: 'Open' })} />
        <KpiCard label="Closed" value={fmt.num(k?.closed)} loading={q.isLoading} onClick={() => go({ status: 'Closed' })} />
        <KpiCard label="Exceptions" value={fmt.num(k?.exceptions)} hint="SDQ team responsible = Exception" loading={q.isLoading} onClick={() => go({ exceptions: '1' })} />
        <KpiCard label="Overdue" value={fmt.num(k?.overdue)} hint="Open, no action for 5+ business days" tone={k?.overdue ? 'alert' : undefined} loading={q.isLoading} onClick={() => go({ overdue: '1' })} />
        <KpiCard label="Average aging of open breaks" value={k ? `${k.avg_aging_open} d` : '—'} loading={q.isLoading} />
        <KpiCard label="Closure rate" value={k ? `${k.closure_rate}%` : '—'} loading={q.isLoading} />
        <KpiCard label="Open lots impacted" value={fmt.num(k?.open_lots)} loading={q.isLoading} />
      </div>

      {d && (
        <div className="grid xl:grid-cols-2 gap-5">
          <Card title="Aging of open breaks" subtitle="Business days since the break date, in the mentor's escalation bands">
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={d.aging} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
                <CartesianGrid vertical={false} stroke={colors.border} />
                <XAxis dataKey="bucket" {...axis} tickFormatter={(v) => `${v} d`} />
                <YAxis allowDecimals={false} {...axis} />
                <Tooltip {...tip} formatter={(v) => [v, 'Open breaks']} labelFormatter={(l) => `${l} days`} />
                <Bar dataKey="count" radius={[2, 2, 0, 0]} maxBarSize={56} onClick={(e) => go({ aging: e.bucket, status: 'Open' })} cursor="pointer">
                  {d.aging.map((a) => <Cell key={a.bucket} fill={agingColor[a.bucket] || colors.ink} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </Card>

          <Card title="Open and closed" subtitle={`${d.kpis.closure_rate}% of breaks are closed`}>
            <div className="flex items-center gap-6">
              <ResponsiveContainer width="55%" height={240}>
                <PieChart>
                  <Pie data={d.status_split} dataKey="value" nameKey="name" innerRadius={62} outerRadius={96} paddingAngle={1} stroke="none">
                    <Cell fill={colors.red} /><Cell fill={colors.closed} />
                  </Pie>
                  <Tooltip {...tip} />
                </PieChart>
              </ResponsiveContainer>
              <ul className="space-y-4 flex-1">
                {d.status_split.map((s, i) => (
                  <li key={s.name}>
                    <span className="text-[13px] text-sg-muted flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: i ? colors.closed : colors.red }} />{s.name}</span>
                    <span className="text-2xl font-semibold num text-sg-ink">{fmt.num(s.value)}</span>
                  </li>
                ))}
              </ul>
            </div>
          </Card>

          <Card title="Breaks by SDQ comment" subtitle="Most breaks are explained exceptions; the open ones need action">
            {d.sdq_comments.length === 0 ? <EmptyState title="No breaks" /> : (
              <ResponsiveContainer width="100%" height={Math.max(200, d.sdq_comments.length * 34 + 40)}>
                <BarChart layout="vertical" data={d.sdq_comments.map((c) => ({ ...c, short: short(c.comment) }))} margin={{ top: 0, right: 16, left: 0, bottom: 0 }}>
                  <CartesianGrid horizontal={false} stroke={colors.border} />
                  <XAxis type="number" allowDecimals={false} {...axis} />
                  <YAxis type="category" dataKey="short" width={230} {...axis} tick={{ fontSize: 12, fill: colors.text }} />
                  <Tooltip {...tip} labelFormatter={(_, p) => p?.[0]?.payload?.comment || ''} />
                  <Legend iconType="square" iconSize={10} wrapperStyle={{ fontSize: 12 }} />
                  <Bar dataKey="open" name="Open" stackId="a" fill={colors.red} maxBarSize={20} />
                  <Bar dataKey="closed" name="Closed" stackId="a" fill={colors.grey} maxBarSize={20} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </Card>

          <Card title="Workload by owner" subtitle="Average turnaround is business days from break date to close">
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={d.workload} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
                <CartesianGrid vertical={false} stroke={colors.border} />
                <XAxis dataKey="user" {...axis} />
                <YAxis allowDecimals={false} {...axis} />
                <Tooltip {...tip} />
                <Legend iconType="square" iconSize={10} wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="open" name="Open" stackId="w" fill={colors.ink} maxBarSize={48} />
                <Bar dataKey="closed" name="Closed" stackId="w" fill={colors.closed} maxBarSize={48} />
              </BarChart>
            </ResponsiveContainer>
            <table className="w-full text-sm mt-3">
              <thead><tr className="text-xs text-sg-muted text-left"><th className="py-1.5 font-normal">Owner</th><th className="font-normal">Role</th><th className="font-normal text-right">Open</th><th className="font-normal text-right">Closed</th><th className="font-normal text-right">Avg turnaround</th></tr></thead>
              <tbody>
                {d.workload.map((w) => (
                  <tr key={w.user} className="border-t border-sg-border">
                    <td className="py-1.5 text-sg-ink font-semibold">{w.user}</td><td>{w.role}</td>
                    <td className="text-right num">{w.open}</td><td className="text-right num">{w.closed}</td><td className="text-right num">{w.avg_turnaround} d</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>

          <Card title="Breaks created and closed" actions={<Segmented value={period} onChange={setPeriod} options={[{ value: 'day', label: 'Daily' }, { value: 'week', label: 'Weekly' }, { value: 'month', label: 'Monthly' }]} />}>
            {d.trend.length === 0 ? <EmptyState title="No dated breaks yet" /> : (
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={d.trend} margin={{ top: 8, right: 8, left: -16, bottom: 0 }} barGap={2}>
                  <CartesianGrid vertical={false} stroke={colors.border} />
                  <XAxis dataKey="period" {...axis} tickFormatter={(v) => fmt.date(v).slice(0, 6)} minTickGap={16} />
                  <YAxis allowDecimals={false} {...axis} />
                  <Tooltip {...tip} labelFormatter={(l) => (period === 'day' ? fmt.date(l) : `${period === 'week' ? 'Week of' : 'Month of'} ${fmt.date(l)}`)} />
                  <Legend iconType="square" iconSize={10} wrapperStyle={{ fontSize: 12 }} />
                  <Bar dataKey="created" name="Created" fill={colors.ink} maxBarSize={28} />
                  <Bar dataKey="closed" name="Closed" fill={colors.closed} maxBarSize={28} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </Card>

          <Card title="Escalations and SLA" subtitle={`${d.escalations.emails_total} chaser email(s) sent so far`}>
            <div className="flex items-center gap-6">
              {d.escalations.emails_total === 0 ? (
                <div className="w-[60%] h-[220px] flex flex-col items-center justify-center text-center border border-dashed border-sg-border rounded">
                  <p className="text-sm font-semibold text-sg-ink">No chasers sent yet</p>
                  <p className="text-xs text-sg-muted mt-1 max-w-[220px]">Reminders start after 5 business days without action.</p>
                </div>
              ) : (
              <ResponsiveContainer width="60%" height={220}>
                <BarChart data={d.escalations.by_level} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
                  <CartesianGrid vertical={false} stroke={colors.border} />
                  <XAxis dataKey="level" {...axis} interval={0} tickFormatter={(v) => `${v} reminder`} />
                  <YAxis allowDecimals={false} {...axis} />
                  <Tooltip {...tip} formatter={(v) => [v, 'Emails']} />
                  <Bar dataKey="count" maxBarSize={44}>
                    {d.escalations.by_level.map((l, i) => <Cell key={l.level} fill={['#E0A100', '#D9531E', colors.red][i]} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
              )}
              <div className="flex-1">
                <p className="text-[13px] text-sg-muted">SLA adherence</p>
                <p className="text-[40px] leading-tight font-semibold num text-sg-ink">{d.escalations.sla_adherence}%</p>
                <p className="text-xs text-sg-muted">of closed breaks were closed within {d.escalations.sla_days} business days</p>
              </div>
            </div>
          </Card>

          <Card title="High-risk accounts" subtitle="Top 10 clients by open lots aged 5+ business days, then by open lots" className="xl:col-span-2" bodyClass="">
            {d.high_risk.length === 0 ? <EmptyState title="No open breaks" text="Every break is closed." /> : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className="text-xs font-semibold text-sg-ink text-left border-b-2 border-sg-ink">
                    <th className="px-5 py-2">Client</th><th className="px-3">Account</th><th className="px-3 text-right">Open breaks</th>
                    <th className="px-3 text-right">Open lots</th><th className="px-3 text-right">Aged lots (5+ d)</th><th className="px-5 text-right">Oldest (days)</th></tr></thead>
                  <tbody>
                    {d.high_risk.map((h) => (
                      <tr key={h.client + h.account} className="border-b border-sg-border hover:bg-sg-tint cursor-pointer" onClick={() => go({ q: h.account, status: 'Open' })}>
                        <td className="px-5 py-2.5 text-sg-ink font-semibold">{h.client || '—'}</td><td className="px-3 num">{h.account}</td>
                        <td className="px-3 text-right num">{h.open_breaks}</td><td className="px-3 text-right num">{fmt.num(h.open_lots)}</td>
                        <td className={`px-3 text-right num ${h.aged_lots ? 'text-sg-red font-semibold' : ''}`}>{fmt.num(h.aged_lots)}</td>
                        <td className="px-5 text-right num">{h.max_aging}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>
      )}
    </>
  )
}
