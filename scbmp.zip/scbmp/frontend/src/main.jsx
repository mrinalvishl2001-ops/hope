import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import App from './App'
import { AuthProvider } from './auth'
import { ToastProvider } from './components/Toast'
import './index.css'

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchInterval: 60_000,          // auto-refresh every 60 seconds
      refetchOnWindowFocus: true,
      retry: (count, err) => err?.status !== 401 && err?.status !== 403 && err?.status !== 404 && count < 1,
      staleTime: 10_000,
    },
  },
})

class ErrorBoundary extends React.Component {
  constructor(props) { super(props); this.state = { error: null } }
  static getDerivedStateFromError(error) { return { error } }
  render() {
    if (this.state.error) {
      return (
        <div style={{ fontFamily: 'Segoe UI, Arial', padding: 40 }}>
          <h2>Something went wrong on this screen.</h2>
          <p style={{ color: '#767676' }}>{String(this.state.error.message || this.state.error)}</p>
          <button onClick={() => { window.location.href = '/' }} style={{ marginTop: 16, padding: '8px 16px', background: '#E9041E', color: '#fff', border: 0, borderRadius: 4, fontWeight: 600 }}>
            Back to start
          </button>
        </div>
      )
    }
    return this.props.children
  }
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
          <ToastProvider>
            <AuthProvider>
              <App />
            </AuthProvider>
          </ToastProvider>
        </BrowserRouter>
      </QueryClientProvider>
    </ErrorBoundary>
  </React.StrictMode>,
)
