/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        sg: {
          red: '#E9041E', redDark: '#B8031A', black: '#000000', ink: '#1A1A1A', text: '#333333',
          muted: '#767676', border: '#E0E0E0', bg: '#F5F5F5', tint: '#FDE6E8',
          ae: '#1F5C99', sdq: '#5E4B8B', cfmo: '#B86E00', closed: '#1E7F4F',
        },
      },
      fontFamily: { sans: ['"Segoe UI"', 'system-ui', 'Arial', 'sans-serif'] },
      borderRadius: { DEFAULT: '4px' },
      boxShadow: { drawer: '-8px 0 24px rgba(0,0,0,0.12)', pop: '0 6px 20px rgba(0,0,0,0.12)' },
    },
  },
  plugins: [],
}
