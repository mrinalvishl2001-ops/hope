"""Send today's chaser emails. Windows Task Scheduler runs this every weekday at 09:00.

    python run_chasers.py               send in the mode set in Settings (default: Outlook drafts)
    python run_chasers.py --dry-run     only list what would be sent
"""
from __future__ import annotations

import argparse
import sys
from datetime import date

from backend.api.services import get_services, setup_logging
from backend.core import chasers
from backend.core.data_store import StoreError


def _safe_console() -> None:
    try:
        sys.stdout.reconfigure(errors="replace")
    except Exception:
        pass


def main(argv=None) -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--dry-run", action="store_true")
    args = p.parse_args(argv)
    _safe_console()
    setup_logging()
    svc = get_services()
    if date.today().weekday() >= 5 and svc.cfg.chasers.get("business_days", True):
        print("Weekend: no chasers sent.")
        return 0
    try:
        if args.dry_run:
            groups = chasers.plan(svc.store, svc.cfg, svc.users, date.today())
            for g in groups:
                print(f"{g['label']:22} to {g['to']:30} cc {g['cc'] or '-':30} {len(g['breaks'])} break(s)")
            print(f"{len(groups)} email(s) would be sent.")
            return 0
        res = chasers.run(svc.store, svc.cfg, svc.users)
    except StoreError as exc:
        print(f"ERROR: {exc}")
        return 1
    for e in res["emails"]:
        print(f"[{e['mode']}] {e['subject']} -> {e['to']}")
    print(f"{res['count']} email(s) processed in '{res['mode']}' mode.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
