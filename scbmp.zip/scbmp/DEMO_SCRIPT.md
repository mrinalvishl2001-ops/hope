# SCBMP — 5-minute demo script

**Before the demo:** start the app. As Mrinal007 go to **Audit & settings → Settings → Reset demo data** so you start clean. Set the email mode to *Outlook drafts* and put your own address in "Redirect every email to".

### 1. The problem (30 s)
"SDQ assigns every commission break by hand, chases by email, and tracks it across several Excel files. SCBMP automates all of that on the same Excel file."

### 2. Automatic assignment (45 s)
Sign in as **Mrinal007 / Bhaavya**. On the **Dashboard**, point at *Where the breaks are now*: 29 breaks from the daily report — 5 with the AE, 1 with CFMO, 23 already closed as explained exceptions. Open **Upload & assign** and mention that a new daily report is uploaded here; duplicates are skipped and new rows are assigned instantly.

### 3. The AE's view (60 s)
Sign out, sign in as **Nitesh003 / Mentor123**. He sees only his 5 breaks. Open one, tick *Agreement updated*, write a comment, **Send to SDQ for review**. Show the toast. Type `/dashboard` in the address bar — he is sent back to his inbox (role security).

### 4. SDQ → CFMO → closed (75 s)
Sign in as **Mrinal007**: the break is in *My inbox*. Open it, **Send to CFMO for closure** with a comment.
Sign in as **Visva3202 / Godhelpme**: add a comment, then **Close break**. Open the history in the side panel — every step, who, when and why.

### 5. Chasers (60 s)
As **Mrinal007**, open **Chaser centre**. Click **+5**: the 1st reminders. Click **+7**: the 2nd reminders with SDQ copied. Click **+8**: daily reminders. Click **Preview email** to show the email. Back on **Today**, explain the scheduled task runs every weekday at 09:00.

### 6. Proof in the Excel + dashboard (30 s)
Back on the **Dashboard**: closure rate and the flow have updated. Open the Excel: the workflow columns (BF onwards), the **Audit_Log** sheet, and a backup in `backups/`.

### Close (15 s)
"Zero manual assignment, zero email chasing, one source of truth — and the core logic ports straight to Power Automate and Dataverse."
