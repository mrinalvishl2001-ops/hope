"""Run the assignment engine on the configured Excel file.

    python assign_breaks.py
"""
from __future__ import annotations

import sys

from backend.api.services import get_services, setup_logging
from backend.core.assignment import run_assignment
from backend.core.data_store import StoreError


def _safe_console() -> None:
    try:
        sys.stdout.reconfigure(errors="replace")
    except Exception:
        pass


def main() -> int:
    _safe_console()
    setup_logging()
    svc = get_services()
    print(f"Excel file: {svc.cfg.excel_path}")
    try:
        res = run_assignment(svc.store, svc.cfg, svc.users)
    except StoreError as exc:
        print(f"ERROR: {exc}")
        return 1
    print(f"Breaks in file:      {res.total}")
    print(f"Newly assigned:      {res.newly_assigned}")
    print(f"Already assigned:    {res.already_assigned}")
    print("By role:   " + ", ".join(f"{k}={v}" for k, v in sorted(res.by_role.items())))
    print("By status: " + ", ".join(f"{k}={v}" for k, v in sorted(res.by_status.items())))
    if res.unclassified:
        print("Unclassified (sent to SDQ for review): " + ", ".join(res.unclassified))
    return 0


if __name__ == "__main__":
    sys.exit(main())
