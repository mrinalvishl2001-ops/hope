@echo off
setlocal
cd /d "%~dp0"
echo.
echo  === SCBMP setup ===
echo.
if exist .venv\Scripts\python.exe goto install
echo Creating the Python virtual environment (.venv)...
py -3 --version >nul 2>&1
if %errorlevel%==0 (py -3 -m venv .venv) else (python -m venv .venv)
if not exist .venv\Scripts\python.exe (
  echo.
  echo ERROR: could not create .venv. Check that Python 3.10 or newer is installed.
  pause & exit /b 1
)
:install
echo Installing packages (this can take a minute)...
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo ERROR: pip could not install the packages. See "Troubleshooting" in README.md.
  pause & exit /b 1
)
if not exist users.json .venv\Scripts\python.exe manage_users.py init
.venv\Scripts\python.exe assign_breaks.py
echo.
echo Setup complete. Double-click run_app.bat to start SCBMP.
pause
