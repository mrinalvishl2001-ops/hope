@echo off
rem Creates a Windows scheduled task that sends chasers every weekday at 09:00.
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe ( echo Run setup.bat first. & pause & exit /b 1 )
schtasks /Create /F /SC WEEKLY /D MON,TUE,WED,THU,FRI /ST 09:00 /TN "SCBMP Chasers" /TR "\"%~dp0.venv\Scripts\python.exe\" \"%~dp0run_chasers.py\""
if errorlevel 1 ( echo Could not create the task. Your laptop policy may block it; use "Run chasers now" in the app instead. ) else ( echo Task "SCBMP Chasers" created: weekdays at 09:00. Remove it with: schtasks /Delete /TN "SCBMP Chasers" /F )
pause
