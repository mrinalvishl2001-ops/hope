Optional logo slot.
Save the official logo here as logo.png (about 28 px tall) ONLY if your brand guidelines allow it.
It then appears in the top bar automatically. Without it, the app shows the text wordmark "SCBMP".
