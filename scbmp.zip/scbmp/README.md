# SCBMP — Smart Commission Break Management Portal

SCBMP reads the daily Zero Commission / Commission Difference break file, assigns each break to SDQ, CFMO or the Account Executive, gives each person an inbox to act on their breaks, and chases them through Outlook when nothing happens. The Excel file stays the single source of truth: every assignment, comment and closure is written back to it, with an audit trail.

- **Back end:** Python (FastAPI) — assignment engine, workflow, Excel read/write, Outlook chasers.
- **Front end:** React, already built into `frontend/dist`. **Your laptop needs Python only — no Node.js.**

---

## 1. Run it in VS Code (5 minutes)

1. Unzip `scbmp.zip` somewhere you can write to, e.g. `C:\Users\<you>\Documents\scbmp`.
2. In VS Code: **File → Open Folder…** → choose the `scbmp` folder.
3. Open a terminal: **Terminal → New Terminal**, then run these one at a time:

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe assign_breaks.py
.venv\Scripts\python.exe run_app.py
```

4. The browser opens at **http://localhost:8000**. Stop the app with **Ctrl + C** in the terminal.

Next time you only need the last command: `.venv\Scripts\python.exe run_app.py`

> If `python` is not found, try `py -3` instead of `python` in the first command.
> Calling `.venv\Scripts\python.exe` directly avoids PowerShell's "running scripts is disabled" error that `activate` can trigger.

**No-terminal alternative:** double-click `setup.bat` once, then `run_app.bat` every time.

**VS Code buttons:** the **Run and Debug** panel (Ctrl+Shift+D) has ready-made entries: *run the app*, *assign breaks*, *chasers (dry run)* and *run tests*. Select the `.venv` interpreter when VS Code asks.

## 2. Users

| Username  | Password  | Role | Sees |
|-----------|-----------|------|------|
| Mrinal007 | Bhaavya   | SDQ — application owner | Everything: dashboard, all breaks, upload, chasers, audit, settings |
| Visva3202 | Godhelpme | CFMO | Own breaks: comment, close, send back to SDQ |
| Nitesh003 | Mentor123 | Account Executive | Own breaks: comment, send to SDQ |

Passwords are stored only as salted hashes in `users.json`. Change them after the hackathon:

```powershell
.venv\Scripts\python.exe manage_users.py reset Mrinal007 NewPassword
.venv\Scripts\python.exe manage_users.py email Nitesh003 nitesh.name@company.com
.venv\Scripts\python.exe manage_users.py list
```

**Set the real email addresses** (placeholders are `@example.com`) before using chasers in Draft or Live mode.

## 3. Point it at the SharePoint file

1. In SharePoint, open the document library and click **Sync** so it appears in File Explorer under OneDrive.
2. Right-click the Excel file → **Copy as path**.
3. In `config.yaml`, set (single quotes keep the backslashes safe):

```yaml
data:
  excel_path: 'C:\Users\you\OneDrive - Company\SDQ\Combined_Sheet.xlsx'
demo:
  allow_reset: false     # IMPORTANT on the real file
```

4. Restart the app. Unassigned breaks are assigned automatically on start-up (or run `assign_breaks.py`).

The file must keep the standard layout: sheet `Sheet1`, headers in row 1, 57 columns A–BE. SCBMP adds its workflow columns from **BF** onwards (Break ID, Break Category, Assigned Role, Assigned To, Workflow Status, Assigned On, Last Action On, Last Action By, Latest Comment, Chaser Count, Last Chaser On, Closed On, Closed By) and two sheets, **Audit_Log** and **Email_Log**. Original columns are never changed.

**Safety:** before every write a copy goes to `backups/` (last 20 kept). If the file is open in Excel, SCBMP retries for ~10 seconds and then asks you to close it — your comment is kept in the form. Two people editing the same break are warned instead of overwriting each other.

## 4. How assignment works

Rules live in `config.yaml` → `assignment.rules`. SCBMP looks at column **BC (SDQ Team Responsible)**, then **BB (SDQ Comments)**, then the whole row. First match wins; matching is whole-word and case-insensitive.

| Text contains | Category | Goes to |
|---|---|---|
| CFMO, Rate updated, Commission adjustment | Commission Adjustment Required | CFMO (Visva3202) |
| Account Executive, AE, Consensys ITEC, Product mapping, Missing product | Missing Product in Agreement | AE (Nitesh003) |
| SDQ, Exception, Investigation | Investigation Required | SDQ (Mrinal007) |
| nothing matched | Unclassified (flagged) | SDQ (Mrinal007) |

Rows already marked **Closed** in SDQ STATUS are loaded as closed history (no chasers). On the sample file: 29 breaks → 23 closed, 5 with Nitesh003, 1 with Visva3202.

## 5. Workflow

```
AE ──Send to SDQ──▶ SDQ ──Send to CFMO──▶ CFMO ──Close──▶ Closed
                    │  ◀──Send back to SDQ──┘
                    ├──Close──▶ Closed
                    └──Send back to AE──▶ AE
SDQ can also Reassign any open break and Reopen a closed one.
```
Every action needs a comment (5+ characters), resets the chaser clock and is logged in `Audit_Log`.

## 6. Outlook chasers

- **1st reminder** after 5 business days with no action → owner.
- **2nd reminder** 2 business days later → owner, **SDQ copied**.
- **Daily reminder** every business day after that → owner + SDQ (+ optional manager from the 5th, `chasers.manager_email`).
- One email per person per day, listing all their overdue breaks. Any action restarts the clock.

**Modes** (Audit & settings → Settings): *Preview files only* (HTML in `outbox/`), *Outlook drafts* (default — check your Drafts folder), *Send for real*. "Redirect every email to" sends everything to one address for demos. If Outlook or pywin32 is missing, SCBMP writes previews instead of failing.

**Schedule:** double-click `schedule_chasers.bat` to run `run_chasers.py` every weekday at 09:00 via Windows Task Scheduler (the app does not need to be open). Or click **Run chasers now** in the Chaser centre. Test with `.venv\Scripts\python.exe run_chasers.py --dry-run`.

**Demo tip:** in the Chaser centre, the **+5 / +7 / +8** buttons simulate future dates so you can show the 1st, 2nd and daily reminders without waiting. Simulation never sends or saves anything.

## 7. Tests

```powershell
.venv\Scripts\python.exe -m unittest -v
```
23 tests cover dates, passwords and sessions, the assignment rules and expected sample result, the full AE → SDQ → CFMO → Closed flow, permissions, stale-edit protection, backups, the chaser schedule (5 / 7 / 8 days, CC, redirect, no duplicates) and the API role guards. They run on a temporary copy, never on your file.

## 8. Changing the screens (optional, needs Node.js 18+)

The React source is in `frontend/src` (colours in `frontend/src/theme.js` and `frontend/tailwind.config.js`). After editing, double-click `build_frontend.bat` (or `cd frontend`, `npm install`, `npm run build`) and restart the app. For live reload while editing: run the app, then `cd frontend` and `npm run dev`, and open http://localhost:5173.

## 9. Troubleshooting

| Problem | Fix |
|---|---|
| `pip install` fails (proxy / blocked) | Ask IT for the internal PyPI mirror and run `pip install -r requirements.txt --index-url <mirror-url>`; or `pip config set global.index-url <mirror-url>`. |
| `python` not recognised | Use `py -3`, or reinstall Python with "Add to PATH" ticked. |
| "Port 8000 is already in use" | Another SCBMP window is open — close it, or change `app.port` in `config.yaml`. |
| "The Excel file is open elsewhere" | Close the file in Excel (and wait for OneDrive to finish syncing), then click Retry. |
| Outlook asks "A program is trying to send email" | Normal Outlook security on some laptops; click Allow, or use Draft mode. |
| Blank page with "front end not built" | `frontend/dist` is missing — re-extract the zip, or run `build_frontend.bat`. |
| Something else | See `logs/scbmp.log`. |

To let colleagues open the app from their own laptops (only if IT allows), set `app.host: 0.0.0.0` and share `http://<your-computer-name>:8000`.

## 10. Project layout

```
backend/main.py        web server (API + React files)
backend/api/           REST endpoints (/api/docs for interactive docs)
backend/core/          business logic: config, auth, data_store, assignment,
                       workflow, breaks, metrics, chasers, outlook_mail
frontend/src           React source       frontend/dist   pre-built app
assign_breaks.py       run_chasers.py     manage_users.py     run_app.py
config.yaml            users.json         data/            tests/
```

## 11. Scale-up path

This hackathon build runs locally on Python. The production target from the mentor proposal is the Microsoft Power Platform: Dataverse or SharePoint lists instead of the Excel file, Power Automate for assignment and chasers, a Power Apps front end, Teams and Outlook notifications, and Power BI for the dashboard. The logic in `backend/core/` (rules, workflow states, chaser schedule, metrics) is framework-free so it maps directly onto those flows.
